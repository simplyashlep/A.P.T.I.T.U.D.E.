import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const judges = pgTable("judges", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  county: text("county").notNull(),
  countyId: varchar("county_id").references(() => counties.id),
  court: text("court").notNull(),
  prisonRate: real("prison_rate").notNull(),
  totalCases: integer("total_cases").notNull(),
  appealRate: real("appeal_rate").notNull(),
  reversalRate: real("reversal_rate").notNull(),
  riskScore: real("risk_score").notNull(),
  riskLevel: text("risk_level").notNull(),
  yearsServed: integer("years_served").notNull(),
  demographics: jsonb("demographics"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const counties = pgTable("counties", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull().unique(),
  judgeCount: integer("judge_count").notNull(),
  prisonRate: real("prison_rate").notNull(),
  counselDisparity: real("counsel_disparity").notNull(),
  racialDisparity: real("racial_disparity").notNull(),
  riskLevel: text("risk_level").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const chatSessions = pgTable("chat_sessions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  messages: jsonb("messages").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertJudgeSchema = createInsertSchema(judges).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertCountySchema = createInsertSchema(counties).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertChatSessionSchema = createInsertSchema(chatSessions).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertJudge = z.infer<typeof insertJudgeSchema>;
export type Judge = typeof judges.$inferSelect;
export type InsertCounty = z.infer<typeof insertCountySchema>;
export type County = typeof counties.$inferSelect;
export type InsertChatSession = z.infer<typeof insertChatSessionSchema>;
export type ChatSession = typeof chatSessions.$inferSelect;
