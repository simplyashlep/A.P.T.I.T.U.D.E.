# Overview

A.P.T.I.T.U.D.E. is a comprehensive Oregon judicial bias tracking system designed to analyze and monitor judicial performance across all Oregon counties. The application tracks 320+ judges' sentencing patterns, demographic disparities, and bias indicators across all 36 Oregon counties. It provides an interactive dashboard, detailed judge profiles, county-wide analysis, comparison tools, legal document templates, and an AI assistant for legal research.

## Recent Changes (January 2025)
- ✓ Populated database with 320 judges across all 36 Oregon counties
- ✓ Integrated real PostgreSQL data replacing all mock data
- ✓ Applied periwinkle (#C3B1E1) brand styling with government-appropriate design
- ✓ Implemented loading states and proper error handling throughout the platform
- ✓ Added comprehensive data seeding system with realistic Oregon judicial data

# User Preferences

Preferred communication style: Simple, everyday language.

# System Architecture

## Frontend Architecture
The client uses React with TypeScript and Vite for the build system. The UI is built with shadcn/ui components and Radix UI primitives, styled with Tailwind CSS. Navigation is handled by Wouter for client-side routing. The app follows a component-based architecture with separate pages for dashboard, judges, counties, comparison, templates, and AI assistant functionality.

State management is handled through React Query for server state and React hooks for local state. The application is responsive with mobile-first design patterns and uses a custom sidebar navigation system.

## Backend Architecture
The server is built with Express.js and follows a RESTful API design. It uses TypeScript with ES modules and provides endpoints for chat interactions, judge analysis, and template generation. The server implements middleware for logging, error handling, and JSON parsing.

The application uses a service layer pattern with separate modules for OpenAI integration and data storage. Storage is currently implemented with an in-memory store but designed to be easily replaceable with a database implementation.

## Database Layer
The application uses Drizzle ORM with PostgreSQL for data persistence. The schema includes tables for users, judges, counties, and chat sessions. Drizzle Kit is configured for database migrations and schema management.

The database design supports comprehensive judicial tracking with fields for sentencing rates, demographic disparities, appeal rates, and risk assessments. All tables include timestamp tracking for audit purposes.

## AI Integration
The application integrates OpenAI's GPT-4o model for legal assistance functionality. The AI service provides chat responses, judge bias analysis, and legal template generation. The system includes specialized prompts for Oregon legal research and judicial analysis.

## External Dependencies

- **Neon Database**: PostgreSQL hosting service for production database
- **OpenAI API**: GPT-4o model for AI assistant functionality
- **Replit Infrastructure**: Development environment and deployment platform
- **Oregon State Data Sources**: Integration planned for Oregon Judicial Department (OJD), Oregon Criminal Justice Commission (OCJC), Oregon Department of Corrections (DOC), Oregon Department of Justice (DOJ), Open Oregon Public Records, STOP Data, and State of Oregon Law Library
- **Radix UI**: Accessible component primitives for the user interface
- **Recharts**: Data visualization library for charts and graphs
- **React Query**: Server state management and data fetching
- **Tailwind CSS**: Utility-first CSS framework for styling