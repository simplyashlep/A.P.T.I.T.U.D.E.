import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { Bot, User, Send } from "lucide-react";

interface Message {
  id: string;
  type: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

export default function ChatInterface() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      type: "assistant",
      content: "Hello! I'm your A.P.T.I.T.U.D.E. legal assistant. I can help you with Oregon statutes, case law research, judicial statistics, and document generation. What would you like to know?",
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState("");

  const chatMutation = useMutation({
    mutationFn: async (message: string) => {
      const response = await apiRequest("POST", "/api/chat", { message });
      return response.json();
    },
    onSuccess: (data) => {
      const assistantMessage: Message = {
        id: Date.now().toString(),
        type: "assistant",
        content: data.response,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, assistantMessage]);
    },
    onError: (error) => {
      console.error("Chat error:", error);
      const errorMessage: Message = {
        id: Date.now().toString(),
        type: "assistant",
        content: "I apologize, but I'm experiencing technical difficulties. Please try again later.",
        timestamp: new Date()
      };
      setMessages(prev => [...prev, errorMessage]);
    }
  });

  const handleSendMessage = () => {
    if (!inputValue.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      type: "user",
      content: inputValue,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    chatMutation.mutate(inputValue);
    setInputValue("");
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === "Enter" && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  return (
    <Card className="border-periwinkle/20 h-96 flex flex-col">
      <CardHeader className="pb-4">
        <div className="flex items-center">
          <div className="bg-slate-blue/10 p-2 rounded-full mr-3">
            <Bot className="text-slate-blue h-5 w-5" />
          </div>
          <div>
            <CardTitle className="text-lg">Legal Assistant</CardTitle>
            <p className="text-sm text-secondary-text">
              Ask questions about Oregon law, procedure, or judicial statistics
            </p>
          </div>
        </div>
      </CardHeader>
      
      {/* Chat Messages */}
      <CardContent className="flex-1 flex flex-col p-0">
        <ScrollArea className="flex-1 p-4">
          <div className="space-y-4">
            {messages.map((message) => (
              <div
                key={message.id}
                className={`flex items-start ${
                  message.type === "user" ? "justify-end" : "justify-start"
                }`}
              >
                {message.type === "assistant" && (
                  <div className="bg-slate-blue/10 p-2 rounded-full mr-3">
                    <Bot className="text-slate-blue h-4 w-4" />
                  </div>
                )}
                <div
                  className={`max-w-md p-3 rounded-lg ${
                    message.type === "user"
                      ? "bg-slate-blue text-white"
                      : "bg-gray-100"
                  }`}
                >
                  <p className="text-sm">{message.content}</p>
                </div>
                {message.type === "user" && (
                  <div className="bg-slate-blue/10 p-2 rounded-full ml-3">
                    <User className="text-slate-blue h-4 w-4" />
                  </div>
                )}
              </div>
            ))}
            {chatMutation.isPending && (
              <div className="flex items-start">
                <div className="bg-slate-blue/10 p-2 rounded-full mr-3">
                  <Bot className="text-slate-blue h-4 w-4" />
                </div>
                <div className="bg-gray-100 p-3 rounded-lg max-w-md">
                  <p className="text-sm">Thinking...</p>
                </div>
              </div>
            )}
          </div>
        </ScrollArea>
        
        {/* Chat Input */}
        <div className="p-4 border-t border-gray-200">
          <div className="flex space-x-2">
            <Input
              placeholder="Ask about Oregon law, judicial statistics, or legal research..."
              value={inputValue}
              onChange={(e) => setInputValue(e.target.value)}
              onKeyPress={handleKeyPress}
              disabled={chatMutation.isPending}
            />
            <Button
              onClick={handleSendMessage}
              disabled={!inputValue.trim() || chatMutation.isPending}
              className="bg-slate-blue hover:bg-slate-blue/90"
            >
              <Send className="h-4 w-4" />
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
