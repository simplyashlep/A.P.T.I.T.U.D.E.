import { RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis, Radar, ResponsiveContainer, Legend } from 'recharts';

const comparisonData = [
  { metric: 'Prison Rate', judgeA: 42, judgeB: 28 },
  { metric: 'Appeal Rate', judgeA: 15, judgeB: 8 },
  { metric: 'Reversal Rate', judgeA: 23, judgeB: 12 },
  { metric: 'Counsel Disparity', judgeA: 18, judgeB: 3 },
  { metric: 'Racial Disparity', judgeA: 12, judgeB: 2 },
];

export default function ComparisonChart() {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <RadarChart data={comparisonData}>
          <PolarGrid />
          <PolarAngleAxis dataKey="metric" />
          <PolarRadiusAxis domain={[0, 50]} />
          <Radar
            name="Judge A"
            dataKey="judgeA"
            stroke="#EF4444"
            fill="#EF4444"
            fillOpacity={0.2}
          />
          <Radar
            name="Judge B"
            dataKey="judgeB"
            stroke="#22C55E"
            fill="#22C55E"
            fillOpacity={0.2}
          />
          <Legend />
        </RadarChart>
      </ResponsiveContainer>
    </div>
  );
}
