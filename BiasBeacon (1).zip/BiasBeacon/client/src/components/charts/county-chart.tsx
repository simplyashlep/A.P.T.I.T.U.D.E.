import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { countyChartData } from '@/lib/mock-data';

export default function CountyChart() {
  return (
    <div className="h-[300px] w-full">
      <ResponsiveContainer width="100%" height="100%">
        <BarChart data={countyChartData}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="county" />
          <YAxis domain={[0, 50]} />
          <Tooltip />
          <Bar dataKey="prisonRate" fill="#6366F1" />
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
