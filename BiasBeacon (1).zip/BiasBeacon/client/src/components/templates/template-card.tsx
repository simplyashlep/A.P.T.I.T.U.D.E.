import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Template } from "@/lib/mock-data";
import { 
  FileText, 
  AlertTriangle, 
  Home, 
  Scale, 
  Shield, 
  FileSignature 
} from "lucide-react";

interface TemplateCardProps {
  template: Template;
}

export default function TemplateCard({ template }: TemplateCardProps) {
  const getIcon = () => {
    switch (template.icon) {
      case "FileText":
        return <FileText className="text-slate-blue h-5 w-5" />;
      case "AlertTriangle":
        return <AlertTriangle className="text-amber-600 h-5 w-5" />;
      case "Home":
        return <Home className="text-green-600 h-5 w-5" />;
      case "Scale":
        return <Scale className="text-purple-600 h-5 w-5" />;
      case "Shield":
        return <Shield className="text-red-600 h-5 w-5" />;
      case "FileSignature":
        return <FileSignature className="text-blue-600 h-5 w-5" />;
      default:
        return <FileText className="text-slate-blue h-5 w-5" />;
    }
  };

  const getIconBackground = () => {
    switch (template.icon) {
      case "FileText":
        return "bg-slate-blue/10";
      case "AlertTriangle":
        return "bg-amber-100";
      case "Home":
        return "bg-green-100";
      case "Scale":
        return "bg-purple-100";
      case "Shield":
        return "bg-red-100";
      case "FileSignature":
        return "bg-blue-100";
      default:
        return "bg-slate-blue/10";
    }
  };

  return (
    <Card className="border-periwinkle/20 hover:shadow-md transition-shadow">
      <CardContent className="p-6">
        <div className="flex items-center mb-4">
          <div className={`p-3 rounded-full mr-4 ${getIconBackground()}`}>
            {getIcon()}
          </div>
          <div>
            <h3 className="font-semibold">{template.title}</h3>
            <p className="text-sm text-secondary-text">{template.category}</p>
          </div>
        </div>
        <p className="text-sm text-secondary-text mb-4">
          {template.description}
        </p>
        <Button className="w-full bg-slate-blue hover:bg-slate-blue/90">
          Create Template
        </Button>
      </CardContent>
    </Card>
  );
}
