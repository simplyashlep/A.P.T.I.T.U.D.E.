import { Menu } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useSidebar } from "@/hooks/use-sidebar";

export default function MobileHeader() {
  const { toggle } = useSidebar();

  return (
    <Button
      variant="outline"
      size="icon"
      className="md:hidden fixed top-4 left-4 z-50 bg-primary-text text-white hover:bg-primary-text/90"
      onClick={toggle}
    >
      <Menu className="h-4 w-4" />
    </Button>
  );
}
