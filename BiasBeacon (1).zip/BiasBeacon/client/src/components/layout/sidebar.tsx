import { Link, useLocation } from "wouter";
import { cn } from "@/lib/utils";
import { useSidebar } from "@/hooks/use-sidebar";
import {
  LayoutDashboard,
  Gavel,
  Map,
  Scale,
  FileText,
  Bot
} from "lucide-react";

const navItems = [
  { path: "/", label: "Dashboard", icon: LayoutDashboard },
  { path: "/judges", label: "Judges", icon: Gavel },
  { path: "/counties", label: "Counties", icon: Map },
  { path: "/compare", label: "Compare", icon: Scale },
  { path: "/templates", label: "Templates", icon: FileText },
  { path: "/assistant", label: "AI Assistant", icon: Bot },
];

export default function Sidebar() {
  const [location] = useLocation();
  const { isOpen, close } = useSidebar();

  return (
    <nav
      className={cn(
        "sidebar-transition sidebar-mobile md:translate-x-0 fixed left-0 top-0 h-full w-64 bg-primary-text text-white shadow-xl z-40",
        isOpen && "active"
      )}
    >
      <div className="p-6">
        <h1 className="text-xl font-bold text-periwinkle mb-2">A.P.T.I.T.U.D.E.</h1>
        <p className="text-sm text-gray-300 mb-8">Oregon Judicial Tracker</p>
        
        <ul className="space-y-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = location === item.path;
            
            return (
              <li key={item.path}>
                <Link href={item.path}>
                  <div
                    className={cn(
                      "flex items-center p-3 rounded-lg hover:bg-periwinkle/20 transition-colors cursor-pointer",
                      isActive && "bg-periwinkle/20"
                    )}
                    onClick={close}
                  >
                    <Icon className="mr-3 h-5 w-5" />
                    {item.label}
                  </div>
                </Link>
              </li>
            );
          })}
        </ul>
      </div>
    </nav>
  );
}
