import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";

export default function OregonMap() {
  const [selectedCounty, setSelectedCounty] = useState<string | null>(null);

  const handleCountyClick = (county: string) => {
    setSelectedCounty(county);
    // In a real implementation, this would trigger navigation or detailed view
    console.log(`Clicked on ${county} County`);
  };

  return (
    <div className="w-full h-96 bg-secondary-bg rounded-lg flex items-center justify-center relative overflow-hidden">
      <svg viewBox="0 0 400 300" className="w-full h-full">
        {/* Simplified Oregon outline with clickable county regions */}
        <path
          d="M50 150 L100 50 L350 60 L380 150 L350 250 L100 240 Z"
          fill="#E2E8F0"
          stroke="var(--periwinkle)"
          strokeWidth="2"
          className="hover:fill-periwinkle/30 cursor-pointer transition-colors"
          onClick={() => handleCountyClick("Multnomah")}
        />
        <path
          d="M100 50 L200 45 L220 100 L180 140 L100 130 Z"
          fill="#FEF3C7"
          stroke="var(--periwinkle)"
          strokeWidth="2"
          className="hover:fill-periwinkle/30 cursor-pointer transition-colors"
          onClick={() => handleCountyClick("Washington")}
        />
        <path
          d="M220 100 L320 95 L340 150 L280 180 L220 160 Z"
          fill="#DBEAFE"
          stroke="var(--periwinkle)"
          strokeWidth="2"
          className="hover:fill-periwinkle/30 cursor-pointer transition-colors"
          onClick={() => handleCountyClick("Clackamas")}
        />
        <path
          d="M50 150 L120 140 L140 200 L80 220 Z"
          fill="#ECFDF5"
          stroke="var(--periwinkle)"
          strokeWidth="2"
          className="hover:fill-periwinkle/30 cursor-pointer transition-colors"
          onClick={() => handleCountyClick("Lane")}
        />
        
        {/* County labels */}
        <text x="120" y="90" fontSize="12" fill="var(--primary-text)" textAnchor="middle" className="pointer-events-none">
          Multnomah
        </text>
        <text x="160" y="75" fontSize="10" fill="var(--primary-text)" textAnchor="middle" className="pointer-events-none">
          Washington
        </text>
        <text x="280" y="125" fontSize="10" fill="var(--primary-text)" textAnchor="middle" className="pointer-events-none">
          Clackamas
        </text>
        <text x="95" y="185" fontSize="10" fill="var(--primary-text)" textAnchor="middle" className="pointer-events-none">
          Lane
        </text>
      </svg>
      
      <Card className="absolute bottom-4 left-4 bg-white">
        <CardContent className="p-3">
          <h4 className="font-medium text-sm mb-2">Legend</h4>
          <div className="space-y-1 text-xs">
            <div className="flex items-center">
              <div className="w-3 h-3 bg-red-200 mr-2 rounded"></div>
              High Bias Risk
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-yellow-200 mr-2 rounded"></div>
              Moderate Risk
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-blue-200 mr-2 rounded"></div>
              Low Risk
            </div>
            <div className="flex items-center">
              <div className="w-3 h-3 bg-green-200 mr-2 rounded"></div>
              Excellent
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
