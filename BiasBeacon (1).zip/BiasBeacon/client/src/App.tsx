import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Dashboard from "@/pages/dashboard";
import Judges from "@/pages/judges";
import Counties from "@/pages/counties";
import Compare from "@/pages/compare";
import Templates from "@/pages/templates";
import Assistant from "@/pages/assistant";
import Sidebar from "@/components/layout/sidebar";
import MobileHeader from "@/components/layout/mobile-header";
import { SidebarProvider } from "@/hooks/use-sidebar";

function Router() {
  return (
    <div className="min-h-screen bg-primary-bg">
      <SidebarProvider>
        <MobileHeader />
        <Sidebar />
        <main className="md:ml-64 min-h-screen">
          <Switch>
            <Route path="/" component={Dashboard} />
            <Route path="/judges" component={Judges} />
            <Route path="/counties" component={Counties} />
            <Route path="/compare" component={Compare} />
            <Route path="/templates" component={Templates} />
            <Route path="/assistant" component={Assistant} />
            <Route component={NotFound} />
          </Switch>
        </main>
      </SidebarProvider>
    </div>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
