export interface Judge {
  id: string;
  name: string;
  county: string;
  court: string;
  prisonRate: number;
  totalCases: number;
  appealRate: number;
  reversalRate: number;
  counselDisparity: number;
  racialDisparity: number;
  riskLevel: 'low' | 'moderate' | 'high' | 'excellent';
}

export interface County {
  name: string;
  judgeCount: number;
  prisonRate: number;
  counselDisparity: number;
  racialDisparity: number;
  riskLevel: 'low' | 'moderate' | 'high' | 'excellent';
}

export interface Alert {
  id: string;
  type: 'high' | 'moderate';
  judge?: string;
  county?: string;
  message: string;
  timestamp: string;
}

export interface Template {
  id: string;
  title: string;
  description: string;
  category: string;
  icon: string;
}

export const mockJudges: Judge[] = [
  {
    id: "1",
    name: "Judge Sarah Williams",
    county: "Multnomah",
    court: "Circuit Court",
    prisonRate: 42,
    totalCases: 1247,
    appealRate: 15,
    reversalRate: 23,
    counselDisparity: 18,
    racialDisparity: 12,
    riskLevel: "high"
  },
  {
    id: "2",
    name: "Judge Michael Chen",
    county: "Washington",
    court: "Circuit Court",
    prisonRate: 28,
    totalCases: 892,
    appealRate: 8,
    reversalRate: 12,
    counselDisparity: 3,
    racialDisparity: 2,
    riskLevel: "excellent"
  },
  {
    id: "3",
    name: "Judge Patricia Davis",
    county: "Lane",
    court: "Circuit Court",
    prisonRate: 35,
    totalCases: 1089,
    appealRate: 12,
    reversalRate: 18,
    counselDisparity: 8,
    racialDisparity: 5,
    riskLevel: "moderate"
  }
];

export const mockCounties: County[] = [
  {
    name: "Multnomah",
    judgeCount: 47,
    prisonRate: 32,
    counselDisparity: 18,
    racialDisparity: 12,
    riskLevel: "high"
  },
  {
    name: "Washington",
    judgeCount: 23,
    prisonRate: 29,
    counselDisparity: 8,
    racialDisparity: 2,
    riskLevel: "moderate"
  },
  {
    name: "Clackamas",
    judgeCount: 18,
    prisonRate: 26,
    counselDisparity: 3,
    racialDisparity: 1,
    riskLevel: "low"
  },
  {
    name: "Lane",
    judgeCount: 15,
    prisonRate: 24,
    counselDisparity: 1,
    racialDisparity: -1,
    riskLevel: "excellent"
  }
];

export const mockAlerts: Alert[] = [
  {
    id: "1",
    type: "high",
    judge: "Judge Smith",
    county: "Multnomah County",
    message: "Prison rate 23% higher for court-appointed counsel cases",
    timestamp: "2 hours ago"
  },
  {
    id: "2",
    type: "moderate",
    county: "Washington County",
    message: "Higher revocation rates for defendants of color detected",
    timestamp: "1 day ago"
  }
];

export const mockTemplates: Template[] = [
  {
    id: "1",
    title: "Motion to Compel",
    description: "Generate motions to compel discovery responses with customizable arguments and legal citations.",
    category: "Discovery",
    icon: "FileText"
  },
  {
    id: "2",
    title: "Judicial Misconduct Complaint",
    description: "File formal complaints against judges showing bias or misconduct with supporting evidence.",
    category: "Ethics",
    icon: "AlertTriangle"
  },
  {
    id: "3",
    title: "Landlord/Tenant Notice",
    description: "Generate proper notices for landlord-tenant disputes including cure or quit notices.",
    category: "Housing",
    icon: "Home"
  },
  {
    id: "4",
    title: "Bar Complaint",
    description: "File complaints against attorneys for professional misconduct or ethical violations.",
    category: "Professional",
    icon: "Scale"
  },
  {
    id: "5",
    title: "Police Complaint",
    description: "File formal complaints against law enforcement for misconduct or civil rights violations.",
    category: "Civil Rights",
    icon: "Shield"
  },
  {
    id: "6",
    title: "Affidavit/Declaration",
    description: "Create sworn affidavits and declarations for court proceedings with proper formatting.",
    category: "Court Documents",
    icon: "FileSignature"
  }
];

export const countyChartData = [
  { county: "Multnomah", prisonRate: 32, color: "#EF4444" },
  { county: "Washington", prisonRate: 29, color: "#FACC15" },
  { county: "Clackamas", prisonRate: 26, color: "#22C55E" },
  { county: "Lane", prisonRate: 24, color: "#22C55E" },
  { county: "Jackson", prisonRate: 31, color: "#FACC15" }
];

export const counselChartData = [
  { type: "Court-Appointed", rate: 38, color: "#EF4444" },
  { type: "Retained Private", rate: 24, color: "#22C55E" }
];
