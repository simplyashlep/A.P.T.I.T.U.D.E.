import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { Badge } from "@/components/ui/badge";
import CountyChart from "@/components/charts/county-chart";
import CounselChart from "@/components/charts/counsel-chart";
import { useQuery } from "@tanstack/react-query";
import type { Judge, County } from "@shared/schema";
import { 
  Gavel, 
  BarChart3, 
  Map, 
  AlertTriangle,
  AlertCircle,
  TriangleAlert
} from "lucide-react";

export default function Dashboard() {
  const { data: judges = [], isLoading: judgesLoading } = useQuery<Judge[]>({
    queryKey: ["/api/judges"],
    retry: false,
  });

  const { data: counties = [], isLoading: countiesLoading } = useQuery<County[]>({
    queryKey: ["/api/counties"],
    retry: false,
  });

  // Calculate statistics from real data
  const totalJudges = judges.length;
  const totalCases = judges.reduce((sum, j) => sum + j.totalCases, 0);
  const totalCounties = counties.length;
  const highRiskJudges = judges.filter(j => j.riskScore > 75).length;

  // Generate alerts from real data
  const recentAlerts = [
    ...judges.filter(j => j.riskScore > 85).slice(0, 3).map(j => ({
      id: `judge-${j.id}`,
      type: 'high' as const,
      judge: j.name,
      county: counties.find(c => c.id === j.countyId)?.name || 'Unknown',
      message: `High bias risk score of ${j.riskScore.toFixed(1)}% detected`,
      timestamp: '2 hours ago'
    })),
    ...counties.filter(c => c.racialDisparity > 15).slice(0, 2).map(c => ({
      id: `county-${c.id}`,
      type: 'medium' as const,
      county: c.name,
      message: `Significant racial disparity of ${c.racialDisparity.toFixed(1)}% in sentencing`,
      timestamp: '1 day ago'
    }))
  ].slice(0, 5);

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Oregon Judicial Dashboard</h2>
        <p className="text-secondary-text">
          Comprehensive judicial bias tracking across all Oregon counties (2019-2024)
        </p>
      </div>

      {/* Key Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <Card className="border-periwinkle/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-secondary-text text-sm">Total Judges Tracked</p>
                <p className="text-2xl font-bold">
                  {judgesLoading ? '...' : totalJudges.toLocaleString()}
                </p>
              </div>
              <div className="bg-slate-blue/10 p-3 rounded-full">
                <Gavel className="text-slate-blue h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-periwinkle/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-secondary-text text-sm">Cases Analyzed</p>
                <p className="text-2xl font-bold">
                  {judgesLoading ? '...' : `${(totalCases / 1000000).toFixed(1)}M+`}
                </p>
              </div>
              <div className="bg-emerald-100 p-3 rounded-full">
                <BarChart3 className="text-emerald-600 h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-periwinkle/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-secondary-text text-sm">Counties Covered</p>
                <p className="text-2xl font-bold">
                  {countiesLoading ? '...' : totalCounties}
                </p>
              </div>
              <div className="bg-amber-100 p-3 rounded-full">
                <Map className="text-amber-600 h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="border-periwinkle/20">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-secondary-text text-sm">High-Risk Judges</p>
                <p className="text-2xl font-bold">
                  {judgesLoading ? '...' : highRiskJudges}
                </p>
              </div>
              <div className="bg-red-100 p-3 rounded-full">
                <AlertTriangle className="text-red-600 h-5 w-5" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        <Card className="border-periwinkle/20">
          <CardHeader>
            <CardTitle>Sentencing Disparities by County</CardTitle>
          </CardHeader>
          <CardContent>
            <CountyChart />
          </CardContent>
        </Card>

        <Card className="border-periwinkle/20">
          <CardHeader>
            <CardTitle>Prison Rate by Counsel Type</CardTitle>
          </CardHeader>
          <CardContent>
            <CounselChart />
          </CardContent>
        </Card>
      </div>

      {/* Recent Alerts */}
      <Card className="border-periwinkle/20">
        <CardHeader>
          <CardTitle>Recent Bias Alerts</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {judgesLoading || countiesLoading ? (
              [...Array(3)].map((_, i) => (
                <Alert key={i} className="border-gray-200 bg-gray-50">
                  <div className="flex items-center">
                    <div className="h-4 w-4 bg-gray-300 rounded animate-pulse mr-3"></div>
                    <div className="flex-1">
                      <div className="h-4 bg-gray-300 rounded animate-pulse w-3/4 mb-2"></div>
                      <div className="h-3 bg-gray-300 rounded animate-pulse w-1/2"></div>
                    </div>
                    <div className="h-6 bg-gray-300 rounded animate-pulse w-16"></div>
                  </div>
                </Alert>
              ))
            ) : recentAlerts.length > 0 ? (
              recentAlerts.map((alert) => (
                <Alert key={alert.id} className={alert.type === 'high' ? 'border-red-200 bg-red-50' : 'border-amber-200 bg-amber-50'}>
                  <div className="flex items-center">
                    {alert.type === 'high' ? (
                      <AlertCircle className="h-4 w-4 text-red-500 mr-3" />
                    ) : (
                      <TriangleAlert className="h-4 w-4 text-amber-500 mr-3" />
                    )}
                    <div className="flex-1">
                      <p className="font-medium">
                        {alert.judge ? `${alert.judge} (${alert.county})` : alert.county}
                      </p>
                      <AlertDescription className="text-secondary-text">
                        {alert.message}
                      </AlertDescription>
                    </div>
                    <Badge variant="outline" className="text-xs">
                      {alert.timestamp}
                    </Badge>
                  </div>
                </Alert>
              ))
            ) : (
              <Alert className="border-green-200 bg-green-50">
                <div className="flex items-center">
                  <AlertCircle className="h-4 w-4 text-green-500 mr-3" />
                  <div className="flex-1">
                    <p className="font-medium">No Critical Alerts</p>
                    <AlertDescription className="text-secondary-text">
                      All judges and counties are within acceptable bias thresholds.
                    </AlertDescription>
                  </div>
                </div>
              </Alert>
            )}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
