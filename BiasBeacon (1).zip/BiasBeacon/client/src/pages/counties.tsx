import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import OregonMap from "@/components/maps/oregon-map";
import { useQuery } from "@tanstack/react-query";
import type { County } from "@shared/schema";

export default function Counties() {
  const { data: counties = [], isLoading } = useQuery<County[]>({
    queryKey: ["/api/counties"],
    retry: false,
  });

  const getRiskBadgeColor = (riskLevel: string) => {
    switch (riskLevel) {
      case "high":
        return "bg-red-100 text-red-800";
      case "moderate":
        return "bg-amber-100 text-amber-800";
      case "low":
        return "bg-blue-100 text-blue-800";
      case "excellent":
        return "bg-green-100 text-green-800";
      default:
        return "bg-gray-100 text-gray-800";
    }
  };

  const getDisparityColor = (value: number) => {
    if (value >= 15) return "text-red-500";
    if (value >= 5) return "text-amber-500";
    return "text-green-500";
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">County Analysis</h2>
        <p className="text-secondary-text">
          County-wide judicial statistics and trends
        </p>
      </div>

      {/* Oregon Map */}
      <Card className="border-periwinkle/20 mb-6">
        <CardHeader>
          <CardTitle>Oregon Counties Interactive Map</CardTitle>
        </CardHeader>
        <CardContent>
          <OregonMap />
        </CardContent>
      </Card>

      {/* County Stats Table */}
      <Card className="border-periwinkle/20">
        <CardHeader>
          <CardTitle>County Performance Metrics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-gray-200">
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary-text uppercase tracking-wider">
                    County
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary-text uppercase tracking-wider">
                    Judges
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary-text uppercase tracking-wider">
                    Prison Rate
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary-text uppercase tracking-wider">
                    Counsel Disparity
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary-text uppercase tracking-wider">
                    Racial Disparity
                  </th>
                  <th className="px-4 py-3 text-left text-xs font-medium text-secondary-text uppercase tracking-wider">
                    Risk Level
                  </th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-200">
                {isLoading ? (
                  [...Array(6)].map((_, i) => (
                    <tr key={i} className="hover:bg-gray-50">
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="h-4 bg-gray-200 rounded animate-pulse"></div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-8"></div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-12"></div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-10"></div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="h-4 bg-gray-200 rounded animate-pulse w-10"></div>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <div className="h-6 bg-gray-200 rounded animate-pulse w-16"></div>
                      </td>
                    </tr>
                  ))
                ) : (
                  counties.map((county) => (
                    <tr key={county.name} className="hover:bg-gray-50">
                      <td className="px-4 py-4 whitespace-nowrap font-medium">
                        {county.name}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        {county.judgeCount}
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        {county.prisonRate.toFixed(1)}%
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className={getDisparityColor(county.counselDisparity)}>
                          +{county.counselDisparity.toFixed(1)}%
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <span className={getDisparityColor(Math.abs(county.racialDisparity))}>
                          {county.racialDisparity > 0 ? '+' : ''}{county.racialDisparity.toFixed(1)}%
                        </span>
                      </td>
                      <td className="px-4 py-4 whitespace-nowrap">
                        <Badge 
                          variant="outline" 
                          className={getRiskBadgeColor(county.riskLevel)}
                        >
                          {county.riskLevel.charAt(0).toUpperCase() + county.riskLevel.slice(1)}
                        </Badge>
                      </td>
                    </tr>
                  ))
                )}
              </tbody>
            </table>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
