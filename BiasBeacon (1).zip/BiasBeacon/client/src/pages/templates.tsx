import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import TemplateCard from "@/components/templates/template-card";
import { mockTemplates } from "@/lib/mock-data";

export default function Templates() {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Legal Document Templates</h2>
        <p className="text-secondary-text">
          Generate customized legal documents and forms
        </p>
      </div>

      {/* Template Categories */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {mockTemplates.map((template) => (
          <TemplateCard key={template.id} template={template} />
        ))}
      </div>
    </div>
  );
}
