import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import ComparisonChart from "@/components/charts/comparison-chart";
import { mockJudges } from "@/lib/mock-data";

export default function Compare() {
  const [judgeA, setJudgeA] = useState<string>("");
  const [judgeB, setJudgeB] = useState<string>("");

  const selectedJudgeA = mockJudges.find(j => j.id === judgeA);
  const selectedJudgeB = mockJudges.find(j => j.id === judgeB);

  const StatCard = ({ value, label, type = "default" }: { value: string | number; label: string; type?: "high" | "moderate" | "low" | "default" }) => {
    const getBackgroundColor = () => {
      switch (type) {
        case "high": return "bg-red-50";
        case "moderate": return "bg-amber-50";
        case "low": return "bg-blue-50";
        default: return "bg-gray-50";
      }
    };

    const getTextColor = () => {
      switch (type) {
        case "high": return "text-red-500";
        case "moderate": return "text-amber-500";
        case "low": return "text-blue-500";
        default: return "text-gray-900";
      }
    };

    return (
      <div className={`text-center p-3 rounded-lg ${getBackgroundColor()}`}>
        <p className={`text-2xl font-bold ${getTextColor()}`}>{value}</p>
        <p className="text-xs text-secondary-text">{label}</p>
      </div>
    );
  };

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Judge Comparison</h2>
        <p className="text-secondary-text">
          Side-by-side analysis of judicial performance
        </p>
      </div>

      {/* Comparison Tool */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
        {/* Judge A Selection */}
        <Card className="border-periwinkle/20">
          <CardHeader>
            <CardTitle>Judge A</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={judgeA} onValueChange={setJudgeA}>
              <SelectTrigger className="mb-4">
                <SelectValue placeholder="Select Judge..." />
              </SelectTrigger>
              <SelectContent>
                {mockJudges.map((judge) => (
                  <SelectItem key={judge.id} value={judge.id}>
                    {judge.name} - {judge.county}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {selectedJudgeA && (
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">{selectedJudgeA.name}</h4>
                  <p className="text-sm text-secondary-text">
                    {selectedJudgeA.county} County {selectedJudgeA.court}
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <StatCard
                    value={`${selectedJudgeA.prisonRate}%`}
                    label="Prison Rate"
                    type={selectedJudgeA.prisonRate >= 40 ? "high" : selectedJudgeA.prisonRate >= 30 ? "moderate" : "low"}
                  />
                  <StatCard
                    value={selectedJudgeA.totalCases.toLocaleString()}
                    label="Total Cases"
                  />
                  <StatCard
                    value={`${selectedJudgeA.reversalRate}%`}
                    label="Reversal Rate"
                    type={selectedJudgeA.reversalRate >= 20 ? "moderate" : "low"}
                  />
                  <StatCard
                    value={`+${selectedJudgeA.counselDisparity}%`}
                    label="Counsel Disparity"
                    type={selectedJudgeA.counselDisparity >= 15 ? "high" : selectedJudgeA.counselDisparity >= 5 ? "moderate" : "low"}
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Judge B Selection */}
        <Card className="border-periwinkle/20">
          <CardHeader>
            <CardTitle>Judge B</CardTitle>
          </CardHeader>
          <CardContent>
            <Select value={judgeB} onValueChange={setJudgeB}>
              <SelectTrigger className="mb-4">
                <SelectValue placeholder="Select Judge..." />
              </SelectTrigger>
              <SelectContent>
                {mockJudges.map((judge) => (
                  <SelectItem key={judge.id} value={judge.id}>
                    {judge.name} - {judge.county}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            
            {selectedJudgeB && (
              <div className="space-y-4">
                <div className="bg-gray-50 p-4 rounded-lg">
                  <h4 className="font-medium mb-2">{selectedJudgeB.name}</h4>
                  <p className="text-sm text-secondary-text">
                    {selectedJudgeB.county} County {selectedJudgeB.court}
                  </p>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <StatCard
                    value={`${selectedJudgeB.prisonRate}%`}
                    label="Prison Rate"
                    type={selectedJudgeB.prisonRate >= 40 ? "high" : selectedJudgeB.prisonRate >= 30 ? "moderate" : "low"}
                  />
                  <StatCard
                    value={selectedJudgeB.totalCases.toLocaleString()}
                    label="Total Cases"
                  />
                  <StatCard
                    value={`${selectedJudgeB.reversalRate}%`}
                    label="Reversal Rate"
                    type={selectedJudgeB.reversalRate >= 20 ? "moderate" : "low"}
                  />
                  <StatCard
                    value={`+${selectedJudgeB.counselDisparity}%`}
                    label="Counsel Disparity"
                    type={selectedJudgeB.counselDisparity >= 15 ? "high" : selectedJudgeB.counselDisparity >= 5 ? "moderate" : "low"}
                  />
                </div>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Comparison Chart */}
      {selectedJudgeA && selectedJudgeB && (
        <Card className="border-periwinkle/20">
          <CardHeader>
            <CardTitle>Comparative Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <ComparisonChart />
          </CardContent>
        </Card>
      )}
    </div>
  );
}
