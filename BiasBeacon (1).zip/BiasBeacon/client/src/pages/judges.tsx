import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import JudgeCard from "@/components/judges/judge-card";
import { useQuery } from "@tanstack/react-query";
import type { Judge } from "@shared/schema";

export default function Judges() {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCounty, setSelectedCounty] = useState("all");
  const [selectedCourt, setSelectedCourt] = useState("all");

  const { data: judges = [], isLoading } = useQuery<Judge[]>({
    queryKey: ["/api/judges", selectedCounty, selectedCourt],
    retry: false,
  });

  const filteredJudges = judges.filter(judge => {
    const matchesSearch = judge.name.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesSearch;
  });

  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">Judge Database</h2>
        <p className="text-secondary-text">
          Detailed profiles and statistics for all Oregon judges
        </p>
      </div>

      {/* Search and Filters */}
      <Card className="border-periwinkle/20 mb-6">
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <Label htmlFor="search">Search Judge</Label>
              <Input
                id="search"
                placeholder="Enter judge name..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="mt-2"
              />
            </div>
            <div>
              <Label>County</Label>
              <Select value={selectedCounty} onValueChange={setSelectedCounty}>
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Counties</SelectItem>
                  <SelectItem value="Multnomah">Multnomah</SelectItem>
                  <SelectItem value="Washington">Washington</SelectItem>
                  <SelectItem value="Clackamas">Clackamas</SelectItem>
                  <SelectItem value="Lane">Lane</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label>Court Type</Label>
              <Select value={selectedCourt} onValueChange={setSelectedCourt}>
                <SelectTrigger className="mt-2">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Courts</SelectItem>
                  <SelectItem value="Circuit Court">Circuit Court</SelectItem>
                  <SelectItem value="District Court">District Court</SelectItem>
                  <SelectItem value="Municipal Court">Municipal Court</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Judge Cards */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="border-periwinkle/20">
              <CardContent className="p-6">
                <div className="animate-pulse">
                  <div className="h-4 bg-gray-200 rounded w-3/4 mb-2"></div>
                  <div className="h-3 bg-gray-200 rounded w-1/2 mb-4"></div>
                  <div className="space-y-2">
                    <div className="h-3 bg-gray-200 rounded"></div>
                    <div className="h-3 bg-gray-200 rounded"></div>
                    <div className="h-3 bg-gray-200 rounded"></div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredJudges.map((judge) => (
            <JudgeCard key={judge.id} judge={judge} />
          ))}
        </div>
      )}

      {!isLoading && filteredJudges.length === 0 && (
        <Card className="border-periwinkle/20">
          <CardContent className="p-8 text-center">
            <p className="text-secondary-text">No judges found matching your criteria.</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
