import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import ChatInterface from "@/components/assistant/chat-interface";
import { Search, Book, TrendingUp, Bot } from "lucide-react";

export default function Assistant() {
  return (
    <div className="p-6">
      <div className="mb-8">
        <h2 className="text-3xl font-bold mb-2">A.P.T.I.T.U.D.E. Legal Assistant</h2>
        <p className="text-secondary-text">
          AI-powered legal research and case analysis
        </p>
      </div>

      {/* Chat Interface */}
      <ChatInterface />

      {/* Quick Actions */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
        <Button
          variant="outline"
          className="p-4 h-auto flex-col items-start border-periwinkle/20 hover:shadow-md"
        >
          <Search className="text-slate-blue mb-2 h-5 w-5" />
          <h4 className="font-medium mb-1">Case Law Search</h4>
          <p className="text-sm text-secondary-text text-left">
            Search Oregon Supreme Court and Court of Appeals decisions
          </p>
        </Button>
        
        <Button
          variant="outline"
          className="p-4 h-auto flex-col items-start border-periwinkle/20 hover:shadow-md"
        >
          <Book className="text-slate-blue mb-2 h-5 w-5" />
          <h4 className="font-medium mb-1">Statute Lookup</h4>
          <p className="text-sm text-secondary-text text-left">
            Quick access to Oregon Revised Statutes (ORS)
          </p>
        </Button>
        
        <Button
          variant="outline"
          className="p-4 h-auto flex-col items-start border-periwinkle/20 hover:shadow-md"
        >
          <TrendingUp className="text-slate-blue mb-2 h-5 w-5" />
          <h4 className="font-medium mb-1">Judge Analysis</h4>
          <p className="text-sm text-secondary-text text-left">
            Get detailed insights on specific judges or patterns
          </p>
        </Button>
      </div>
    </div>
  );
}
