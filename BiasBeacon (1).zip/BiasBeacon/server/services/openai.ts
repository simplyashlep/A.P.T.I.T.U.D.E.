import OpenAI from "openai";

// the newest OpenAI model is "gpt-4o" which was released May 13, 2024. do not change this unless explicitly requested by the user
const openai = new OpenAI({ 
  apiKey: process.env.OPENAI_API_KEY || process.env.OPENAI_API_KEY_ENV_VAR || "default_key"
});

export interface ChatMessage {
  role: 'system' | 'user' | 'assistant';
  content: string;
}

export async function generateChatResponse(message: string): Promise<string> {
  try {
    const systemPrompt = `You are A.P.T.I.T.U.D.E., a specialized legal assistant for Oregon judicial bias tracking and legal research. You help with:

1. Oregon statutes (ORS) and administrative rules (OAR)
2. Oregon case law from Supreme Court and Court of Appeals
3. Judicial statistics and bias analysis
4. Legal document templates and forms
5. Court procedures and practice

You have access to comprehensive judicial data for Oregon judges including sentencing patterns, bias indicators, and performance metrics. Provide accurate, helpful legal information while being mindful that you cannot provide legal advice.

When discussing judges or judicial statistics, reference general patterns and suggest users check the specific judge profiles in the system for detailed data.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [
        { role: "system", content: systemPrompt },
        { role: "user", content: message }
      ],
      max_tokens: 500,
      temperature: 0.7,
    });

    return response.choices[0]?.message?.content || "I apologize, but I couldn't generate a response. Please try again.";
  } catch (error) {
    console.error("OpenAI API error:", error);
    throw new Error("Failed to generate chat response");
  }
}

export async function analyzeJudgeBias(judgeData: {
  name: string;
  prisonRate: number;
  counselDisparity: number;
  racialDisparity: number;
  reversalRate: number;
}): Promise<{
  summary: string;
  concerns: string[];
  recommendations: string[];
}> {
  try {
    const prompt = `Analyze this Oregon judge's performance data and provide insights:
    
Judge: ${judgeData.name}
Prison Rate: ${judgeData.prisonRate}%
Counsel Disparity: +${judgeData.counselDisparity}% (higher for court-appointed)
Racial Disparity: +${judgeData.racialDisparity}% (higher for defendants of color)
Reversal Rate: ${judgeData.reversalRate}%

Provide analysis in JSON format with fields: summary, concerns (array), recommendations (array)`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      response_format: { type: "json_object" },
    });

    const result = JSON.parse(response.choices[0].message.content || "{}");
    return {
      summary: result.summary || "Analysis unavailable",
      concerns: result.concerns || [],
      recommendations: result.recommendations || []
    };
  } catch (error) {
    console.error("Judge bias analysis error:", error);
    throw new Error("Failed to analyze judge bias");
  }
}

export async function generateLegalTemplate(templateType: string, details: Record<string, any>): Promise<string> {
  try {
    const prompt = `Generate a ${templateType} template for Oregon law with the following details:
    ${Object.entries(details).map(([key, value]) => `${key}: ${value}`).join('\n')}
    
    Include proper legal formatting, citations where applicable, and placeholder fields for customization.`;

    const response = await openai.chat.completions.create({
      model: "gpt-4o",
      messages: [{ role: "user", content: prompt }],
      max_tokens: 1000,
    });

    return response.choices[0]?.message?.content || "Template generation failed";
  } catch (error) {
    console.error("Template generation error:", error);
    throw new Error("Failed to generate legal template");
  }
}
