import { db } from "./db";
import { judges, counties } from "@shared/schema";
import type { InsertJudge, InsertCounty } from "@shared/schema";

// All 36 Oregon counties
const oregonCounties = [
  "Baker", "Benton", "Clackamas", "Clatsop", "Columbia", "Coos", "Crook", "Curry",
  "Deschutes", "Douglas", "Gilliam", "Grant", "Harney", "Hood River", "Jackson",
  "Jefferson", "Josephine", "Klamath", "Lake", "Lane", "Lincoln", "Linn", "Malheur",
  "Marion", "Morrow", "Multnomah", "Polk", "Sherman", "Tillamook", "Umatilla",
  "Union", "Wallowa", "Wasco", "Washington", "Wheeler", "Yamhill"
];

// Common Oregon judge names (mix of realistic names)
const judgeFirstNames = [
  "Michael", "Sarah", "David", "Jennifer", "Robert", "Lisa", "James", "Mary",
  "John", "Patricia", "William", "Linda", "Richard", "Elizabeth", "Joseph", "Barbara",
  "Thomas", "Susan", "Christopher", "Jessica", "Charles", "Margaret", "Daniel", "Karen",
  "Matthew", "Nancy", "Anthony", "Betty", "Mark", "Helen", "Donald", "Sandra",
  "Steven", "Donna", "Paul", "Carol", "Andrew", "Ruth", "Joshua", "Sharon",
  "Kenneth", "Michelle", "Kevin", "Laura", "Brian", "Sarah", "George", "Kimberly",
  "Timothy", "Deborah", "Ronald", "Dorothy", "Jason", "Amy", "Edward", "Angela",
  "Jeffrey", "Brenda", "Ryan", "Emma", "Jacob", "Olivia", "Gary", "Cynthia",
  "Nicholas", "Marie", "Eric", "Janet", "Jonathan", "Frances", "Stephen", "Christine"
];

const judgeLastNames = [
  "Smith", "Johnson", "Williams", "Brown", "Jones", "Garcia", "Miller", "Davis",
  "Rodriguez", "Martinez", "Hernandez", "Lopez", "Gonzalez", "Wilson", "Anderson", "Thomas",
  "Taylor", "Moore", "Jackson", "Martin", "Lee", "Perez", "Thompson", "White",
  "Harris", "Sanchez", "Clark", "Ramirez", "Lewis", "Robinson", "Walker", "Young",
  "Allen", "King", "Wright", "Scott", "Torres", "Nguyen", "Hill", "Flores",
  "Green", "Adams", "Nelson", "Baker", "Hall", "Rivera", "Campbell", "Mitchell",
  "Carter", "Roberts", "Gomez", "Phillips", "Evans", "Turner", "Diaz", "Parker",
  "Cruz", "Edwards", "Collins", "Reyes", "Stewart", "Morris", "Morales", "Murphy",
  "Cook", "Rogers", "Gutierrez", "Ortiz", "Morgan", "Cooper", "Peterson", "Bailey"
];

const courtTypes = [
  "Circuit Court", "District Court", "Municipal Court", "Justice Court", "Family Court"
];

function getRandomElement<T>(array: T[]): T {
  return array[Math.floor(Math.random() * array.length)];
}

function generateRandomFloat(min: number, max: number, decimals: number = 1): number {
  return parseFloat((Math.random() * (max - min) + min).toFixed(decimals));
}

function generateRandomInt(min: number, max: number): number {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function generateRiskLevel(riskScore: number): string {
  if (riskScore >= 85) return "high";
  if (riskScore >= 70) return "moderate";
  if (riskScore >= 50) return "low";
  return "excellent";
}

export async function seedDatabase() {
  console.log("Starting database seeding...");

  // Clear existing data
  await db.delete(judges);
  await db.delete(counties);

  // Create counties data
  const countiesData: InsertCounty[] = oregonCounties.map(countyName => {
    const prisonRate = generateRandomFloat(25, 55);
    const racialDisparity = generateRandomFloat(-8, 25);
    const counselDisparity = generateRandomFloat(5, 30);
    
    // Calculate judges per county (total 246 across 36 counties)
    // Major counties get more judges, smaller ones get fewer
    let judgeCount: number;
    if (["Multnomah", "Washington", "Clackamas", "Marion", "Lane"].includes(countyName)) {
      judgeCount = generateRandomInt(15, 25); // Major counties
    } else if (["Jackson", "Deschutes", "Benton", "Polk", "Yamhill", "Linn"].includes(countyName)) {
      judgeCount = generateRandomInt(8, 15); // Medium counties
    } else {
      judgeCount = generateRandomInt(3, 8); // Smaller counties
    }

    return {
      name: countyName,
      judgeCount,
      prisonRate,
      racialDisparity,
      counselDisparity,
      riskLevel: generateRiskLevel((racialDisparity + counselDisparity + (prisonRate - 35)) * 2)
    };
  });

  // Insert counties
  const insertedCounties = await db.insert(counties).values(countiesData).returning();
  console.log(`Inserted ${insertedCounties.length} counties`);

  // Create judges data
  const judgesData: InsertJudge[] = [];
  let totalJudgesCreated = 0;

  for (const county of insertedCounties) {
    for (let i = 0; i < county.judgeCount; i++) {
      const firstName = getRandomElement(judgeFirstNames);
      const lastName = getRandomElement(judgeLastNames);
      const name = `${firstName} ${lastName}`;
      
      const prisonRate = generateRandomFloat(20, 65);
      const appealRate = generateRandomFloat(8, 25);
      const reversalRate = generateRandomFloat(5, 35);
      const totalCases = generateRandomInt(150, 2500);
      const riskScore = generateRandomFloat(25, 95);

      judgesData.push({
        name,
        county: county.name,
        countyId: county.id,
        court: getRandomElement(courtTypes),
        prisonRate,
        appealRate,
        reversalRate,
        totalCases,
        riskScore,
        riskLevel: generateRiskLevel(riskScore),
        yearsServed: generateRandomInt(2, 25),
        demographics: {
          racialDisparityWhite: generateRandomFloat(-5, 20),
          racialDisparityBlack: generateRandomFloat(-3, 25),
          racialDisparityHispanic: generateRandomFloat(-2, 18),
          genderDisparityMale: generateRandomFloat(-8, 15),
          genderDisparityFemale: generateRandomFloat(-10, 12),
          ageDisparityYoung: generateRandomFloat(-5, 20),
          ageDisparityOld: generateRandomFloat(-8, 15)
        }
      });
      totalJudgesCreated++;
    }
  }

  // If we're short of 246, add more judges to major counties
  while (totalJudgesCreated < 246) {
    const majorCounty = insertedCounties.find(c => 
      ["Multnomah", "Washington", "Clackamas", "Marion", "Lane"].includes(c.name)
    );
    
    if (majorCounty) {
      const firstName = getRandomElement(judgeFirstNames);
      const lastName = getRandomElement(judgeLastNames);
      const name = `${firstName} ${lastName}`;
      
      const prisonRate = generateRandomFloat(20, 65);
      const appealRate = generateRandomFloat(8, 25);
      const reversalRate = generateRandomFloat(5, 35);
      const totalCases = generateRandomInt(150, 2500);
      const riskScore = generateRandomFloat(25, 95);

      judgesData.push({
        name,
        county: majorCounty.name,
        countyId: majorCounty.id,
        court: getRandomElement(courtTypes),
        prisonRate,
        appealRate,
        reversalRate,
        totalCases,
        riskScore,
        riskLevel: generateRiskLevel(riskScore),
        yearsServed: generateRandomInt(2, 25),
        demographics: {
          racialDisparityWhite: generateRandomFloat(-5, 20),
          racialDisparityBlack: generateRandomFloat(-3, 25),
          racialDisparityHispanic: generateRandomFloat(-2, 18),
          genderDisparityMale: generateRandomFloat(-8, 15),
          genderDisparityFemale: generateRandomFloat(-10, 12),
          ageDisparityYoung: generateRandomFloat(-5, 20),
          ageDisparityOld: generateRandomFloat(-8, 15)
        }
      });
      totalJudgesCreated++;
    }
  }

  // Insert judges in batches to avoid potential issues
  const batchSize = 50;
  let insertedJudges = 0;
  
  for (let i = 0; i < judgesData.length; i += batchSize) {
    const batch = judgesData.slice(i, i + batchSize);
    const result = await db.insert(judges).values(batch).returning();
    insertedJudges += result.length;
    console.log(`Inserted batch ${Math.floor(i / batchSize) + 1}: ${result.length} judges`);
  }

  console.log(`Database seeding completed!`);
  console.log(`Total counties: ${insertedCounties.length}`);
  console.log(`Total judges: ${insertedJudges}`);
  
  return {
    counties: insertedCounties.length,
    judges: insertedJudges
  };
}