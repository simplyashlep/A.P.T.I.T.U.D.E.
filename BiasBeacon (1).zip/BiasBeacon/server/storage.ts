import type { InsertUser, User, InsertJudge, Judge, InsertCounty, County, InsertChatSession, ChatSession } from "@shared/schema";
import { users, judges, counties, chatSessions } from "@shared/schema";
import { db } from "./db";
import { eq } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Judge operations
  getJudges(): Promise<Judge[]>;
  getJudge(id: string): Promise<Judge | undefined>;
  getJudgesByCounty(county: string): Promise<Judge[]>;
  createJudge(judge: InsertJudge): Promise<Judge>;
  
  // County operations
  getCounties(): Promise<County[]>;
  getCounty(name: string): Promise<County | undefined>;
  createCounty(county: InsertCounty): Promise<County>;
  
  // Chat operations
  createChatSession(session: InsertChatSession): Promise<ChatSession>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async getJudges(): Promise<Judge[]> {
    return await db.select().from(judges);
  }

  async getJudge(id: string): Promise<Judge | undefined> {
    const [judge] = await db.select().from(judges).where(eq(judges.id, id));
    return judge || undefined;
  }

  async getJudgesByCounty(county: string): Promise<Judge[]> {
    return await db.select().from(judges).where(eq(judges.county, county));
  }

  async createJudge(insertJudge: InsertJudge): Promise<Judge> {
    const [judge] = await db
      .insert(judges)
      .values(insertJudge)
      .returning();
    return judge;
  }

  async getCounties(): Promise<County[]> {
    return await db.select().from(counties);
  }

  async getCounty(name: string): Promise<County | undefined> {
    const [county] = await db.select().from(counties).where(eq(counties.name, name));
    return county || undefined;
  }

  async createCounty(insertCounty: InsertCounty): Promise<County> {
    const [county] = await db
      .insert(counties)
      .values(insertCounty)
      .returning();
    return county;
  }

  async createChatSession(insertChatSession: InsertChatSession): Promise<ChatSession> {
    const [chatSession] = await db
      .insert(chatSessions)
      .values(insertChatSession)
      .returning();
    return chatSession;
  }
}

export const storage = new DatabaseStorage();
