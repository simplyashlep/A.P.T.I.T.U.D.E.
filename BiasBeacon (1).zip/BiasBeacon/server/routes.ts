import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { seedDatabase } from "./seed-data";
import { generateChatResponse, analyzeJudgeBias, generateLegalTemplate } from "./services/openai";
import { z } from "zod";

const chatRequestSchema = z.object({
  message: z.string().min(1),
});

const judgeAnalysisSchema = z.object({
  judgeId: z.string(),
});

const templateRequestSchema = z.object({
  templateType: z.string(),
  details: z.record(z.any()),
});

export async function registerRoutes(app: Express): Promise<Server> {
  // Chat endpoint for AI assistant
  app.post("/api/chat", async (req, res) => {
    try {
      const { message } = chatRequestSchema.parse(req.body);
      
      const response = await generateChatResponse(message);
      
      res.json({ response });
    } catch (error) {
      console.error("Chat error:", error);
      res.status(500).json({ 
        message: "Failed to process chat message",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Judge analysis endpoint
  app.post("/api/analyze-judge", async (req, res) => {
    try {
      const { judgeId } = judgeAnalysisSchema.parse(req.body);
      
      // In a real implementation, fetch judge data from database
      const mockJudgeData = {
        name: "Judge Sarah Williams",
        prisonRate: 42,
        counselDisparity: 18,
        racialDisparity: 12,
        reversalRate: 23
      };
      
      const analysis = await analyzeJudgeBias(mockJudgeData);
      
      res.json(analysis);
    } catch (error) {
      console.error("Judge analysis error:", error);
      res.status(500).json({ 
        message: "Failed to analyze judge",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Template generation endpoint
  app.post("/api/generate-template", async (req, res) => {
    try {
      const { templateType, details } = templateRequestSchema.parse(req.body);
      
      const template = await generateLegalTemplate(templateType, details);
      
      res.json({ template });
    } catch (error) {
      console.error("Template generation error:", error);
      res.status(500).json({ 
        message: "Failed to generate template",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  // Database endpoints for judges and counties
  app.get("/api/judges", async (req, res) => {
    try {
      const { county, court } = req.query;
      let judgesList = await storage.getJudges();
      
      // Apply filters if provided
      if (county && county !== 'all') {
        judgesList = judgesList.filter(judge => judge.county === county);
      }
      if (court && court !== 'all') {
        judgesList = judgesList.filter(judge => judge.court === court);
      }
      
      res.json(judgesList);
    } catch (error) {
      console.error("Judges fetch error:", error);
      res.status(500).json({ message: "Failed to fetch judges" });
    }
  });

  app.get("/api/counties", async (req, res) => {
    try {
      const countiesList = await storage.getCounties();
      res.json(countiesList);
    } catch (error) {
      console.error("Counties fetch error:", error);
      res.status(500).json({ message: "Failed to fetch counties" });
    }
  });

  app.get("/api/judges/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const judge = await storage.getJudge(id);
      
      if (!judge) {
        return res.status(404).json({ message: "Judge not found" });
      }
      
      res.json(judge);
    } catch (error) {
      console.error("Judge fetch error:", error);
      res.status(500).json({ message: "Failed to fetch judge" });
    }
  });

  // Seed database with Oregon data (246 judges across 36 counties)
  app.post("/api/seed", async (req, res) => {
    try {
      console.log("Starting database seeding...");
      const result = await seedDatabase();
      res.json({ 
        message: "Database seeded successfully",
        ...result
      });
    } catch (error) {
      console.error("Error seeding database:", error);
      res.status(500).json({ 
        message: "Failed to seed database",
        error: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
