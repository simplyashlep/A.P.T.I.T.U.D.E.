---
name: aptitude-design
description: Use this skill to generate well-branded interfaces and assets for A.P.T.I.T.U.D.E. (a public-accountability platform for Oregon's justice system — dark, editorial, judicial), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the `readme.md` file within this skill, and explore the other available files
(`styles.css` + `tokens/`, `components/`, `ui_kits/`, `guidelines/`, `assets/`).

If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out
and create static HTML files for the user to view — link `styles.css` for the tokens and
brand utilities, pull icons from Lucide, and use the `assets/` logo + favicon. If working on
production code, copy assets and read the rules here to become an expert in designing with
this brand (dark near-black fields, ivory serif gravitas, a single restrained gold, thin
Lucide icons, slow cinematic motion, no emoji).

The A.P.T.I.T.U.D.E. component API lives on `window.APTITUDEDesignSystem_cff43a` once
`_ds_bundle.js` is loaded (`Button, Badge, Eyebrow, GoldRule, NumeralHeading, StatCounter,
SearchField, PillarCard, JudgeCard`). Each component has a `.prompt.md` with a usage example.

If the user invokes this skill without any other guidance, ask them what they want to build
or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_
production code, depending on the need.
