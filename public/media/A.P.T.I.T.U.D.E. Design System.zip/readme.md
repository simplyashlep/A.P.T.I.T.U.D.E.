# A.P.T.I.T.U.D.E. — Design System

**A Platform Tracking Institutional Transparency Using Data Edification.**

A.P.T.I.T.U.D.E. is a public-accountability platform for Oregon's justice system. It
turns scattered public records — judicial decisions, prosecutor charging data, law-
enforcement STOP data, community-corrections outcomes — into one legible, comparable,
auditable civic surface. Its public face spans nine "wings": **Judiciary, Watchtower**
(prosecutors), **Law Enforcement, Community Corrections, Aptitude Advancement, Bias
Beacon** (the analytics dashboard), **Juris Lab** (document tools), **Community**, and
**About**. Beneath it sits the **Aptitude Brain**, a deterministic legal-reasoning
engine ("auditability before automation").

The brand voice is the product's argument: institutions accepted a public standard, and
this is the mirror that measures them against it. The aesthetic is deliberately
**judicial and editorial** — a dark, near-black field; ivory serif gravitas; a single
restrained gold; long, exacting prose. It reads like a quietly authoritative legal
periodical, not a SaaS dashboard.

> _For research and orientation only — not a substitute for counsel or the official record._

---

## Sources

This system was reverse-engineered from the platform's own premium React/Vite UI and
brand documentation. Explore these to design with higher fidelity:

- **GitHub — `simplyashlep/A.P.T.I.T.U.D.E.`** (branch `claude/judge-bias-beacon-scoring-8qAT3`):
  https://github.com/simplyashlep/A.P.T.I.T.U.D.E.
  - `src/App.css` — the canonical token + utility layer (colors, type, shadows, motifs).
  - `src/components/aptitude/*` — Hero, TopNav, Brand (wordmark + scales logo), PagesGrid
    (the nine flip cards), SearchBar, OregonCounter, Footer.
  - `COLOR-SYSTEM-GUIDE.md`, `STYLE-SYSTEM-IMPLEMENTATION.md` — the palette + page themes.
  - `APTITUDE-BRAIN.md`, `bias-beacon/*.md` — product copy, voice, and the Bias Beacon spec.
  - `improved-judge-card-template.md` — the judge-card structure (risk levels, score, metrics).

> Don't assume the reader has repo access; everything needed to design is captured here.
> Note: the screenshots in the repo show an earlier "legal research instrument / Chambers"
> wording — the **code** (Oregon accountability platform) is the current source of truth and
> what this system follows.

---

## Content Fundamentals

**Voice — institutional, declarative, unhurried.** Short, weighted sentences in the
present tense. It states; it rarely sells. _"Every public institution has a record. Now it
has a mirror." / "An instrument, not a chatbot." / "Behavior becomes data. Data becomes
pattern. Pattern becomes evidence. Evidence becomes accountability."_

**Person.** Addresses the reader as **you** ("We meet you there"); the platform speaks as
**we** sparingly and only about method. The institutions under review are named plainly
(the bench, the office, the agency) — never euphemized.

**Restraint over accusation.** Copy "preserves difference without forcing a story" and is
careful not to claim causation the data can't support. Findings are framed as questions the
record now lets you ask. Hedge words for unknowns are explicit: **Pending**, **Coverage
note**, _"what is uncertain is named uncertain."_

**Casing & punctuation.**
- **Eyebrows / kickers**: UPPERCASE, wide tracking, words joined by a middot " · "
  (`ACCOUNTABILITY IS INFRASTRUCTURE`, `PILLAR I · THE JUDICIARY`).
- **Display headings**: Title or sentence case, often with one **italic gold** clause
  ("Nine wings of one _public record._").
- **Roman numerals** (I, II, III) label principles and tiers. Years and dates render as
  **roman** in chrome (`MMXXVI`).
- The em dash — set with spaces — is the house connector. Trailing periods are sometimes a
  design accent (a small gold dot after each wordmark letter).

**Vocabulary.** "The record," "the bench," "actor records," "Aptitudinal Alignment,"
"pillar," "wing," "evidence chain," "disparity," "pathway." Three-word creeds recur:
_Precision · Principle · Proof_ · _Public · Accountable · Disciplined._

**Emoji: never.** No emoji, ever. No exclamation points. Tone is grave, literate, exact.

---

## Visual Foundations

**Palette.** A near-black navy field (`#070B14` → `#0A0F1A`), warm **ivory** ink
(`#F5F1E6`), one **gold** accent (`#C8A97E`), and a cool **steel** blue (`#5B7B9A`) as the
analytical secondary. Each wing carries its own muted accent (gold, teal, coral, sage,
plum, steel, bronze, blue) — used sparingly, one per card. Bias Beacon risk levels run a
five-stop signal scale (excellent→critical). Color is never loud; the dark field does the
work and the gold is a highlight, not a fill. See `tokens/colors.css`.

**Type.** Three families (`tokens/typography.css`):
- **Playfair Display** — display serif for the wordmark, hero, and big headings (500–700,
  tight tracking, frequent italic clauses).
- **Cormorant Garamond** — editorial serif, almost always *italic*, for taglines, pull
  quotes, captions, and numerals.
- **Outfit** — the working UI sans (weight 300 default), for body, labels, controls, and
  the wide-tracked uppercase eyebrows.

**Backgrounds.** Dark fields with a barely-perceptible, slowly drifting multi-radial
gradient (steel + gold blooms, ~42s loop) for site-wide cohesion. A faint SVG **grain**
overlay (fractal noise, ~0.35 opacity, `overlay` blend) sits on heroes and cards. Vertical
**gold hairline** edge-rules frame the hero. Imagery, when present, is dark, desaturated,
and tinted gold/steel — often masked into letterforms or faded behind content; the scales-
of-justice mark appears as a large, ~5% opacity watermark. No bright photography, no stock.

**Animation.** Slow and cinematic, never bouncy. Signature easing `cubic-bezier(.22,.61,
.36,1)`. Sections fade-and-rise on reveal (~900ms). Numbers count up (~1.4s ease-out). The
search underline draws gold from the center outward on focus (~600ms). Cards flip on the
Y-axis (~650ms). Everything respects `prefers-reduced-motion`.

**Hover & press.** Hover = warm toward gold (borders gold-tint, text ivory→gold, links draw
an underline left-to-right, cards lift ~3px with a gold-tinted shadow). Primary gold pills
lighten to `--accent-hover` on hover. No aggressive scale; press is a quiet settle, not a
shrink-bounce.

**Borders, shadows & glass.** Hairline borders are translucent ivory (`rgba(245,241,230,
.08–.18)`); accents are translucent gold. Shadows are **deep and multi-layered** with an
inner top highlight + inner bottom shade (an "engraved/raised" rim) over long ambient
drops; the elevated state adds a gold-tinted outer glow. Cards are **glass**: translucent
navy + `backdrop-filter: blur(18px) saturate(120%)`, with grain and a top accent line.

**Corners.** Restrained and judicial: **2–6px** is the whole range (`--radius-sm: 4px`
default, `6px` for feature cards). The only fully-round things are gold pill buttons,
status dots, and the score medallions. No large pill cards, no playful rounding.

**Cards.** Translucent glass, 4–6px corners, hairline border with a 2px top accent line
(gold or pillar color), deep layered shadow, optional radial accent bloom in a corner.
Feature cards **flip** to reveal tiered detail. See `.apt-card` and `PillarCard`/`JudgeCard`.

**Layout.** Centered `1360px` max container, generous `clamp(24–40px)` gutters, and large
`~120px` section padding. A fixed glass top nav (`64px`). 3-column grids for the pillar and
principle sets; auto-fill grids for record directories. Whitespace is treated as gravitas —
type is large and breathes.

---

## Iconography

**Lucide is the brand's icon system** (confirmed: the source imports `lucide-react`
throughout — `Gavel, Eye, Shield, Compass, Activity, FlaskConical, Users, Info, TrendingUp,
Landmark, ArrowUpRight, Search, Sparkles`). Icons are **thin-stroke line icons**
(`strokeWidth` ~1.4–1.5, occasionally 2.5 for the nav courthouse), small (13–24px), and
usually gold or ivory-dim. They sit inside circular hairline **medallions** on cards, or
inline before labels. The **scales-of-justice** mark (`assets/scale-logo.svg`) is the lockup
glyph and the watermark.

- **In HTML mocks**, link Lucide from CDN and render `<i data-lucide="gavel">` then call
  `lucide.createIcons()` (see the UI kits). Match the thin stroke and small size.
- **Unicode** is used as light ornament: the middot ` · ` in eyebrows, `↗` / `&rarr;` for
  "enter"/external links, `&rdquo;`/`&ldquo;` for big pull quotes, the gold `.` between
  wordmark letters. **No emoji.** Don't hand-draw SVG icons — use Lucide or copy the scales mark.

Assets in `assets/`: `scale-logo.svg` (gold gradient lockup glyph), `favicon.svg`
(navy tile + gold scales).

---

## Index / Manifest

**Foundations** (`styles.css` → `tokens/`)
- `styles.css` — the one file consumers link (import-only).
- `tokens/fonts.css` — Playfair Display, Cormorant Garamond, Outfit (Google Fonts).
- `tokens/colors.css` — surfaces, ink, gold, steel, pillar accents, signal scale + aliases.
- `tokens/typography.css` — families, display + UI scales, weights, tracking.
- `tokens/spacing.css` — spacing, layout, radius, shadow, blur, motion.
- `tokens/base.css` — resets + brand utilities: `.apt-eyebrow .apt-numeral .apt-gold-rule
  .apt-link .apt-card .apt-wordmark-3d .apt-reveal .apt-grain`.

**Components** — `window.APTITUDEDesignSystem_cff43a`
- `components/core/` — `Button`, `Badge`, `Eyebrow`, `GoldRule`.
- `components/patterns/` — `NumeralHeading`, `StatCounter`, `SearchField`, `PillarCard`,
  `JudgeCard`. (Each has a `.prompt.md` with usage + a JSX example.)

**UI Kits**
- `ui_kits/aptitude-portal/` — the public portal home (Hero, nine pillars, principles, quote).
- `ui_kits/bias-beacon/` — actor records directory + statewide system dashboard.

**Specimen cards** — `guidelines/*.card.html` (the Design System tab: Colors, Type,
Spacing, Brand).

**Other** — `assets/` (logo, favicon), `SKILL.md` (portable skill manifest).

---

## Caveats
- Fonts are served from **Google Fonts** (the brand's actual typefaces); no local files are
  bundled. Swap in self-hosted files if you need offline/embedded use.
- The portal's hero omits the source's clipped background **video** (an uploaded asset in the
  real app); it uses the dark gradient field + grain instead.
- Bias Beacon data and the portal stats are **illustrative samples**, not the live Oregon
  dataset.
