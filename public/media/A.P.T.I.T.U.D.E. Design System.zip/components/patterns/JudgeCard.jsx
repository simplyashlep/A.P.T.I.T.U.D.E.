import React from "react";

const RISK = {
  excellent: { color: "var(--apt-excellent)", label: "Excellent" },
  low: { color: "var(--apt-low)", label: "Low Concern" },
  moderate: { color: "var(--apt-moderate)", label: "Moderate" },
  high: { color: "var(--apt-high)", label: "Elevated" },
  critical: { color: "var(--apt-critical)", label: "Critical" },
};

/**
 * A.P.T.I.T.U.D.E. — JudgeCard (Bias Beacon)
 * Actor record card. Front: name, county, score medallion. Back: profile +
 * bias metrics grid. Flips on click. `riskLevel` drives the accent + score ring.
 */
export function JudgeCard({
  name,
  county,
  role = "Circuit Court Judge",
  score = "—",
  scoreLabel = "Aptitudinal Alignment",
  riskLevel = "moderate",
  term,
  tenure,
  caseload,
  metrics = [],
  onProfile,
  height = 320,
  style = {},
  ...props
}) {
  const [flipped, setFlipped] = React.useState(false);
  const risk = RISK[riskLevel] || RISK.moderate;
  const countyLabel = county && county !== "Statewide" ? `${county} County` : county;

  const face = {
    position: "absolute", inset: 0,
    backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden",
    borderRadius: "var(--radius-sm)", overflow: "hidden",
    background: "rgba(19,26,38,0.72)",
    backdropFilter: "var(--blur-glass)", WebkitBackdropFilter: "var(--blur-glass)",
    border: "1px solid var(--border-subtle)",
    boxShadow: "var(--shadow-lg)",
    padding: 22,
    display: "flex", flexDirection: "column",
  };

  return (
    <div style={{ height, perspective: "1200px", ...style }} {...props}>
      <div
        role="button" tabIndex={0} aria-pressed={flipped}
        onClick={() => setFlipped((v) => !v)}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), setFlipped((v) => !v))}
        style={{
          position: "relative", width: "100%", height: "100%", cursor: "pointer",
          transformStyle: "preserve-3d",
          transition: "transform var(--dur-flip) cubic-bezier(0.23,1,0.32,1)",
          transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
        }}
      >
        {/* FRONT */}
        <div style={{ ...face, alignItems: "center", justifyContent: "center", textAlign: "center", gap: 4 }}>
          <span style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${risk.color}, transparent)` }} />
          <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 23, color: "var(--text-primary)", margin: 0, lineHeight: 1.1 }}>{name}</h3>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.28em", color: "var(--text-muted)", marginBottom: 18 }}>{countyLabel}</div>
          <div style={{
            width: 92, height: 92, borderRadius: "50%", display: "grid", placeItems: "center",
            border: `2px solid ${risk.color}`,
            background: `color-mix(in srgb, ${risk.color} 12%, transparent)`,
            boxShadow: `0 0 28px color-mix(in srgb, ${risk.color} 30%, transparent)`,
          }}>
            <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 34, color: "var(--text-primary)", lineHeight: 1 }}>{score}</span>
          </div>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.3em", color: risk.color, marginTop: 14 }}>{scoreLabel}</div>
          <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 13, color: "var(--text-faint)", marginTop: 16 }}>Flip for the record</div>
        </div>

        {/* BACK */}
        <div style={{ ...face, transform: "rotateY(180deg)", gap: 14 }}>
          <span style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${risk.color}, transparent)` }} />
          <div>
            <h4 style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 18, color: "var(--text-primary)", margin: 0 }}>{name}</h4>
            <div style={{ fontFamily: "var(--font-ui)", fontSize: 11, color: "var(--text-muted)" }}>{countyLabel} · {role}</div>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px 16px" }}>
            {[["Bench Term", term], ["Tenure", tenure], ["Caseload", caseload], ...metrics.map((m) => [m.label, m.value])]
              .filter(([, v]) => v != null)
              .map(([label, value], i) => (
                <div key={i}>
                  <div style={{ fontFamily: "var(--font-ui)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.22em", color: "var(--text-faint)" }}>{label}</div>
                  <div style={{ fontFamily: "var(--font-ui)", fontSize: 15, color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{value}</div>
                </div>
              ))}
          </div>
          <button
            onClick={(e) => { e.stopPropagation(); onProfile && onProfile(); }}
            style={{
              marginTop: "auto", alignSelf: "flex-start",
              display: "inline-flex", alignItems: "center", gap: 7,
              fontFamily: "var(--font-ui)", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.32em",
              color: risk.color, background: "transparent", border: 0, cursor: "pointer",
              borderBottom: `1px solid color-mix(in srgb, ${risk.color} 45%, transparent)`, paddingBottom: 3,
            }}
          >
            Full Profile <span aria-hidden="true">↗</span>
          </button>
        </div>
      </div>
    </div>
  );
}
