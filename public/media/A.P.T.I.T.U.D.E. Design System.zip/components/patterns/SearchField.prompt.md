The hero inquiry bar — soft underline (no pill box) that draws a gold line from the center on focus, with a gold pill submit.

```jsx
<SearchField
  placeholder="Ask the record — a judge, an office, a statute…"
  buttonLabel="Inquire"
  onSubmit={(q) => console.log(q)}
/>
```

Works uncontrolled (read the query from `onSubmit(query)`) or controlled (`value` + `onChange`). Pair above it with a row of muted uppercase suggestion chips and below it with `apt-link` quick queries, per the hero pattern.
