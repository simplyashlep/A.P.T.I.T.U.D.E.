import React from "react";

/**
 * A.P.T.I.T.U.D.E. — SearchField
 * The hero "soft underline" inquiry bar: no pill outline, a single hairline
 * underline that draws gold from the center on focus, plus a gold pill submit.
 * Controlled or uncontrolled.
 */
export function SearchField({
  placeholder = "Search any institution, obligation, statute, or public record…",
  buttonLabel = "Inquire",
  value,
  defaultValue,
  onChange,
  onSubmit,
  style = {},
  ...props
}) {
  const [focused, setFocused] = React.useState(false);

  const submit = (e) => {
    e.preventDefault();
    const v = (e.currentTarget.querySelector("input") || {}).value || "";
    onSubmit && onSubmit(v.trim());
  };

  return (
    <form
      onSubmit={submit}
      style={{
        position: "relative",
        display: "flex",
        alignItems: "center",
        gap: "12px",
        padding: "4px 6px 4px 18px",
        background: focused
          ? "linear-gradient(180deg, rgba(245,241,230,0.05), rgba(245,241,230,0.015))"
          : "linear-gradient(180deg, rgba(245,241,230,0.025), rgba(245,241,230,0.01))",
        borderBottom: "1px solid var(--border-strong)",
        boxShadow: focused ? "0 30px 80px -30px rgba(200,169,126,0.14)" : "none",
        transition: "background var(--dur-base) ease, box-shadow var(--dur-slow) ease",
        ...style,
      }}
      {...props}
    >
      {/* magnifier glyph (inline, stroke) */}
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="var(--accent)" strokeWidth="1.4" style={{ opacity: 0.85, flex: "none" }}>
        <circle cx="11" cy="11" r="7" /><line x1="21" y1="21" x2="16.5" y2="16.5" strokeLinecap="round" />
      </svg>
      <input
        type="text"
        value={value}
        defaultValue={defaultValue}
        onChange={onChange}
        onFocus={() => setFocused(true)}
        onBlur={() => setFocused(false)}
        placeholder={placeholder}
        aria-label="Search the record"
        style={{
          flex: 1,
          minWidth: 0,
          background: "transparent",
          border: 0,
          outline: "none",
          color: "var(--text-primary)",
          fontFamily: "var(--font-ui)",
          fontWeight: 300,
          fontSize: "var(--text-lead)",
          letterSpacing: "0.01em",
          padding: "16px 0",
        }}
      />
      <button
        type="submit"
        style={{
          flex: "none",
          display: "inline-flex",
          alignItems: "center",
          gap: "8px",
          padding: "10px 22px",
          borderRadius: "var(--radius-pill)",
          border: 0,
          background: "var(--accent)",
          color: "var(--text-on-accent)",
          fontFamily: "var(--font-ui)",
          fontWeight: 500,
          fontSize: "10.5px",
          textTransform: "uppercase",
          letterSpacing: "0.32em",
          cursor: "pointer",
          transition: "background var(--dur-fast) ease",
        }}
        onMouseEnter={(e) => (e.currentTarget.style.background = "var(--accent-hover)")}
        onMouseLeave={(e) => (e.currentTarget.style.background = "var(--accent)")}
      >
        {buttonLabel}
      </button>
      {/* center-out gold underline on focus */}
      <span style={{
        position: "absolute", bottom: -1, height: 1,
        left: focused ? 0 : "50%", right: focused ? 0 : "50%",
        background: "linear-gradient(90deg, transparent, var(--accent), transparent)",
        transition: "left var(--dur-slow) var(--ease-out), right var(--dur-slow) var(--ease-out)",
      }} />
    </form>
  );
}
