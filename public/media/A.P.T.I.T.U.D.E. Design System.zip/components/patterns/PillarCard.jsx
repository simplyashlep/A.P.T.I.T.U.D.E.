import React from "react";

/**
 * A.P.T.I.T.U.D.E. — PillarCard
 * The signature flip card from the "Nine wings of one public record" grid.
 * Front: eyebrow, icon medallion, title, description. Back: tiered detail
 * list + an "Enter" link. Click/Enter/Space flips. Themed by `accent`.
 */
export function PillarCard({
  eyebrow,
  title,
  description,
  icon = null,
  tiers = [],
  href = "#",
  enterLabel,
  accent = "var(--accent)",
  accentRgb = "200,169,126",
  height = "clamp(260px, 30vw, 360px)",
  style = {},
  ...props
}) {
  const [flipped, setFlipped] = React.useState(false);
  const rgba = (a) => `rgba(${accentRgb}, ${a})`;

  const face = {
    position: "absolute", inset: 0,
    backfaceVisibility: "hidden", WebkitBackfaceVisibility: "hidden",
    borderRadius: "var(--radius-md)", overflow: "hidden",
    padding: "clamp(18px, 2.2vw, 28px)",
    display: "flex", flexDirection: "column", justifyContent: "space-between",
  };

  return (
    <div style={{ height, perspective: "1200px", ...style }} {...props}>
      <div
        role="button" tabIndex={0} aria-pressed={flipped}
        onClick={() => setFlipped((v) => !v)}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), setFlipped((v) => !v))}
        style={{
          position: "relative", width: "100%", height: "100%", cursor: "pointer",
          transformStyle: "preserve-3d",
          transition: "transform var(--dur-flip) cubic-bezier(0.23,1,0.32,1)",
          transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)",
        }}
      >
        {/* FRONT */}
        <div style={{
          ...face,
          background: "linear-gradient(145deg, #131A26, #0A0F1A)",
          border: `1px solid ${rgba(0.18)}`,
          boxShadow: `var(--shadow-md), inset 0 1px 0 ${rgba(0.12)}`,
        }}>
          <div style={{ position: "absolute", inset: 0, zIndex: 0, background: `radial-gradient(ellipse 70% 60% at 85% 12%, ${rgba(0.2)} 0%, transparent 65%)` }} />
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, zIndex: 1, background: `linear-gradient(90deg, transparent, ${rgba(0.9)} 45%, ${rgba(0.3)})` }} />
          <div style={{ position: "relative", zIndex: 2 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <span style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.36em", color: rgba(0.85) }}>{eyebrow}</span>
              {icon && (
                <span style={{ width: 30, height: 30, borderRadius: "50%", display: "grid", placeItems: "center", border: `1px solid ${rgba(0.3)}`, background: rgba(0.08), color: rgba(0.9) }}>{icon}</span>
              )}
            </div>
            <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "clamp(18px, 2.2vw, 28px)", color: "var(--text-primary)", lineHeight: 1.1, margin: "0 0 8px" }}>{title}</h3>
            <p style={{ fontFamily: "var(--font-ui)", fontWeight: 300, fontSize: 12.5, color: "rgba(245,241,230,0.55)", lineHeight: 1.5, margin: 0 }}>{description}</p>
          </div>
          <div style={{ position: "relative", zIndex: 2, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
            <span style={{ height: 1, width: 28, background: rgba(0.4) }} />
            <span style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.3em", color: "rgba(245,241,230,0.25)" }}>Flip to explore</span>
          </div>
        </div>

        {/* BACK (pre-rotated) */}
        <div style={{
          ...face,
          transform: "rotateY(180deg)",
          border: `1px solid ${rgba(0.3)}`,
          boxShadow: `var(--shadow-md), inset 0 1px 0 ${rgba(0.2)}`,
          background: "linear-gradient(160deg, rgba(10,15,26,0.98), rgba(7,11,20,1))",
        }}>
          <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${rgba(0.9)}, ${rgba(0.15)})` }} />
          <div>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16 }}>
              <span style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.36em", color: rgba(0.85) }}>{title}</span>
              {icon && <span style={{ color: rgba(0.6) }}>{icon}</span>}
            </div>
            <ul style={{ listStyle: "none", padding: 0, margin: 0, display: "flex", flexDirection: "column", gap: 9 }}>
              {tiers.map((t, i) => (
                <li key={i} style={{ borderLeft: `2px solid ${rgba(0.4)}`, paddingLeft: 11 }}>
                  <div style={{ fontFamily: "var(--font-ui)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.32em", color: rgba(0.8), marginBottom: 2 }}>{t.label}</div>
                  <div style={{ fontFamily: "var(--font-ui)", fontWeight: 300, fontSize: 12.5, color: "rgba(245,241,230,0.62)", lineHeight: 1.4 }}>{t.body}</div>
                </li>
              ))}
            </ul>
          </div>
          <a
            href={href}
            onClick={(e) => e.stopPropagation()}
            style={{ display: "inline-flex", alignItems: "center", gap: 6, width: "fit-content", fontFamily: "var(--font-ui)", fontSize: 10, textTransform: "uppercase", letterSpacing: "0.32em", color: rgba(1), textDecoration: "none", borderBottom: `1px solid ${rgba(0.45)}`, paddingBottom: 2 }}
          >
            {enterLabel || `Enter ${title}`}
            <span aria-hidden="true">↗</span>
          </a>
        </div>
      </div>
    </div>
  );
}
