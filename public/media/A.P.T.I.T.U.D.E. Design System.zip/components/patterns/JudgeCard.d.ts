import * as React from "react";

export interface JudgeMetric {
  /** Metric label (e.g. "Prison Usage"). */
  label: string;
  /** Metric value (e.g. "62%", "Pending"). */
  value: React.ReactNode;
}

/**
 * Props for {@link JudgeCard}.
 * @startingPoint section="Bias Beacon" subtitle="Flippable judge / actor record" viewport="320x340"
 */
export interface JudgeCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Actor name. */
  name: string;
  /** County (or "Statewide"). */
  county?: string;
  /** Role title. @default "Circuit Court Judge" */
  role?: string;
  /** Headline score shown in the medallion. @default "—" */
  score?: React.ReactNode;
  /** Score caption. @default "Aptitudinal Alignment" */
  scoreLabel?: string;
  /** Drives accent color + medallion ring + label. @default "moderate" */
  riskLevel?: "excellent" | "low" | "moderate" | "high" | "critical";
  /** Bench term display. */
  term?: string;
  /** Tenure display. */
  tenure?: string;
  /** 2024 caseload display. */
  caseload?: React.ReactNode;
  /** Extra metric rows shown on the back grid. */
  metrics?: JudgeMetric[];
  /** Fired when "Full Profile" is clicked. */
  onProfile?: () => void;
  /** Card height in px. @default 320 */
  height?: number;
}

/**
 * Bias Beacon actor record card. Front: name, county, score medallion ringed
 * by risk color. Back: profile facts + bias-metrics grid + "Full Profile".
 * Click or Enter/Space flips it.
 */
export function JudgeCard(props: JudgeCardProps): React.JSX.Element;
