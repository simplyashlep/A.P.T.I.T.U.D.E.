Large count-up display statistic with an italic serif label — the "Oregon · Did You Know" strip and dashboard KPIs.

```jsx
<StatCounter value={211} label="active judges across 36 Oregon counties" source="Oregon Judicial Dept." />
<StatCounter value={34} suffix="%" label="higher prison usage than peer median" size="md" accent="var(--apt-beacon)" />
```

`prefix`/`suffix` flank the number (suffix is accent-colored). Integers get thousands separators; non-integer `value` shows one decimal. Set `animate={false}` for static contexts. Recolor the unit via `accent` (pillar tokens).
