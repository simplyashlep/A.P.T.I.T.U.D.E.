The flippable "wing" card from the home grid. Front: kicker, icon medallion, title, description. Back: tiered detail list + "Enter" link.

```jsx
import { Gavel } from "lucide-react";

<PillarCard
  eyebrow="Pillar I"
  title="The Judiciary"
  description="Every active, sitting judge in Oregon — 211 across 36 counties."
  icon={<Gavel size={13} strokeWidth={1.5} />}
  href="/judiciary"
  accent="var(--apt-judiciary)"
  accentRgb="200,169,126"
  tiers={[
    { label: "Tier I", body: "Name, county, term, alignment index." },
    { label: "Tier II", body: "Prison usage, reversals, sentencing trends." },
    { label: "Tier III", body: "Full deep dive with peer comparison." },
  ]}
/>
```

Theme each card with a pillar token + matching `accentRgb` (used for tinted glows and borders). Lay out in a 3-column grid with `gap: clamp(12px,1.4vw,20px)`.
