import React from "react";

/**
 * A.P.T.I.T.U.D.E. — StatCounter
 * A large tabular display number that counts up on mount, with an italic
 * serif label and optional source meta. Used in the "Oregon · Did You Know"
 * strip and across dashboards.
 */
export function StatCounter({
  value = 0,
  suffix = "",
  prefix = "",
  label,
  source,
  size = "lg",
  accent = "var(--accent)",
  animate = true,
  style = {},
  ...props
}) {
  const [n, setN] = React.useState(animate ? 0 : value);

  React.useEffect(() => {
    if (!animate) { setN(value); return; }
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) { setN(value); return; }
    let raf;
    const start = performance.now();
    const dur = 1400;
    const tick = (t) => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(value * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, animate]);

  const sizes = {
    sm: "clamp(1.75rem, 3vw, 2.25rem)",
    md: "clamp(2.25rem, 4vw, 3rem)",
    lg: "clamp(2.75rem, 5vw, 3.5rem)",
  };

  const display = Number.isInteger(value) ? Math.round(n).toLocaleString() : n.toFixed(1);

  return (
    <div style={{ ...style }} {...props}>
      <div style={{ display: "flex", alignItems: "baseline", gap: "14px", flexWrap: "wrap" }}>
        <span style={{
          fontFamily: "var(--font-display)",
          fontWeight: 600,
          fontSize: sizes[size],
          color: "var(--text-primary)",
          lineHeight: 1,
          fontVariantNumeric: "tabular-nums",
          letterSpacing: "-0.01em",
        }}>
          {prefix}{display}<span style={{ color: accent }}>{suffix}</span>
        </span>
        {label && (
          <span style={{
            fontFamily: "var(--font-serif)",
            fontStyle: "italic",
            fontSize: "var(--text-lead)",
            color: "var(--text-secondary)",
            lineHeight: 1.3,
            maxWidth: "32ch",
          }}>
            {label}
          </span>
        )}
      </div>
      {source && (
        <div style={{
          marginTop: "10px",
          fontFamily: "var(--font-ui)",
          fontSize: "10px",
          textTransform: "uppercase",
          letterSpacing: "var(--tracking-eyebrow)",
          color: "var(--text-faint)",
        }}>
          {source}
        </div>
      )}
    </div>
  );
}
