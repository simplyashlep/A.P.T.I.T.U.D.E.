import React from "react";

/**
 * A.P.T.I.T.U.D.E. — NumeralHeading
 * The editorial "Roman numeral + eyebrow + display heading" block used on
 * the Principles section and pillar intros. Numeral can be Roman or any string.
 */
export function NumeralHeading({
  numeral,
  eyebrow,
  title,
  body,
  align = "left",
  accent = "var(--accent)",
  style = {},
  ...props
}) {
  return (
    <div style={{ textAlign: align, ...style }} {...props}>
      <div style={{ display: "flex", alignItems: "baseline", gap: "16px", justifyContent: align === "center" ? "center" : "flex-start", marginBottom: "22px" }}>
        {numeral != null && (
          <span style={{
            fontFamily: "var(--font-serif)",
            fontStyle: "italic",
            fontWeight: 300,
            fontSize: "clamp(40px, 5vw, 64px)",
            color: accent,
            lineHeight: 1,
            letterSpacing: "0.02em",
          }}>
            {numeral}
          </span>
        )}
        {eyebrow && (
          <span style={{
            fontFamily: "var(--font-ui)",
            fontSize: "var(--text-eyebrow)",
            textTransform: "uppercase",
            letterSpacing: "var(--tracking-eyebrow)",
            color: "var(--text-muted)",
          }}>
            {eyebrow}
          </span>
        )}
      </div>
      {title && (
        <h2 style={{
          fontFamily: "var(--font-display)",
          fontWeight: 600,
          fontSize: "var(--text-h1)",
          color: "var(--text-primary)",
          lineHeight: 1.1,
          margin: "0 0 14px",
          letterSpacing: "var(--tracking-tight)",
        }}>
          {title}
        </h2>
      )}
      {body && (
        <p style={{
          fontFamily: "var(--font-ui)",
          fontWeight: 300,
          fontSize: "var(--text-body)",
          color: "var(--text-muted)",
          lineHeight: 1.6,
          margin: 0,
          maxWidth: "42ch",
          marginLeft: align === "center" ? "auto" : 0,
          marginRight: align === "center" ? "auto" : 0,
        }}>
          {body}
        </p>
      )}
    </div>
  );
}
