import * as React from "react";

/**
 * Props for {@link SearchField}.
 * @startingPoint section="Patterns" subtitle="Soft-underline inquiry bar" viewport="700x140"
 */
export interface SearchFieldProps extends Omit<React.HTMLAttributes<HTMLFormElement>, "onSubmit" | "onChange"> {
  /** Input placeholder. */
  placeholder?: string;
  /** Submit button label. @default "Inquire" */
  buttonLabel?: string;
  /** Controlled value. */
  value?: string;
  /** Uncontrolled initial value. */
  defaultValue?: string;
  /** Input change handler. */
  onChange?: React.ChangeEventHandler<HTMLInputElement>;
  /** Fires with the trimmed query string on submit. */
  onSubmit?: (query: string) => void;
}

/**
 * The hero "soft underline" inquiry bar — no pill outline, a single hairline
 * that draws gold from the center on focus, with a gold pill submit.
 */
export function SearchField(props: SearchFieldProps): React.JSX.Element;
