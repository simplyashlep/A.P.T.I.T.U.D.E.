Editorial heading block: large italic-gold Roman numeral, tracked eyebrow, Playfair display title, and body copy.

```jsx
<NumeralHeading
  numeral="I"
  eyebrow="Precision"
  title="Precision."
  body="Every answer measured against the controlling rule. What is uncertain is named uncertain."
/>
```

`align="center"` centers everything. `accent` recolors the numeral — pass a pillar token like `var(--apt-watchtower)` to theme per section.
