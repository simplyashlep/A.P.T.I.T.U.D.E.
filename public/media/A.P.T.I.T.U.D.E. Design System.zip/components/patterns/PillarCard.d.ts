import * as React from "react";

export interface PillarTier {
  /** Tier label (e.g. "Tier I", "Statewide"). */
  label: string;
  /** Tier description. */
  body: string;
}

/**
 * Props for {@link PillarCard}.
 * @startingPoint section="Patterns" subtitle="Flippable themed pillar card" viewport="380x340"
 */
export interface PillarCardProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Small tracked kicker (e.g. "Pillar I"). */
  eyebrow?: string;
  /** Card title (e.g. "The Judiciary"). */
  title: string;
  /** Front-face description. */
  description?: string;
  /** Icon node shown in the medallion (Lucide icon recommended). */
  icon?: React.ReactNode;
  /** Tiered detail rows revealed on the back. */
  tiers?: PillarTier[];
  /** Destination for the "Enter" link. @default "#" */
  href?: string;
  /** Override the "Enter {title}" link label. */
  enterLabel?: string;
  /** Accent color for theming. @default gold */
  accent?: string;
  /** Accent as "r,g,b" for tinted glows/borders. @default "200,169,126" */
  accentRgb?: string;
  /** Card height (CSS). @default clamp(260px, 30vw, 360px) */
  height?: string;
}

/**
 * The signature flip card from the "Nine wings of one public record" grid.
 * Front shows eyebrow + icon + title + description; flipping reveals a tiered
 * detail list and an "Enter" link. Click or press Enter/Space to flip.
 */
export function PillarCard(props: PillarCardProps): React.JSX.Element;
