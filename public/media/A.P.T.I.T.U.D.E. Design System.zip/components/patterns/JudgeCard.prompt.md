Bias Beacon actor record card — a flip card whose accent and score ring are driven by `riskLevel`.

```jsx
<JudgeCard
  name="Matthew Shirtcliff"
  county="Marion"
  role="Circuit Court Judge"
  score={72}
  scoreLabel="Aptitudinal Alignment"
  riskLevel="high"
  term="2027"
  tenure="9 yrs"
  caseload="1,240"
  metrics={[
    { label: "Prison Usage", value: "62%" },
    { label: "Reversal Rate", value: "8%" },
    { label: "Counsel Disparity", value: "Notable" },
    { label: "Racial Disparity", value: "Pending" },
  ]}
  onProfile={() => openProfile(id)}
/>
```

`riskLevel`: excellent · low · moderate · high · critical (sets ring + label color). Use `score="Pending"` when unscored. Lay out in a responsive grid (min ~260px columns).
