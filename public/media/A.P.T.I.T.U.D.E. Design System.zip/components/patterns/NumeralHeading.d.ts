import * as React from "react";

/**
 * Props for {@link NumeralHeading}.
 * @startingPoint section="Patterns" subtitle="Numeral + eyebrow + display heading" viewport="700x300"
 */
export interface NumeralHeadingProps extends React.HTMLAttributes<HTMLDivElement> {
  /** Roman numeral or label shown large in italic serif gold (e.g. "I", "II"). */
  numeral?: React.ReactNode;
  /** Small tracked uppercase kicker beside the numeral. */
  eyebrow?: string;
  /** Display heading (Playfair). */
  title?: React.ReactNode;
  /** Supporting body copy. */
  body?: React.ReactNode;
  /** Text alignment. @default "left" */
  align?: "left" | "center";
  /** Numeral color (use a pillar accent token to theme). @default gold */
  accent?: string;
  children?: React.ReactNode;
}

/**
 * Editorial "Roman numeral + eyebrow + display heading + body" block —
 * the layout used for the Principles columns and pillar intros.
 */
export function NumeralHeading(props: NumeralHeadingProps): React.JSX.Element;
