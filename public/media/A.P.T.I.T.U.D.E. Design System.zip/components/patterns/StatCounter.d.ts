import * as React from "react";

export interface StatCounterProps extends React.HTMLAttributes<HTMLDivElement> {
  /** The numeric value (integers count with thousands separators; decimals show one place). */
  value?: number;
  /** Trailing unit shown in accent color (e.g. "%", "k"). */
  suffix?: string;
  /** Leading unit (e.g. "$"). */
  prefix?: string;
  /** Italic serif label beside the number. */
  label?: React.ReactNode;
  /** Small uppercase source/meta line below. */
  source?: string;
  /** Number size. @default "lg" */
  size?: "sm" | "md" | "lg";
  /** Accent color for the suffix (pillar token to theme). @default gold */
  accent?: string;
  /** Count up on mount (respects reduced-motion). @default true */
  animate?: boolean;
}

/**
 * Large tabular display number that counts up on mount, with an italic
 * serif label and optional source meta — the "Oregon · Did You Know"
 * statistic and dashboard KPI pattern.
 *
 * @dsCard
 */
export function StatCounter(props: StatCounterProps): React.JSX.Element;
