import React from "react";

/**
 * A.P.T.I.T.U.D.E. — Button
 * Gold pill primaries, hairline-outline secondaries, quiet ghost/link.
 * Uppercase tracked labels are the brand default for primary/secondary.
 */
export function Button({
  variant = "primary",
  size = "md",
  as = "button",
  icon = null,
  iconRight = null,
  uppercase,
  children,
  style = {},
  ...props
}) {
  const Tag = as;

  const sizes = {
    sm: { padding: "8px 18px", fontSize: "10px", letterSpacing: "0.28em" },
    md: { padding: "11px 26px", fontSize: "10.5px", letterSpacing: "0.32em" },
    lg: { padding: "15px 38px", fontSize: "11px", letterSpacing: "0.34em" },
  };

  // Link variant is lowercase serif-adjacent; others uppercase tracked
  const isLink = variant === "link";
  const wantUpper = uppercase ?? !isLink;

  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "9px",
    fontFamily: "var(--font-ui)",
    fontWeight: 500,
    textTransform: wantUpper ? "uppercase" : "none",
    textDecoration: "none",
    cursor: "pointer",
    border: "1px solid transparent",
    borderRadius: "var(--radius-pill)",
    transition: "all var(--dur-fast) var(--ease-out)",
    whiteSpace: "nowrap",
    ...sizes[size],
  };

  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--text-on-accent)",
      borderColor: "var(--accent)",
    },
    secondary: {
      background: "transparent",
      color: "var(--text-secondary)",
      borderColor: "var(--border-strong)",
    },
    ghost: {
      background: "transparent",
      color: "var(--text-secondary)",
      borderColor: "transparent",
    },
    link: {
      background: "transparent",
      color: "var(--accent)",
      borderColor: "transparent",
      borderRadius: 0,
      borderBottom: "1px solid var(--border-accent)",
      padding: `${size === "sm" ? "2px 0" : "4px 0"}`,
      gap: "7px",
    },
  };

  const hovers = {
    primary: (e, on) => { e.currentTarget.style.background = on ? "var(--accent-hover)" : "var(--accent)"; },
    secondary: (e, on) => {
      e.currentTarget.style.borderColor = on ? "var(--border-accent)" : "var(--border-strong)";
      e.currentTarget.style.color = on ? "var(--text-primary)" : "var(--text-secondary)";
    },
    ghost: (e, on) => { e.currentTarget.style.color = on ? "var(--accent)" : "var(--text-secondary)"; },
    link: (e, on) => { e.currentTarget.style.color = on ? "var(--accent-hover)" : "var(--accent)"; },
  };

  return (
    <Tag
      style={{ ...base, ...variants[variant], ...style }}
      onMouseEnter={(e) => hovers[variant]?.(e, true)}
      onMouseLeave={(e) => hovers[variant]?.(e, false)}
      {...props}
    >
      {icon}
      {children}
      {iconRight}
    </Tag>
  );
}
