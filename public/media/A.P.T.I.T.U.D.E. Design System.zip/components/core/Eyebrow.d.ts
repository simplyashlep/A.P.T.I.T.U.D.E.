import * as React from "react";

export interface EyebrowProps extends React.HTMLAttributes<HTMLElement> {
  /** Color tone. @default "gold" */
  tone?: "gold" | "muted" | "ivory";
  /** Extra-wide tracking (0.42em) for hero kickers. @default false */
  loose?: boolean;
  /** Element to render. @default "span" */
  as?: React.ElementType;
  children?: React.ReactNode;
}

/**
 * The signature uppercase tracked kicker label that precedes most
 * headings ("Accountability Is Infrastructure", "Pillar I").
 *
 * @dsCard
 */
export function Eyebrow(props: EyebrowProps): React.JSX.Element;
