import * as React from "react";

export interface BadgeProps extends React.HTMLAttributes<HTMLSpanElement> {
  /** Treatment. @default "outline" */
  variant?: "outline" | "solid" | "signal";
  /** Risk tone for the "signal" variant (renders a colored dot). @default "neutral" */
  signal?: "excellent" | "low" | "moderate" | "high" | "critical" | "neutral";
  children?: React.ReactNode;
}

/**
 * Small tracked uppercase chips. Use "outline" for taxonomy tags
 * ("Pillar I", "STOP Data"), "signal" for Bias Beacon risk levels,
 * and "solid" for rare gold emphasis.
 *
 * @dsCard
 */
export function Badge(props: BadgeProps): React.JSX.Element;
