import React from "react";

const SIGNAL_COLORS = {
  excellent: "var(--apt-excellent)",
  low: "var(--apt-low)",
  moderate: "var(--apt-moderate)",
  high: "var(--apt-high)",
  critical: "var(--apt-critical)",
  neutral: "var(--text-muted)",
};

/**
 * A.P.T.I.T.U.D.E. — Badge / Tag
 * Small tracked uppercase chips. "outline" for taxonomy tags, "signal"
 * for risk levels (dot + label), "solid" for emphasis.
 */
export function Badge({
  variant = "outline",
  signal = "neutral",
  children,
  style = {},
  ...props
}) {
  const tone = SIGNAL_COLORS[signal] || SIGNAL_COLORS.neutral;

  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "7px",
    fontFamily: "var(--font-ui)",
    fontSize: "9.5px",
    fontWeight: 500,
    textTransform: "uppercase",
    letterSpacing: "0.28em",
    padding: "5px 11px",
    borderRadius: "var(--radius-xs)",
    border: "1px solid transparent",
    lineHeight: 1,
    whiteSpace: "nowrap",
  };

  const variants = {
    outline: {
      color: "var(--text-secondary)",
      borderColor: "var(--border-strong)",
      background: "transparent",
    },
    solid: {
      color: "var(--text-on-accent)",
      background: "var(--accent)",
    },
    signal: {
      color: tone,
      borderColor: tone,
      background: "color-mix(in srgb, " + tone + " 10%, transparent)",
    },
  };

  return (
    <span style={{ ...base, ...variants[variant], ...style }} {...props}>
      {variant === "signal" && (
        <span style={{ width: 6, height: 6, borderRadius: "50%", background: tone, flex: "none" }} />
      )}
      {children}
    </span>
  );
}
