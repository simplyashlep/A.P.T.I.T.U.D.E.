The signature uppercase tracked kicker label above headings and section starts.

```jsx
<Eyebrow>Accountability Is Infrastructure</Eyebrow>
<Eyebrow tone="muted">Pillar I · The Judiciary</Eyebrow>
<Eyebrow loose tone="ivory">Precision · Principle · Proof</Eyebrow>
```

`tone`: gold (default), muted, ivory. `loose` widens tracking to 0.42em for hero kickers. Separate words with " · " (middot) per brand convention.
