import * as React from "react";

/**
 * Props for {@link Button}.
 * @startingPoint section="Core" subtitle="Gold pill, outline, ghost & link" viewport="700x180"
 */
export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** Visual treatment. @default "primary" */
  variant?: "primary" | "secondary" | "ghost" | "link";
  /** Size. @default "md" */
  size?: "sm" | "md" | "lg";
  /** Render as another element/component (e.g. "a"). @default "button" */
  as?: React.ElementType;
  /** Leading icon node (Lucide icon recommended). */
  icon?: React.ReactNode;
  /** Trailing icon node (e.g. ArrowUpRight on "link"). */
  iconRight?: React.ReactNode;
  /** Force uppercase on/off. Defaults: true except for the "link" variant. */
  uppercase?: boolean;
  children?: React.ReactNode;
}

/**
 * Primary call-to-action and supporting buttons for A.P.T.I.T.U.D.E.
 * Gold pill primaries, hairline-outline secondaries, quiet ghost, and an
 * underline "link" for inline actions like "Enter Judiciary →".
 */
export function Button(props: ButtonProps): React.JSX.Element;
