import React from "react";

/**
 * A.P.T.I.T.U.D.E. — GoldRule
 * A centered gold hairline that fades to transparent at both ends.
 * Used as a section divider and under the footer brand block.
 */
export function GoldRule({ width = "100%", style = {}, ...props }) {
  return (
    <hr
      style={{
        height: "1px",
        width,
        border: 0,
        margin: 0,
        background: "linear-gradient(90deg, transparent, var(--border-accent), transparent)",
        ...style,
      }}
      {...props}
    />
  );
}
