import React from "react";

/**
 * A.P.T.I.T.U.D.E. — Eyebrow
 * The brand's signature uppercase tracked kicker label. Gold by default;
 * pass tone="muted" for a quieter meta label.
 */
export function Eyebrow({ tone = "gold", loose = false, as = "span", children, style = {}, ...props }) {
  const Tag = as;
  const colors = {
    gold: "var(--accent)",
    muted: "var(--text-muted)",
    ivory: "var(--text-secondary)",
  };
  return (
    <Tag
      style={{
        fontFamily: "var(--font-ui)",
        fontSize: "var(--text-eyebrow)",
        fontWeight: 400,
        textTransform: "uppercase",
        letterSpacing: loose ? "var(--tracking-eyebrow-loose)" : "var(--tracking-eyebrow)",
        color: colors[tone] || colors.gold,
        display: "inline-block",
        ...style,
      }}
      {...props}
    >
      {children}
    </Tag>
  );
}
