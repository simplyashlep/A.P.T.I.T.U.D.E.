import * as React from "react";

export interface GoldRuleProps extends React.HTMLAttributes<HTMLHRElement> {
  /** CSS width of the rule. @default "100%" */
  width?: string;
}

/**
 * A centered gold hairline that fades to transparent at both ends —
 * the brand's section divider.
 *
 * @dsCard
 */
export function GoldRule(props: GoldRuleProps): React.JSX.Element;
