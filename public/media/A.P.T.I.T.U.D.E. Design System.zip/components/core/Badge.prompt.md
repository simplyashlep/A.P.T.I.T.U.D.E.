Small tracked uppercase chips for tags and risk signals.

```jsx
<Badge>Pillar I</Badge>
<Badge variant="signal" signal="critical">Critical</Badge>
<Badge variant="solid">New</Badge>
```

Variants: `outline` (hairline taxonomy tag), `signal` (colored dot + matching text for Bias Beacon risk levels — pass `signal="excellent|low|moderate|high|critical"`), `solid` (gold fill, dark ink, use sparingly).
