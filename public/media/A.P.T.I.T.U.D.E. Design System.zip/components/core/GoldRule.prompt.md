A centered gold hairline that fades at both ends — the standard section divider.

```jsx
<GoldRule />
<GoldRule width="120px" />
```
