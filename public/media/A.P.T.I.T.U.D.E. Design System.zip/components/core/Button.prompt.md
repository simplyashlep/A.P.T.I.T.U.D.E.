Primary actions and supporting buttons — gold pill primaries, hairline-outline secondaries, quiet ghosts, and an underline "link" for inline navigation.

```jsx
import { ArrowUpRight } from "lucide-react";

<Button variant="primary">Open Actor Records</Button>
<Button variant="secondary">Open Watchtower</Button>
<Button variant="link" iconRight={<ArrowUpRight size={12} />} as="a" href="#">
  Enter Judiciary
</Button>
```

Variants: `primary` (gold pill, dark ink), `secondary` (transparent, hairline border that warms to gold on hover), `ghost` (text-only, gold on hover), `link` (gold underline for inline CTAs — lowercase by default). Sizes: `sm` `md` `lg`. Pass `as="a"` for anchors, `icon`/`iconRight` for Lucide icons. Labels are uppercase + tracked by default (override with `uppercase={false}`).
