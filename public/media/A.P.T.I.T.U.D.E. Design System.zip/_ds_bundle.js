/* @ds-bundle: {"format":3,"namespace":"APTITUDEDesignSystem_cff43a","components":[{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Eyebrow","sourcePath":"components/core/Eyebrow.jsx"},{"name":"GoldRule","sourcePath":"components/core/GoldRule.jsx"},{"name":"JudgeCard","sourcePath":"components/patterns/JudgeCard.jsx"},{"name":"NumeralHeading","sourcePath":"components/patterns/NumeralHeading.jsx"},{"name":"PillarCard","sourcePath":"components/patterns/PillarCard.jsx"},{"name":"SearchField","sourcePath":"components/patterns/SearchField.jsx"},{"name":"StatCounter","sourcePath":"components/patterns/StatCounter.jsx"}],"sourceHashes":{"components/core/Badge.jsx":"ee82a9e6c3b4","components/core/Button.jsx":"56d1c20c7102","components/core/Eyebrow.jsx":"a65b5ae5a3cd","components/core/GoldRule.jsx":"560813d5aae1","components/patterns/JudgeCard.jsx":"c473b017548e","components/patterns/NumeralHeading.jsx":"7245211d79cb","components/patterns/PillarCard.jsx":"bcc24d33dbb8","components/patterns/SearchField.jsx":"abcf39bfe066","components/patterns/StatCounter.jsx":"09e965ace7cd","ui_kits/aptitude-portal/Chrome.jsx":"04c0bb9139db","ui_kits/aptitude-portal/screens.jsx":"754200d22a1a","ui_kits/bias-beacon/screens.jsx":"3c80c48c5446"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.APTITUDEDesignSystem_cff43a = window.APTITUDEDesignSystem_cff43a || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SIGNAL_COLORS = {
  excellent: "var(--apt-excellent)",
  low: "var(--apt-low)",
  moderate: "var(--apt-moderate)",
  high: "var(--apt-high)",
  critical: "var(--apt-critical)",
  neutral: "var(--text-muted)"
};

/**
 * A.P.T.I.T.U.D.E. — Badge / Tag
 * Small tracked uppercase chips. "outline" for taxonomy tags, "signal"
 * for risk levels (dot + label), "solid" for emphasis.
 */
function Badge({
  variant = "outline",
  signal = "neutral",
  children,
  style = {},
  ...props
}) {
  const tone = SIGNAL_COLORS[signal] || SIGNAL_COLORS.neutral;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    gap: "7px",
    fontFamily: "var(--font-ui)",
    fontSize: "9.5px",
    fontWeight: 500,
    textTransform: "uppercase",
    letterSpacing: "0.28em",
    padding: "5px 11px",
    borderRadius: "var(--radius-xs)",
    border: "1px solid transparent",
    lineHeight: 1,
    whiteSpace: "nowrap"
  };
  const variants = {
    outline: {
      color: "var(--text-secondary)",
      borderColor: "var(--border-strong)",
      background: "transparent"
    },
    solid: {
      color: "var(--text-on-accent)",
      background: "var(--accent)"
    },
    signal: {
      color: tone,
      borderColor: tone,
      background: "color-mix(in srgb, " + tone + " 10%, transparent)"
    }
  };
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      ...base,
      ...variants[variant],
      ...style
    }
  }, props), variant === "signal" && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: tone,
      flex: "none"
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A.P.T.I.T.U.D.E. — Button
 * Gold pill primaries, hairline-outline secondaries, quiet ghost/link.
 * Uppercase tracked labels are the brand default for primary/secondary.
 */
function Button({
  variant = "primary",
  size = "md",
  as = "button",
  icon = null,
  iconRight = null,
  uppercase,
  children,
  style = {},
  ...props
}) {
  const Tag = as;
  const sizes = {
    sm: {
      padding: "8px 18px",
      fontSize: "10px",
      letterSpacing: "0.28em"
    },
    md: {
      padding: "11px 26px",
      fontSize: "10.5px",
      letterSpacing: "0.32em"
    },
    lg: {
      padding: "15px 38px",
      fontSize: "11px",
      letterSpacing: "0.34em"
    }
  };

  // Link variant is lowercase serif-adjacent; others uppercase tracked
  const isLink = variant === "link";
  const wantUpper = uppercase ?? !isLink;
  const base = {
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    gap: "9px",
    fontFamily: "var(--font-ui)",
    fontWeight: 500,
    textTransform: wantUpper ? "uppercase" : "none",
    textDecoration: "none",
    cursor: "pointer",
    border: "1px solid transparent",
    borderRadius: "var(--radius-pill)",
    transition: "all var(--dur-fast) var(--ease-out)",
    whiteSpace: "nowrap",
    ...sizes[size]
  };
  const variants = {
    primary: {
      background: "var(--accent)",
      color: "var(--text-on-accent)",
      borderColor: "var(--accent)"
    },
    secondary: {
      background: "transparent",
      color: "var(--text-secondary)",
      borderColor: "var(--border-strong)"
    },
    ghost: {
      background: "transparent",
      color: "var(--text-secondary)",
      borderColor: "transparent"
    },
    link: {
      background: "transparent",
      color: "var(--accent)",
      borderColor: "transparent",
      borderRadius: 0,
      borderBottom: "1px solid var(--border-accent)",
      padding: `${size === "sm" ? "2px 0" : "4px 0"}`,
      gap: "7px"
    }
  };
  const hovers = {
    primary: (e, on) => {
      e.currentTarget.style.background = on ? "var(--accent-hover)" : "var(--accent)";
    },
    secondary: (e, on) => {
      e.currentTarget.style.borderColor = on ? "var(--border-accent)" : "var(--border-strong)";
      e.currentTarget.style.color = on ? "var(--text-primary)" : "var(--text-secondary)";
    },
    ghost: (e, on) => {
      e.currentTarget.style.color = on ? "var(--accent)" : "var(--text-secondary)";
    },
    link: (e, on) => {
      e.currentTarget.style.color = on ? "var(--accent-hover)" : "var(--accent)";
    }
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      ...base,
      ...variants[variant],
      ...style
    },
    onMouseEnter: e => hovers[variant]?.(e, true),
    onMouseLeave: e => hovers[variant]?.(e, false)
  }, props), icon, children, iconRight);
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Eyebrow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A.P.T.I.T.U.D.E. — Eyebrow
 * The brand's signature uppercase tracked kicker label. Gold by default;
 * pass tone="muted" for a quieter meta label.
 */
function Eyebrow({
  tone = "gold",
  loose = false,
  as = "span",
  children,
  style = {},
  ...props
}) {
  const Tag = as;
  const colors = {
    gold: "var(--accent)",
    muted: "var(--text-muted)",
    ivory: "var(--text-secondary)"
  };
  return /*#__PURE__*/React.createElement(Tag, _extends({
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-eyebrow)",
      fontWeight: 400,
      textTransform: "uppercase",
      letterSpacing: loose ? "var(--tracking-eyebrow-loose)" : "var(--tracking-eyebrow)",
      color: colors[tone] || colors.gold,
      display: "inline-block",
      ...style
    }
  }, props), children);
}
Object.assign(__ds_scope, { Eyebrow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Eyebrow.jsx", error: String((e && e.message) || e) }); }

// components/core/GoldRule.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A.P.T.I.T.U.D.E. — GoldRule
 * A centered gold hairline that fades to transparent at both ends.
 * Used as a section divider and under the footer brand block.
 */
function GoldRule({
  width = "100%",
  style = {},
  ...props
}) {
  return /*#__PURE__*/React.createElement("hr", _extends({
    style: {
      height: "1px",
      width,
      border: 0,
      margin: 0,
      background: "linear-gradient(90deg, transparent, var(--border-accent), transparent)",
      ...style
    }
  }, props));
}
Object.assign(__ds_scope, { GoldRule });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/GoldRule.jsx", error: String((e && e.message) || e) }); }

// components/patterns/JudgeCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const RISK = {
  excellent: {
    color: "var(--apt-excellent)",
    label: "Excellent"
  },
  low: {
    color: "var(--apt-low)",
    label: "Low Concern"
  },
  moderate: {
    color: "var(--apt-moderate)",
    label: "Moderate"
  },
  high: {
    color: "var(--apt-high)",
    label: "Elevated"
  },
  critical: {
    color: "var(--apt-critical)",
    label: "Critical"
  }
};

/**
 * A.P.T.I.T.U.D.E. — JudgeCard (Bias Beacon)
 * Actor record card. Front: name, county, score medallion. Back: profile +
 * bias metrics grid. Flips on click. `riskLevel` drives the accent + score ring.
 */
function JudgeCard({
  name,
  county,
  role = "Circuit Court Judge",
  score = "—",
  scoreLabel = "Aptitudinal Alignment",
  riskLevel = "moderate",
  term,
  tenure,
  caseload,
  metrics = [],
  onProfile,
  height = 320,
  style = {},
  ...props
}) {
  const [flipped, setFlipped] = React.useState(false);
  const risk = RISK[riskLevel] || RISK.moderate;
  const countyLabel = county && county !== "Statewide" ? `${county} County` : county;
  const face = {
    position: "absolute",
    inset: 0,
    backfaceVisibility: "hidden",
    WebkitBackfaceVisibility: "hidden",
    borderRadius: "var(--radius-sm)",
    overflow: "hidden",
    background: "rgba(19,26,38,0.72)",
    backdropFilter: "var(--blur-glass)",
    WebkitBackdropFilter: "var(--blur-glass)",
    border: "1px solid var(--border-subtle)",
    boxShadow: "var(--shadow-lg)",
    padding: 22,
    display: "flex",
    flexDirection: "column"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      height,
      perspective: "1200px",
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("div", {
    role: "button",
    tabIndex: 0,
    "aria-pressed": flipped,
    onClick: () => setFlipped(v => !v),
    onKeyDown: e => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), setFlipped(v => !v)),
    style: {
      position: "relative",
      width: "100%",
      height: "100%",
      cursor: "pointer",
      transformStyle: "preserve-3d",
      transition: "transform var(--dur-flip) cubic-bezier(0.23,1,0.32,1)",
      transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...face,
      alignItems: "center",
      justifyContent: "center",
      textAlign: "center",
      gap: 4
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 2,
      background: `linear-gradient(90deg, transparent, ${risk.color}, transparent)`
    }
  }), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 23,
      color: "var(--text-primary)",
      margin: 0,
      lineHeight: 1.1
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.28em",
      color: "var(--text-muted)",
      marginBottom: 18
    }
  }, countyLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      width: 92,
      height: 92,
      borderRadius: "50%",
      display: "grid",
      placeItems: "center",
      border: `2px solid ${risk.color}`,
      background: `color-mix(in srgb, ${risk.color} 12%, transparent)`,
      boxShadow: `0 0 28px color-mix(in srgb, ${risk.color} 30%, transparent)`
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: 34,
      color: "var(--text-primary)",
      lineHeight: 1
    }
  }, score)), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 9.5,
      textTransform: "uppercase",
      letterSpacing: "0.3em",
      color: risk.color,
      marginTop: 14
    }
  }, scoreLabel), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontSize: 13,
      color: "var(--text-faint)",
      marginTop: 16
    }
  }, "Flip for the record")), /*#__PURE__*/React.createElement("div", {
    style: {
      ...face,
      transform: "rotateY(180deg)",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 2,
      background: `linear-gradient(90deg, ${risk.color}, transparent)`
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h4", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: 18,
      color: "var(--text-primary)",
      margin: 0
    }
  }, name), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 11,
      color: "var(--text-muted)"
    }
  }, countyLabel, " \xB7 ", role)), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1fr 1fr",
      gap: "10px 16px"
    }
  }, [["Bench Term", term], ["Tenure", tenure], ["Caseload", caseload], ...metrics.map(m => [m.label, m.value])].filter(([, v]) => v != null).map(([label, value], i) => /*#__PURE__*/React.createElement("div", {
    key: i
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 9,
      textTransform: "uppercase",
      letterSpacing: "0.22em",
      color: "var(--text-faint)"
    }
  }, label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 15,
      color: "var(--text-primary)",
      fontVariantNumeric: "tabular-nums"
    }
  }, value)))), /*#__PURE__*/React.createElement("button", {
    onClick: e => {
      e.stopPropagation();
      onProfile && onProfile();
    },
    style: {
      marginTop: "auto",
      alignSelf: "flex-start",
      display: "inline-flex",
      alignItems: "center",
      gap: 7,
      fontFamily: "var(--font-ui)",
      fontSize: 10,
      textTransform: "uppercase",
      letterSpacing: "0.32em",
      color: risk.color,
      background: "transparent",
      border: 0,
      cursor: "pointer",
      borderBottom: `1px solid color-mix(in srgb, ${risk.color} 45%, transparent)`,
      paddingBottom: 3
    }
  }, "Full Profile ", /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2197")))));
}
Object.assign(__ds_scope, { JudgeCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/JudgeCard.jsx", error: String((e && e.message) || e) }); }

// components/patterns/NumeralHeading.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A.P.T.I.T.U.D.E. — NumeralHeading
 * The editorial "Roman numeral + eyebrow + display heading" block used on
 * the Principles section and pillar intros. Numeral can be Roman or any string.
 */
function NumeralHeading({
  numeral,
  eyebrow,
  title,
  body,
  align = "left",
  accent = "var(--accent)",
  style = {},
  ...props
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      textAlign: align,
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "16px",
      justifyContent: align === "center" ? "center" : "flex-start",
      marginBottom: "22px"
    }
  }, numeral != null && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontWeight: 300,
      fontSize: "clamp(40px, 5vw, 64px)",
      color: accent,
      lineHeight: 1,
      letterSpacing: "0.02em"
    }
  }, numeral), eyebrow && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: "var(--text-eyebrow)",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-eyebrow)",
      color: "var(--text-muted)"
    }
  }, eyebrow)), title && /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: "var(--text-h1)",
      color: "var(--text-primary)",
      lineHeight: 1.1,
      margin: "0 0 14px",
      letterSpacing: "var(--tracking-tight)"
    }
  }, title), body && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 300,
      fontSize: "var(--text-body)",
      color: "var(--text-muted)",
      lineHeight: 1.6,
      margin: 0,
      maxWidth: "42ch",
      marginLeft: align === "center" ? "auto" : 0,
      marginRight: align === "center" ? "auto" : 0
    }
  }, body));
}
Object.assign(__ds_scope, { NumeralHeading });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/NumeralHeading.jsx", error: String((e && e.message) || e) }); }

// components/patterns/PillarCard.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A.P.T.I.T.U.D.E. — PillarCard
 * The signature flip card from the "Nine wings of one public record" grid.
 * Front: eyebrow, icon medallion, title, description. Back: tiered detail
 * list + an "Enter" link. Click/Enter/Space flips. Themed by `accent`.
 */
function PillarCard({
  eyebrow,
  title,
  description,
  icon = null,
  tiers = [],
  href = "#",
  enterLabel,
  accent = "var(--accent)",
  accentRgb = "200,169,126",
  height = "clamp(260px, 30vw, 360px)",
  style = {},
  ...props
}) {
  const [flipped, setFlipped] = React.useState(false);
  const rgba = a => `rgba(${accentRgb}, ${a})`;
  const face = {
    position: "absolute",
    inset: 0,
    backfaceVisibility: "hidden",
    WebkitBackfaceVisibility: "hidden",
    borderRadius: "var(--radius-md)",
    overflow: "hidden",
    padding: "clamp(18px, 2.2vw, 28px)",
    display: "flex",
    flexDirection: "column",
    justifyContent: "space-between"
  };
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      height,
      perspective: "1200px",
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("div", {
    role: "button",
    tabIndex: 0,
    "aria-pressed": flipped,
    onClick: () => setFlipped(v => !v),
    onKeyDown: e => (e.key === "Enter" || e.key === " ") && (e.preventDefault(), setFlipped(v => !v)),
    style: {
      position: "relative",
      width: "100%",
      height: "100%",
      cursor: "pointer",
      transformStyle: "preserve-3d",
      transition: "transform var(--dur-flip) cubic-bezier(0.23,1,0.32,1)",
      transform: flipped ? "rotateY(180deg)" : "rotateY(0deg)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...face,
      background: "linear-gradient(145deg, #131A26, #0A0F1A)",
      border: `1px solid ${rgba(0.18)}`,
      boxShadow: `var(--shadow-md), inset 0 1px 0 ${rgba(0.12)}`
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      inset: 0,
      zIndex: 0,
      background: `radial-gradient(ellipse 70% 60% at 85% 12%, ${rgba(0.2)} 0%, transparent 65%)`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 2,
      zIndex: 1,
      background: `linear-gradient(90deg, transparent, ${rgba(0.9)} 45%, ${rgba(0.3)})`
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 9.5,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      color: rgba(0.85)
    }
  }, eyebrow), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 30,
      height: 30,
      borderRadius: "50%",
      display: "grid",
      placeItems: "center",
      border: `1px solid ${rgba(0.3)}`,
      background: rgba(0.08),
      color: rgba(0.9)
    }
  }, icon)), /*#__PURE__*/React.createElement("h3", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: "clamp(18px, 2.2vw, 28px)",
      color: "var(--text-primary)",
      lineHeight: 1.1,
      margin: "0 0 8px"
    }
  }, title), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 300,
      fontSize: 12.5,
      color: "rgba(245,241,230,0.55)",
      lineHeight: 1.5,
      margin: 0
    }
  }, description)), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "relative",
      zIndex: 2,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      height: 1,
      width: 28,
      background: rgba(0.4)
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 9.5,
      textTransform: "uppercase",
      letterSpacing: "0.3em",
      color: "rgba(245,241,230,0.25)"
    }
  }, "Flip to explore"))), /*#__PURE__*/React.createElement("div", {
    style: {
      ...face,
      transform: "rotateY(180deg)",
      border: `1px solid ${rgba(0.3)}`,
      boxShadow: `var(--shadow-md), inset 0 1px 0 ${rgba(0.2)}`,
      background: "linear-gradient(160deg, rgba(10,15,26,0.98), rgba(7,11,20,1))"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      height: 2,
      background: `linear-gradient(90deg, ${rgba(0.9)}, ${rgba(0.15)})`
    }
  }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      marginBottom: 16
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 9.5,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      color: rgba(0.85)
    }
  }, title), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      color: rgba(0.6)
    }
  }, icon)), /*#__PURE__*/React.createElement("ul", {
    style: {
      listStyle: "none",
      padding: 0,
      margin: 0,
      display: "flex",
      flexDirection: "column",
      gap: 9
    }
  }, tiers.map((t, i) => /*#__PURE__*/React.createElement("li", {
    key: i,
    style: {
      borderLeft: `2px solid ${rgba(0.4)}`,
      paddingLeft: 11
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 9,
      textTransform: "uppercase",
      letterSpacing: "0.32em",
      color: rgba(0.8),
      marginBottom: 2
    }
  }, t.label), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-ui)",
      fontWeight: 300,
      fontSize: 12.5,
      color: "rgba(245,241,230,0.62)",
      lineHeight: 1.4
    }
  }, t.body))))), /*#__PURE__*/React.createElement("a", {
    href: href,
    onClick: e => e.stopPropagation(),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 6,
      width: "fit-content",
      fontFamily: "var(--font-ui)",
      fontSize: 10,
      textTransform: "uppercase",
      letterSpacing: "0.32em",
      color: rgba(1),
      textDecoration: "none",
      borderBottom: `1px solid ${rgba(0.45)}`,
      paddingBottom: 2
    }
  }, enterLabel || `Enter ${title}`, /*#__PURE__*/React.createElement("span", {
    "aria-hidden": "true"
  }, "\u2197")))));
}
Object.assign(__ds_scope, { PillarCard });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/PillarCard.jsx", error: String((e && e.message) || e) }); }

// components/patterns/SearchField.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A.P.T.I.T.U.D.E. — SearchField
 * The hero "soft underline" inquiry bar: no pill outline, a single hairline
 * underline that draws gold from the center on focus, plus a gold pill submit.
 * Controlled or uncontrolled.
 */
function SearchField({
  placeholder = "Search any institution, obligation, statute, or public record…",
  buttonLabel = "Inquire",
  value,
  defaultValue,
  onChange,
  onSubmit,
  style = {},
  ...props
}) {
  const [focused, setFocused] = React.useState(false);
  const submit = e => {
    e.preventDefault();
    const v = (e.currentTarget.querySelector("input") || {}).value || "";
    onSubmit && onSubmit(v.trim());
  };
  return /*#__PURE__*/React.createElement("form", _extends({
    onSubmit: submit,
    style: {
      position: "relative",
      display: "flex",
      alignItems: "center",
      gap: "12px",
      padding: "4px 6px 4px 18px",
      background: focused ? "linear-gradient(180deg, rgba(245,241,230,0.05), rgba(245,241,230,0.015))" : "linear-gradient(180deg, rgba(245,241,230,0.025), rgba(245,241,230,0.01))",
      borderBottom: "1px solid var(--border-strong)",
      boxShadow: focused ? "0 30px 80px -30px rgba(200,169,126,0.14)" : "none",
      transition: "background var(--dur-base) ease, box-shadow var(--dur-slow) ease",
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "var(--accent)",
    strokeWidth: "1.4",
    style: {
      opacity: 0.85,
      flex: "none"
    }
  }, /*#__PURE__*/React.createElement("circle", {
    cx: "11",
    cy: "11",
    r: "7"
  }), /*#__PURE__*/React.createElement("line", {
    x1: "21",
    y1: "21",
    x2: "16.5",
    y2: "16.5",
    strokeLinecap: "round"
  })), /*#__PURE__*/React.createElement("input", {
    type: "text",
    value: value,
    defaultValue: defaultValue,
    onChange: onChange,
    onFocus: () => setFocused(true),
    onBlur: () => setFocused(false),
    placeholder: placeholder,
    "aria-label": "Search the record",
    style: {
      flex: 1,
      minWidth: 0,
      background: "transparent",
      border: 0,
      outline: "none",
      color: "var(--text-primary)",
      fontFamily: "var(--font-ui)",
      fontWeight: 300,
      fontSize: "var(--text-lead)",
      letterSpacing: "0.01em",
      padding: "16px 0"
    }
  }), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    style: {
      flex: "none",
      display: "inline-flex",
      alignItems: "center",
      gap: "8px",
      padding: "10px 22px",
      borderRadius: "var(--radius-pill)",
      border: 0,
      background: "var(--accent)",
      color: "var(--text-on-accent)",
      fontFamily: "var(--font-ui)",
      fontWeight: 500,
      fontSize: "10.5px",
      textTransform: "uppercase",
      letterSpacing: "0.32em",
      cursor: "pointer",
      transition: "background var(--dur-fast) ease"
    },
    onMouseEnter: e => e.currentTarget.style.background = "var(--accent-hover)",
    onMouseLeave: e => e.currentTarget.style.background = "var(--accent)"
  }, buttonLabel), /*#__PURE__*/React.createElement("span", {
    style: {
      position: "absolute",
      bottom: -1,
      height: 1,
      left: focused ? 0 : "50%",
      right: focused ? 0 : "50%",
      background: "linear-gradient(90deg, transparent, var(--accent), transparent)",
      transition: "left var(--dur-slow) var(--ease-out), right var(--dur-slow) var(--ease-out)"
    }
  }));
}
Object.assign(__ds_scope, { SearchField });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/SearchField.jsx", error: String((e && e.message) || e) }); }

// components/patterns/StatCounter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/**
 * A.P.T.I.T.U.D.E. — StatCounter
 * A large tabular display number that counts up on mount, with an italic
 * serif label and optional source meta. Used in the "Oregon · Did You Know"
 * strip and across dashboards.
 */
function StatCounter({
  value = 0,
  suffix = "",
  prefix = "",
  label,
  source,
  size = "lg",
  accent = "var(--accent)",
  animate = true,
  style = {},
  ...props
}) {
  const [n, setN] = React.useState(animate ? 0 : value);
  React.useEffect(() => {
    if (!animate) {
      setN(value);
      return;
    }
    const reduce = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    if (reduce) {
      setN(value);
      return;
    }
    let raf;
    const start = performance.now();
    const dur = 1400;
    const tick = t => {
      const p = Math.min(1, (t - start) / dur);
      const eased = 1 - Math.pow(1 - p, 3);
      setN(value * eased);
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [value, animate]);
  const sizes = {
    sm: "clamp(1.75rem, 3vw, 2.25rem)",
    md: "clamp(2.25rem, 4vw, 3rem)",
    lg: "clamp(2.75rem, 5vw, 3.5rem)"
  };
  const display = Number.isInteger(value) ? Math.round(n).toLocaleString() : n.toFixed(1);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      ...style
    }
  }, props), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "baseline",
      gap: "14px",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: sizes[size],
      color: "var(--text-primary)",
      lineHeight: 1,
      fontVariantNumeric: "tabular-nums",
      letterSpacing: "-0.01em"
    }
  }, prefix, display, /*#__PURE__*/React.createElement("span", {
    style: {
      color: accent
    }
  }, suffix)), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontSize: "var(--text-lead)",
      color: "var(--text-secondary)",
      lineHeight: 1.3,
      maxWidth: "32ch"
    }
  }, label)), source && /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: "10px",
      fontFamily: "var(--font-ui)",
      fontSize: "10px",
      textTransform: "uppercase",
      letterSpacing: "var(--tracking-eyebrow)",
      color: "var(--text-faint)"
    }
  }, source));
}
Object.assign(__ds_scope, { StatCounter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/patterns/StatCounter.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aptitude-portal/Chrome.jsx
try { (() => {
/* A.P.T.I.T.U.D.E. portal — TopNav + Footer chrome (product surfaces).
   Exposed on window for the inline page script. */

const NAV_LINKS = [{
  label: "Judiciary",
  desc: "Every sitting judge in Oregon — identity, metrics, and Aptitudinal Alignment."
}, {
  label: "Watchtower",
  desc: "Prosecutors by office and individual — charging tendencies and disparity."
}, {
  label: "Law Enforcement",
  desc: "Every officer in Oregon — searchable by agency, rank, and record."
}, {
  label: "Community Corrections",
  desc: "Parole and probation officers by county — caseloads and outcomes."
}, {
  label: "Aptitude Advancement",
  desc: "Where the connection is made — financial access and the path forward.",
  gold: true
}, {
  label: "Bias Beacon",
  desc: "The dashboard. STOP data, conviction rates, heat maps, and budget flow."
}, {
  label: "Juris Lab",
  desc: "Upload documents. AI agents analyze, inform, draft, and surface comparable cases."
}, {
  label: "Community",
  desc: "Public comment, statewide meetings, complaint pathways, and groups."
}, {
  label: "About",
  desc: "The founders, the methodology, and why we built this."
}];
function Wordmark({
  size = 22
}) {
  const dot = {
    color: "var(--accent)"
  };
  const L = "APTITUDE".split("");
  return /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 600,
      fontSize: size,
      letterSpacing: "0.22em",
      color: "var(--text-primary)",
      display: "inline-flex",
      alignItems: "baseline"
    }
  }, L.map((l, i) => /*#__PURE__*/React.createElement("span", {
    key: i
  }, l, /*#__PURE__*/React.createElement("span", {
    style: dot
  }, "."))));
}
function TopNav() {
  const [open, setOpen] = React.useState(false);
  return /*#__PURE__*/React.createElement("nav", {
    style: {
      position: "fixed",
      top: 0,
      left: 0,
      right: 0,
      zIndex: 50,
      background: "rgba(10,15,26,0.6)",
      backdropFilter: "var(--blur-nav)",
      WebkitBackdropFilter: "var(--blur-nav)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container)",
      margin: "0 auto",
      padding: "0 var(--gutter)",
      height: "var(--nav-height)",
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("a", {
    href: "#top",
    style: {
      textDecoration: "none"
    }
  }, /*#__PURE__*/React.createElement(Wordmark, null)), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      color: "rgba(140,147,163,0.5)",
      marginTop: 2
    }
  }, "Accountability Is Infrastructure \xB7 MMXXVI")), /*#__PURE__*/React.createElement("button", {
    onClick: () => setOpen(o => !o),
    "aria-label": "Menu",
    className: "nav-medallion",
    style: {
      width: 44,
      height: 44,
      borderRadius: 6,
      display: "grid",
      placeItems: "center",
      cursor: "pointer",
      background: "linear-gradient(180deg, rgba(200,169,126,0.08), rgba(200,169,126,0.03))",
      border: 0,
      boxShadow: "0 1px 0 rgba(255,255,255,0.06) inset, 0 6px 18px rgba(0,0,0,0.55), 0 0 24px rgba(200,169,126,0.1)"
    }
  }, /*#__PURE__*/React.createElement("i", {
    "data-lucide": "landmark",
    style: {
      width: 22,
      height: 22,
      color: open ? "var(--accent)" : "var(--text-secondary)"
    }
  }))), open && /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      top: "var(--nav-height)",
      left: 0,
      right: 0,
      background: "rgba(10,15,26,0.97)",
      backdropFilter: "var(--blur-nav)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container)",
      margin: "0 auto",
      padding: "32px var(--gutter)",
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 4
    }
  }, NAV_LINKS.map(l => /*#__PURE__*/React.createElement("a", {
    key: l.label,
    href: "#",
    onClick: e => {
      e.preventDefault();
      setOpen(false);
    },
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 4,
      padding: "16px",
      borderRadius: 4,
      textDecoration: "none",
      border: l.gold ? "1px solid rgba(200,169,126,0.25)" : "1px solid transparent",
      background: l.gold ? "rgba(200,169,126,0.04)" : "transparent",
      transition: "background var(--dur-fast) ease"
    },
    onMouseEnter: e => e.currentTarget.style.background = "rgba(200,169,126,0.06)",
    onMouseLeave: e => e.currentTarget.style.background = l.gold ? "rgba(200,169,126,0.04)" : "transparent"
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      fontWeight: 500,
      color: l.gold ? "var(--accent)" : "var(--text-primary)"
    }
  }, l.label), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 12,
      color: "var(--text-muted)",
      lineHeight: 1.45
    }
  }, l.desc))))));
}
function Footer() {
  const {
    GoldRule
  } = window.APTITUDEDesignSystem_cff43a;
  const links = ["Judiciary", "Watchtower", "Law Enforcement", "Corrections", "Aptitude Advancement", "Bias Beacon", "Juris Lab", "Community", "About"];
  return /*#__PURE__*/React.createElement("footer", {
    style: {
      borderTop: "1px solid var(--border-subtle)",
      padding: "56px var(--gutter)",
      position: "relative"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container)",
      margin: "0 auto"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      justifyContent: "space-between",
      gap: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 440
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12,
      marginBottom: 18
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/scale-logo.svg",
    width: "28",
    height: "28",
    alt: ""
  }), /*#__PURE__*/React.createElement(Wordmark, {
    size: 16
  })), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      color: "var(--text-secondary)",
      fontSize: 16,
      lineHeight: 1.6,
      margin: 0
    }
  }, "Accountability Pathways Through Institutional Transparency, Understanding, and Data Ecosystems \u2014 measuring what public institutions promised against what the record shows."), /*#__PURE__*/React.createElement("p", {
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      color: "var(--text-muted)",
      marginTop: 16
    }
  }, "Precision \xB7 Principle \xB7 Proof")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, auto)",
      gap: "12px 48px"
    }
  }, links.map(l => /*#__PURE__*/React.createElement("a", {
    key: l,
    className: "apt-link",
    style: {
      fontSize: 11.5,
      textTransform: "uppercase",
      letterSpacing: "0.28em"
    },
    href: "#"
  }, l)))), /*#__PURE__*/React.createElement(GoldRule, {
    style: {
      margin: "40px 0"
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      justifyContent: "space-between",
      gap: 16,
      fontSize: 10.5,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      color: "var(--text-muted)"
    }
  }, /*#__PURE__*/React.createElement("span", null, "\xA9 MMXXVI \u2014 A.P.T.I.T.U.D.E. \xB7 Oregon"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      textTransform: "none",
      letterSpacing: "normal",
      color: "var(--text-secondary)",
      fontSize: 14
    }
  }, "For research and orientation only \u2014 not a substitute for counsel or the official record."), /*#__PURE__*/React.createElement("span", null, "Public \xB7 Accountable \xB7 Disciplined"))));
}
Object.assign(window, {
  TopNav,
  Footer,
  Wordmark,
  NAV_LINKS
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aptitude-portal/Chrome.jsx", error: String((e && e.message) || e) }); }

// ui_kits/aptitude-portal/screens.jsx
try { (() => {
/* A.P.T.I.T.U.D.E. portal — page sections. Composes the design-system bundle. */
const DS = window.APTITUDEDesignSystem_cff43a;
const {
  Button,
  Eyebrow,
  GoldRule,
  NumeralHeading,
  StatCounter,
  SearchField,
  PillarCard
} = DS;
const FACTS = [{
  value: 211,
  label: "active circuit judges across 36 Oregon counties"
}, {
  value: 34,
  suffix: "%",
  label: "wider counsel disparity in the highest-flagged counties"
}, {
  value: 1240,
  label: "appellate reversals logged and traced to the bench since 2019"
}];
function Hero() {
  const [fact, setFact] = React.useState(0);
  React.useEffect(() => {
    const id = setInterval(() => setFact(f => (f + 1) % FACTS.length), 5200);
    return () => clearInterval(id);
  }, []);
  const L = "APTITUDE".split("");
  const f = FACTS[fact];
  return /*#__PURE__*/React.createElement("section", {
    id: "top",
    className: "apt-grain",
    style: {
      position: "relative",
      minHeight: "100svh",
      display: "flex",
      flexDirection: "column",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      left: "var(--gutter)",
      top: 96,
      bottom: 160,
      width: 1,
      background: "linear-gradient(to bottom, transparent, rgba(200,169,126,0.22) 25%, rgba(200,169,126,0.22) 75%, transparent)",
      zIndex: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      position: "absolute",
      right: "var(--gutter)",
      top: 96,
      bottom: 160,
      width: 1,
      background: "linear-gradient(to bottom, transparent, rgba(200,169,126,0.22) 25%, rgba(200,169,126,0.22) 75%, transparent)",
      zIndex: 2
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "section",
    style: {
      position: "relative",
      zIndex: 3,
      flex: 1,
      display: "flex",
      flexDirection: "column",
      justifyContent: "center",
      paddingTop: 120,
      paddingBottom: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: 1000
    }
  }, /*#__PURE__*/React.createElement("h1", {
    className: "apt-wordmark-3d",
    style: {
      fontFamily: "var(--font-display)",
      fontWeight: 700,
      fontSize: "var(--text-hero)",
      letterSpacing: "0.16em",
      margin: 0,
      display: "flex",
      flexWrap: "wrap"
    }
  }, L.map((l, i) => /*#__PURE__*/React.createElement("span", {
    key: i
  }, l, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      opacity: 0.7,
      WebkitTextFillColor: "var(--accent)",
      margin: "0 0.02em"
    }
  }, ".")))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontSize: 16,
      color: "var(--text-secondary)",
      letterSpacing: "0.06em",
      marginTop: 26
    }
  }, "Accountability\xA0Pathways \xB7 Through \xB7 Institutional \xB7 Transparency \xB7 Understanding \xB7 and \xB7 Data \xB7 Ecosystems"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontSize: "clamp(26px,3vw,34px)",
      color: "var(--text-primary)",
      fontStyle: "italic",
      lineHeight: 1.25,
      marginTop: 36
    }
  }, "Every public institution has a record", /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)"
    }
  }, "."), /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-secondary)",
      fontSize: "0.8em"
    }
  }, "Now it has a mirror.")), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 40
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 24,
      marginBottom: 16,
      fontSize: 10.5,
      textTransform: "uppercase",
      letterSpacing: "0.32em",
      color: "var(--text-muted)",
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("span", null, "Any institution \u2014 court, agency, creditor, or officer"), /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--accent)",
      opacity: 0.6
    }
  }, "\xB7"), /*#__PURE__*/React.createElement("span", null, "A statute, rule, or public record")), /*#__PURE__*/React.createElement(SearchField, {
    placeholder: "Search any institution, obligation, statute, or public record\u2026"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexWrap: "wrap",
      gap: "10px 28px",
      marginTop: 22
    }
  }, ["Aptitudinal Alignment — what it measures", "Oregon STOP data", "Court financial obligations", "DPSST certification"].map(s => /*#__PURE__*/React.createElement("a", {
    key: s,
    className: "apt-link",
    href: "#",
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.18em"
    }
  }, s)))))), /*#__PURE__*/React.createElement("div", {
    style: {
      borderTop: "1px solid var(--border-subtle)",
      position: "relative",
      zIndex: 3
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "section",
    style: {
      padding: "26px var(--gutter)",
      display: "flex",
      alignItems: "center",
      gap: 40,
      flexWrap: "wrap"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      width: 6,
      height: 6,
      borderRadius: "50%",
      background: "var(--accent)"
    }
  }), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 10.5,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      color: "var(--accent)"
    }
  }, "Oregon \xB7 Did You Know")), /*#__PURE__*/React.createElement(StatCounter, {
    key: fact,
    value: f.value,
    suffix: f.suffix || "",
    label: f.label,
    size: "md"
  }))));
}
const PILLARS = [{
  eyebrow: "Pillar I",
  title: "The Judiciary",
  icon: "gavel",
  accent: "var(--apt-judiciary)",
  rgb: "200,169,126",
  description: "Every active, sitting judge in Oregon — 211 across 36 counties — with Aptitudinal Alignment indexed.",
  tiers: [{
    label: "Tier I",
    body: "Name, county, term, alignment index."
  }, {
    label: "Tier II",
    body: "Prison usage, reversals, sentencing trends."
  }, {
    label: "Tier III",
    body: "Deep dive with peer comparison."
  }]
}, {
  eyebrow: "Pillar II",
  title: "The Watchtower",
  icon: "eye",
  accent: "var(--apt-watchtower)",
  rgb: "124,191,176",
  description: "Prosecutors — by office, then by individual DA and DDA. Charging patterns laid bare.",
  tiers: [{
    label: "Tier I",
    body: "Office, position, caseload, charging."
  }, {
    label: "Tier II",
    body: "Plea ratios, dismissals, enhancements."
  }, {
    label: "Tier III",
    body: "Disparity by demographic and peer set."
  }]
}, {
  eyebrow: "The Dashboard",
  title: "Bias Beacon",
  icon: "activity",
  accent: "var(--apt-beacon)",
  rgb: "212,149,106",
  description: "Oregon STOP data, conviction rates, sentencing disparity heat maps, and the money flow of justice.",
  tiers: [{
    label: "Statewide",
    body: "County disparity vs. national baselines."
  }, {
    label: "Spatial",
    body: "Heat maps of hot spots; 3D charts."
  }, {
    label: "Budget",
    body: "The money center of justice."
  }]
}, {
  eyebrow: "The Connection",
  title: "Aptitude Advancement",
  icon: "trending-up",
  accent: "var(--apt-advancement)",
  rgb: "124,168,139",
  description: "Where the gap closes. Financial access, open payment infrastructure, and the path forward.",
  tiers: [{
    label: "Entry",
    body: "Name your starting point. We meet you there."
  }, {
    label: "Connection",
    body: "Matched resources and access pathways."
  }, {
    label: "Action",
    body: "Specific next steps and legal rights."
  }]
}, {
  eyebrow: "Your Tools",
  title: "Juris Lab",
  icon: "flask-conical",
  accent: "var(--apt-jurislab)",
  rgb: "155,143,212",
  description: "Upload your documents. Four agents analyze, research, inform, and co-draft — nothing is filed for you.",
  tiers: [{
    label: "Analyze",
    body: "Document intake and structured summary."
  }, {
    label: "Draft",
    body: "Letters and motions — co-written, never auto-filed."
  }, {
    label: "Library",
    body: "Shared templates and caselaw."
  }]
}, {
  eyebrow: "Pillar III",
  title: "Law Enforcement",
  icon: "shield",
  accent: "var(--apt-enforcement)",
  rgb: "91,123,154",
  description: "Every officer in Oregon — searchable by agency, rank, DPSST certification, and STOP-data record.",
  tiers: [{
    label: "Tier I",
    body: "Agency, rank, sworn date, certifications."
  }, {
    label: "Tier II",
    body: "Stop outcomes, force events, complaints."
  }, {
    label: "Tier III",
    body: "STOP-data demographic breakdown."
  }]
}, {
  eyebrow: "Pillar IV",
  title: "Community Corrections",
  icon: "compass",
  accent: "var(--apt-corrections)",
  rgb: "196,133,90",
  description: "Every parole and probation officer in Oregon — caseloads, revocation rates, and outcome disparity.",
  tiers: [{
    label: "Tier I",
    body: "County, caseload, supervision specialty."
  }, {
    label: "Tier II",
    body: "Revocation, sanction, completion rates."
  }, {
    label: "Tier III",
    body: "Outcome disparity by demographic."
  }]
}, {
  eyebrow: "The Record-Keepers",
  title: "About",
  icon: "info",
  accent: "var(--apt-gold-deep)",
  rgb: "168,137,95",
  description: "The founders, the Aptitudinal Alignment methodology, and why public accountability is infrastructure.",
  tiers: [{
    label: "Founders",
    body: "Who built this and why."
  }, {
    label: "Method",
    body: "How alignment is calculated and verified."
  }, {
    label: "Sources",
    body: "Every dataset, every refresh, every gap."
  }]
}, {
  eyebrow: "The Commons",
  title: "Community",
  icon: "users",
  accent: "var(--apt-community)",
  rgb: "107,143,175",
  description: "Public comment, statewide meetings, agency contacts, complaint pathways, and people navigating the system.",
  tiers: [{
    label: "Voice",
    body: "Public comment and meeting calendars."
  }, {
    label: "Paths",
    body: "Step-by-step complaint pathways."
  }, {
    label: "Groups",
    body: "Spaces to compare experience."
  }]
}];
function PillarsSection() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      padding: "120px 0"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "section"
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      flexWrap: "wrap",
      gap: 24,
      alignItems: "baseline",
      marginBottom: 64
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, null, "Accountability Is Infrastructure"), /*#__PURE__*/React.createElement("h2", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-d1)",
      color: "var(--text-primary)",
      lineHeight: 1.05,
      margin: "16px 0 0",
      fontWeight: 600
    }
  }, "Nine wings of one", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: "italic",
      color: "var(--accent)"
    }
  }, "public record."))), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontSize: 19,
      color: "var(--text-secondary)",
      maxWidth: 420,
      lineHeight: 1.5
    }
  }, "Every institution that operates in public accepted a standard. Each card is a door into how well they are keeping it. Flip to see what is behind.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: "clamp(12px,1.4vw,20px)"
    }
  }, PILLARS.map(p => /*#__PURE__*/React.createElement(PillarCard, {
    key: p.title,
    eyebrow: p.eyebrow,
    title: p.title,
    description: p.description,
    accent: p.accent,
    accentRgb: p.rgb,
    tiers: p.tiers,
    icon: /*#__PURE__*/React.createElement("i", {
      "data-lucide": p.icon,
      style: {
        width: 13,
        height: 13
      }
    })
  })))));
}
function PrinciplesSection() {
  const cols = [{
    n: "I",
    eyebrow: "Precision",
    title: "Precision.",
    body: "Every answer measured against the controlling rule. We resist the soft language of guesswork; what is uncertain is named uncertain."
  }, {
    n: "II",
    eyebrow: "Principle",
    title: "Principle.",
    body: "Doctrine over disposition. The reasoning is shown — statutes, canons, and the architecture of a holding — not concealed behind confidence."
  }, {
    n: "III",
    eyebrow: "Proof",
    title: "Proof.",
    body: "Authority is the closing argument. We point to the cases, codes, and frameworks that bear the weight, so your work can rest on them."
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: {
      padding: "40px 0 120px"
    }
  }, /*#__PURE__*/React.createElement("div", {
    className: "section"
  }, /*#__PURE__*/React.createElement(GoldRule, {
    style: {
      marginBottom: 80
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(3, 1fr)",
      gap: 56
    }
  }, cols.map(c => /*#__PURE__*/React.createElement(NumeralHeading, {
    key: c.n,
    numeral: c.n,
    eyebrow: c.eyebrow,
    title: c.title,
    body: c.body
  })))));
}
function QuoteSection() {
  return /*#__PURE__*/React.createElement("section", {
    style: {
      position: "relative",
      padding: "120px 0",
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/scale-logo.svg",
    alt: "",
    style: {
      position: "absolute",
      width: 480,
      opacity: 0.05,
      left: "50%",
      top: "50%",
      transform: "translate(-50%,-50%)",
      pointerEvents: "none"
    }
  }), /*#__PURE__*/React.createElement("div", {
    className: "section",
    style: {
      position: "relative",
      textAlign: "center",
      maxWidth: 920
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 40,
      color: "var(--accent)",
      opacity: 0.5,
      lineHeight: 0.5
    }
  }, "\u201D"), /*#__PURE__*/React.createElement("blockquote", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "clamp(34px,5vw,58px)",
      color: "var(--text-primary)",
      lineHeight: 1.12,
      margin: "20px 0 28px",
      fontWeight: 600
    }
  }, "\u201CLaw is reason,", /*#__PURE__*/React.createElement("br", null), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      color: "var(--accent)"
    }
  }, "free from passion.\u201D")), /*#__PURE__*/React.createElement("div", {
    style: {
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.36em",
      color: "var(--text-muted)"
    }
  }, "Aristotle \xB7 Politics, Book III"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontSize: 19,
      color: "var(--text-secondary)",
      maxWidth: 620,
      margin: "48px auto 0",
      lineHeight: 1.5
    }
  }, "A.P.T.I.T.U.D.E. exists for the moment between a question and a brief \u2014 when reason must do the steady work of taking sides for principle.")));
}
Object.assign(window, {
  Hero,
  PillarsSection,
  PrinciplesSection,
  QuoteSection
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/aptitude-portal/screens.jsx", error: String((e && e.message) || e) }); }

// ui_kits/bias-beacon/screens.jsx
try { (() => {
/* Bias Beacon — actor directory + system dashboard. Composes the DS bundle. */
const BB = window.APTITUDEDesignSystem_cff43a;
const JUDGES = [{
  name: "Matthew Shirtcliff",
  county: "Marion",
  score: 71,
  risk: "high",
  term: "2027",
  tenure: "9 yrs",
  caseload: "1,240",
  prison: "62%",
  reversal: "8%",
  counsel: "Notable"
}, {
  name: "Jeffrey Jones",
  county: "Lane",
  score: 84,
  risk: "low",
  term: "2026",
  tenure: "14 yrs",
  caseload: "980",
  prison: "41%",
  reversal: "3%",
  counsel: "Minimal"
}, {
  name: "Cheryl Pellegrini",
  county: "Multnomah",
  score: 58,
  risk: "critical",
  term: "2028",
  tenure: "6 yrs",
  caseload: "1,510",
  prison: "70%",
  reversal: "12%",
  counsel: "Severe"
}, {
  name: "Daniel Harris",
  county: "Washington",
  score: 90,
  risk: "excellent",
  term: "2025",
  tenure: "21 yrs",
  caseload: "760",
  prison: "33%",
  reversal: "2%",
  counsel: "Minimal"
}, {
  name: "Patricia Sullivan",
  county: "Clackamas",
  score: 76,
  risk: "moderate",
  term: "2027",
  tenure: "11 yrs",
  caseload: "1,090",
  prison: "48%",
  reversal: "6%",
  counsel: "Moderate"
}, {
  name: "Robert Ahn",
  county: "Multnomah",
  score: 64,
  risk: "high",
  term: "2029",
  tenure: "4 yrs",
  caseload: "1,330",
  prison: "59%",
  reversal: "9%",
  counsel: "Notable"
}, {
  name: "Linda Okafor",
  county: "Lane",
  score: 88,
  risk: "excellent",
  term: "2026",
  tenure: "17 yrs",
  caseload: "640",
  prison: "29%",
  reversal: "1%",
  counsel: "Minimal"
}, {
  name: "Gregory Mills",
  county: "Marion",
  score: 53,
  risk: "critical",
  term: "2028",
  tenure: "8 yrs",
  caseload: "1,420",
  prison: "74%",
  reversal: "14%",
  counsel: "Severe"
}, {
  name: "Susan Vargas",
  county: "Deschutes",
  score: 79,
  risk: "moderate",
  term: "2025",
  tenure: "13 yrs",
  caseload: "870",
  prison: "45%",
  reversal: "5%",
  counsel: "Moderate"
}, {
  name: "Thomas Reed",
  county: "Washington",
  score: 67,
  risk: "high",
  term: "2027",
  tenure: "7 yrs",
  caseload: "1,180",
  prison: "57%",
  reversal: "10%",
  counsel: "Notable"
}, {
  name: "Angela Brooks",
  county: "Clackamas",
  score: 82,
  risk: "low",
  term: "2029",
  tenure: "15 yrs",
  caseload: "910",
  prison: "38%",
  reversal: "4%",
  counsel: "Minimal"
}, {
  name: "David Whitfield",
  county: "Deschutes",
  score: 60,
  risk: "critical",
  term: "2026",
  tenure: "5 yrs",
  caseload: "1,360",
  prison: "68%",
  reversal: "11%",
  counsel: "Severe"
}];
const COUNTIES = ["All counties", ...Array.from(new Set(JUDGES.map(j => j.county))).sort()];
const RISKS = ["All levels", "excellent", "low", "moderate", "high", "critical"];
function Header({
  tab,
  setTab
}) {
  const L = "APTITUDE".split("");
  return /*#__PURE__*/React.createElement("header", {
    style: {
      position: "sticky",
      top: 0,
      zIndex: 40,
      background: "rgba(10,15,26,0.7)",
      backdropFilter: "var(--blur-nav)",
      WebkitBackdropFilter: "var(--blur-nav)",
      borderBottom: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container)",
      margin: "0 auto",
      padding: "0 var(--gutter)",
      height: 64,
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: 24
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 14
    }
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/scale-logo.svg",
    width: "26",
    height: "26",
    alt: ""
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column"
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 17,
      letterSpacing: "0.2em",
      color: "var(--text-primary)"
    }
  }, "BIAS BEACON"), /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: 9,
      textTransform: "uppercase",
      letterSpacing: "0.34em",
      color: "var(--text-muted)"
    }
  }, "A.P.T.I.T.U.D.E. \xB7 The Dashboard"))), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 4
    }
  }, [["records", "Actor Records"], ["dashboard", "System Dashboard"]].map(([k, label]) => /*#__PURE__*/React.createElement("button", {
    key: k,
    onClick: () => setTab(k),
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 10.5,
      textTransform: "uppercase",
      letterSpacing: "0.28em",
      padding: "9px 18px",
      borderRadius: "var(--radius-pill)",
      cursor: "pointer",
      border: "1px solid " + (tab === k ? "var(--border-accent)" : "transparent"),
      background: tab === k ? "rgba(200,169,126,0.08)" : "transparent",
      color: tab === k ? "var(--accent)" : "var(--text-muted)",
      transition: "all var(--dur-fast) ease"
    }
  }, label)))));
}
function RecordsView() {
  const {
    JudgeCard,
    Eyebrow,
    Badge
  } = BB;
  const [county, setCounty] = React.useState("All counties");
  const [risk, setRisk] = React.useState("All levels");
  const [q, setQ] = React.useState("");
  const filtered = JUDGES.filter(j => (county === "All counties" || j.county === county) && (risk === "All levels" || j.risk === risk) && (q === "" || j.name.toLowerCase().includes(q.toLowerCase())));
  const selectStyle = {
    fontFamily: "var(--font-ui)",
    fontSize: 12,
    color: "var(--text-secondary)",
    background: "rgba(245,241,230,0.025)",
    border: "1px solid var(--border-strong)",
    borderRadius: "var(--radius-sm)",
    padding: "10px 14px",
    cursor: "pointer",
    outline: "none"
  };
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container)",
      margin: "0 auto",
      padding: "48px var(--gutter) 96px"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "System View \xB7 Actor Records"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-d2)",
      color: "var(--text-primary)",
      lineHeight: 1.1,
      margin: "16px 0 0",
      fontWeight: 600,
      maxWidth: 760
    }
  }, "Where separate public records either reinforce one another ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: "italic",
      color: "var(--accent)"
    }
  }, "or start to fall apart.")), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      fontSize: 18,
      color: "var(--text-secondary)",
      maxWidth: 640,
      marginTop: 18,
      lineHeight: 1.5
    }
  }, "Every judge filtered, compared, and opened deeper \u2014 so the archive stays useful, not ornamental."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      gap: 12,
      flexWrap: "wrap",
      alignItems: "center",
      margin: "40px 0 32px"
    }
  }, /*#__PURE__*/React.createElement("input", {
    value: q,
    onChange: e => setQ(e.target.value),
    placeholder: "Find a judge by name\u2026",
    style: {
      ...selectStyle,
      minWidth: 240,
      color: "var(--text-primary)"
    }
  }), /*#__PURE__*/React.createElement("select", {
    value: county,
    onChange: e => setCounty(e.target.value),
    style: selectStyle
  }, COUNTIES.map(c => /*#__PURE__*/React.createElement("option", {
    key: c,
    style: {
      background: "#0A0F1A"
    }
  }, c))), /*#__PURE__*/React.createElement("select", {
    value: risk,
    onChange: e => setRisk(e.target.value),
    style: selectStyle
  }, RISKS.map(r => /*#__PURE__*/React.createElement("option", {
    key: r,
    style: {
      background: "#0A0F1A",
      textTransform: "capitalize"
    }
  }, r))), /*#__PURE__*/React.createElement("span", {
    style: {
      marginLeft: "auto",
      fontSize: 11,
      textTransform: "uppercase",
      letterSpacing: "0.28em",
      color: "var(--text-muted)"
    }
  }, filtered.length, " records")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(268px, 1fr))",
      gap: 18
    }
  }, filtered.map(j => /*#__PURE__*/React.createElement(JudgeCard, {
    key: j.name,
    name: j.name,
    county: j.county,
    score: j.score,
    riskLevel: j.risk,
    term: j.term,
    tenure: j.tenure,
    caseload: j.caseload,
    metrics: [{
      label: "Prison Usage",
      value: j.prison
    }, {
      label: "Reversal Rate",
      value: j.reversal
    }, {
      label: "Counsel Disparity",
      value: j.counsel
    }, {
      label: "Racial Disparity",
      value: "Pending"
    }]
  }))), filtered.length === 0 && /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      color: "var(--text-muted)",
      textAlign: "center",
      padding: "60px 0"
    }
  }, "No records match the current filters."));
}
function DashboardView() {
  const {
    StatCounter,
    Eyebrow,
    GoldRule,
    Badge
  } = BB;
  const counties = Array.from(new Set(JUDGES.map(j => j.county)));
  const countyData = counties.map(c => {
    const list = JUDGES.filter(j => j.county === c);
    const avgPrison = Math.round(list.reduce((s, j) => s + parseInt(j.prison), 0) / list.length);
    return {
      county: c,
      avgPrison,
      n: list.length
    };
  }).sort((a, b) => b.avgPrison - a.avgPrison);
  const max = Math.max(...countyData.map(c => c.avgPrison));
  return /*#__PURE__*/React.createElement("div", {
    style: {
      maxWidth: "var(--container)",
      margin: "0 auto",
      padding: "48px var(--gutter) 96px"
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, null, "System View \xB7 Statewide"), /*#__PURE__*/React.createElement("h1", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: "var(--text-d2)",
      color: "var(--text-primary)",
      lineHeight: 1.1,
      margin: "16px 0 48px",
      fontWeight: 600
    }
  }, "The record, at ", /*#__PURE__*/React.createElement("span", {
    style: {
      fontStyle: "italic",
      color: "var(--accent)"
    }
  }, "statewide scale.")), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))",
      gap: 28,
      marginBottom: 64
    }
  }, [{
    v: 211,
    s: "",
    l: "judges tracked across 36 counties"
  }, {
    v: 36,
    s: "",
    l: "counties normalized to one civic surface"
  }, {
    v: 54,
    s: "%",
    l: "average prison usage statewide"
  }, {
    v: 1240,
    s: "",
    l: "appellate reversals traced to the bench"
  }].map((k, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    className: "apt-card",
    style: {
      padding: 24
    }
  }, /*#__PURE__*/React.createElement(StatCounter, {
    value: k.v,
    suffix: k.s,
    size: "md"
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      color: "var(--text-secondary)",
      fontSize: 15,
      marginTop: 8
    }
  }, k.l)))), /*#__PURE__*/React.createElement(GoldRule, {
    style: {
      marginBottom: 40
    }
  }), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "grid",
      gridTemplateColumns: "1.4fr 1fr",
      gap: 48,
      alignItems: "start"
    }
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "muted"
  }, "Prison usage by county \xB7 average"), /*#__PURE__*/React.createElement("div", {
    style: {
      marginTop: 28,
      display: "flex",
      flexDirection: "column",
      gap: 18
    }
  }, countyData.map(c => /*#__PURE__*/React.createElement("div", {
    key: c.county
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      justifyContent: "space-between",
      marginBottom: 7
    }
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-ui)",
      fontSize: 13,
      color: "var(--text-secondary)"
    }
  }, c.county, /*#__PURE__*/React.createElement("span", {
    style: {
      color: "var(--text-faint)",
      marginLeft: 8
    }
  }, "\xB7 ", c.n, " judges")), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-display)",
      fontSize: 16,
      color: "var(--text-primary)",
      fontVariantNumeric: "tabular-nums"
    }
  }, c.avgPrison, "%")), /*#__PURE__*/React.createElement("div", {
    style: {
      height: 6,
      background: "rgba(245,241,230,0.06)",
      borderRadius: 999,
      overflow: "hidden"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      height: "100%",
      width: c.avgPrison / max * 100 + "%",
      background: "linear-gradient(90deg, var(--apt-gold-deep), var(--accent))",
      borderRadius: 999
    }
  })))))), /*#__PURE__*/React.createElement("div", {
    className: "apt-card",
    style: {
      padding: 28
    }
  }, /*#__PURE__*/React.createElement(Eyebrow, {
    tone: "muted"
  }, "Signal legend"), /*#__PURE__*/React.createElement("p", {
    style: {
      fontFamily: "var(--font-serif)",
      fontStyle: "italic",
      color: "var(--text-secondary)",
      fontSize: 15,
      margin: "14px 0 22px",
      lineHeight: 1.5
    }
  }, "Five detection classes color every actor record. The point is to make the evidence legible enough to ask better questions."), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: 12
    }
  }, /*#__PURE__*/React.createElement(Badge, {
    variant: "signal",
    signal: "excellent"
  }, "Excellent \u2014 aligned with peers"), /*#__PURE__*/React.createElement(Badge, {
    variant: "signal",
    signal: "low"
  }, "Low \u2014 minor deviation"), /*#__PURE__*/React.createElement(Badge, {
    variant: "signal",
    signal: "moderate"
  }, "Moderate \u2014 notable pattern"), /*#__PURE__*/React.createElement(Badge, {
    variant: "signal",
    signal: "high"
  }, "Elevated \u2014 sustained outlier"), /*#__PURE__*/React.createElement(Badge, {
    variant: "signal",
    signal: "critical"
  }, "Critical \u2014 systemic disparity")))));
}
function BiasBeaconApp() {
  const [tab, setTab] = React.useState("records");
  return /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Header, {
    tab: tab,
    setTab: setTab
  }), tab === "records" ? /*#__PURE__*/React.createElement(RecordsView, null) : /*#__PURE__*/React.createElement(DashboardView, null));
}
Object.assign(window, {
  BiasBeaconApp
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/bias-beacon/screens.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Eyebrow = __ds_scope.Eyebrow;

__ds_ns.GoldRule = __ds_scope.GoldRule;

__ds_ns.JudgeCard = __ds_scope.JudgeCard;

__ds_ns.NumeralHeading = __ds_scope.NumeralHeading;

__ds_ns.PillarCard = __ds_scope.PillarCard;

__ds_ns.SearchField = __ds_scope.SearchField;

__ds_ns.StatCounter = __ds_scope.StatCounter;

})();
