# UI Kit — Bias Beacon

The analytical product: actor-level records and a statewide system view. Reads
intake against outcome, preserves difference without forcing a story, and keeps
every pattern traceable back to its source layer.

## Screens
- `index.html` — the Bias Beacon app (open this). Switch tabs in the header.
- `screens.jsx`:
  - **Header** — sticky glass bar with the scales mark and a two-tab pill switch.
  - **RecordsView** — filterable directory of flippable `JudgeCard`s (search by name,
    filter by county and risk level). Each card flips to a profile + bias-metrics grid.
  - **DashboardView** — statewide `StatCounter` KPIs, a "prison usage by county"
    bar comparison, and the five-class signal legend (`Badge variant="signal"`).

## How it composes the system
Built entirely from `window.APTITUDEDesignSystem_cff43a`: `JudgeCard`, `StatCounter`,
`Badge`, `Eyebrow`, `GoldRule`. Risk levels (`excellent · low · moderate · high ·
critical`) drive each record's accent and score ring via the signal tokens.

> The 12 judges and metrics here are **illustrative sample data** for design
> reference — not the real Oregon dataset.
