/* Bias Beacon — actor directory + system dashboard. Composes the DS bundle. */
const BB = window.APTITUDEDesignSystem_cff43a;

const JUDGES = [
  { name: "Matthew Shirtcliff", county: "Marion", score: 71, risk: "high", term: "2027", tenure: "9 yrs", caseload: "1,240", prison: "62%", reversal: "8%", counsel: "Notable" },
  { name: "Jeffrey Jones", county: "Lane", score: 84, risk: "low", term: "2026", tenure: "14 yrs", caseload: "980", prison: "41%", reversal: "3%", counsel: "Minimal" },
  { name: "Cheryl Pellegrini", county: "Multnomah", score: 58, risk: "critical", term: "2028", tenure: "6 yrs", caseload: "1,510", prison: "70%", reversal: "12%", counsel: "Severe" },
  { name: "Daniel Harris", county: "Washington", score: 90, risk: "excellent", term: "2025", tenure: "21 yrs", caseload: "760", prison: "33%", reversal: "2%", counsel: "Minimal" },
  { name: "Patricia Sullivan", county: "Clackamas", score: 76, risk: "moderate", term: "2027", tenure: "11 yrs", caseload: "1,090", prison: "48%", reversal: "6%", counsel: "Moderate" },
  { name: "Robert Ahn", county: "Multnomah", score: 64, risk: "high", term: "2029", tenure: "4 yrs", caseload: "1,330", prison: "59%", reversal: "9%", counsel: "Notable" },
  { name: "Linda Okafor", county: "Lane", score: 88, risk: "excellent", term: "2026", tenure: "17 yrs", caseload: "640", prison: "29%", reversal: "1%", counsel: "Minimal" },
  { name: "Gregory Mills", county: "Marion", score: 53, risk: "critical", term: "2028", tenure: "8 yrs", caseload: "1,420", prison: "74%", reversal: "14%", counsel: "Severe" },
  { name: "Susan Vargas", county: "Deschutes", score: 79, risk: "moderate", term: "2025", tenure: "13 yrs", caseload: "870", prison: "45%", reversal: "5%", counsel: "Moderate" },
  { name: "Thomas Reed", county: "Washington", score: 67, risk: "high", term: "2027", tenure: "7 yrs", caseload: "1,180", prison: "57%", reversal: "10%", counsel: "Notable" },
  { name: "Angela Brooks", county: "Clackamas", score: 82, risk: "low", term: "2029", tenure: "15 yrs", caseload: "910", prison: "38%", reversal: "4%", counsel: "Minimal" },
  { name: "David Whitfield", county: "Deschutes", score: 60, risk: "critical", term: "2026", tenure: "5 yrs", caseload: "1,360", prison: "68%", reversal: "11%", counsel: "Severe" },
];

const COUNTIES = ["All counties", ...Array.from(new Set(JUDGES.map(j => j.county))).sort()];
const RISKS = ["All levels", "excellent", "low", "moderate", "high", "critical"];

function Header({ tab, setTab }) {
  const L = "APTITUDE".split("");
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 40, background: "rgba(10,15,26,0.7)", backdropFilter: "var(--blur-nav)", WebkitBackdropFilter: "var(--blur-nav)", borderBottom: "1px solid var(--border-subtle)" }}>
      <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "0 var(--gutter)", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <img src="../../assets/scale-logo.svg" width="26" height="26" alt="" />
          <div style={{ display: "flex", flexDirection: "column" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: 17, letterSpacing: "0.2em", color: "var(--text-primary)" }}>BIAS BEACON</span>
            <span style={{ fontSize: 9, textTransform: "uppercase", letterSpacing: "0.34em", color: "var(--text-muted)" }}>A.P.T.I.T.U.D.E. · The Dashboard</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          {[["records", "Actor Records"], ["dashboard", "System Dashboard"]].map(([k, label]) => (
            <button key={k} onClick={() => setTab(k)} style={{
              fontFamily: "var(--font-ui)", fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.28em",
              padding: "9px 18px", borderRadius: "var(--radius-pill)", cursor: "pointer",
              border: "1px solid " + (tab === k ? "var(--border-accent)" : "transparent"),
              background: tab === k ? "rgba(200,169,126,0.08)" : "transparent",
              color: tab === k ? "var(--accent)" : "var(--text-muted)", transition: "all var(--dur-fast) ease",
            }}>{label}</button>
          ))}
        </div>
      </div>
    </header>
  );
}

function RecordsView({ onOpen }) {
  const { JudgeCard, Eyebrow, Badge } = BB;
  const [county, setCounty] = React.useState("All counties");
  const [risk, setRisk] = React.useState("All levels");
  const [q, setQ] = React.useState("");

  const filtered = JUDGES.filter(j =>
    (county === "All counties" || j.county === county) &&
    (risk === "All levels" || j.risk === risk) &&
    (q === "" || j.name.toLowerCase().includes(q.toLowerCase()))
  );

  const selectStyle = {
    fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-secondary)",
    background: "rgba(245,241,230,0.025)", border: "1px solid var(--border-strong)",
    borderRadius: "var(--radius-sm)", padding: "10px 14px", cursor: "pointer", outline: "none",
  };

  return (
    <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "48px var(--gutter) 96px" }}>
      <Eyebrow>System View · Actor Records</Eyebrow>
      <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-d2)", color: "var(--text-primary)", lineHeight: 1.1, margin: "16px 0 0", fontWeight: 600, maxWidth: 760 }}>
        Where separate public records either reinforce one another <span style={{ fontStyle: "italic", color: "var(--accent)" }}>or start to fall apart.</span>
      </h1>
      <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 18, color: "var(--text-secondary)", maxWidth: 640, marginTop: 18, lineHeight: 1.5 }}>
        Every judge filtered, compared, and opened deeper — so the archive stays useful, not ornamental.
      </p>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", alignItems: "center", margin: "40px 0 32px" }}>
        <input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Find a judge by name…" style={{ ...selectStyle, minWidth: 240, color: "var(--text-primary)" }} />
        <select value={county} onChange={(e) => setCounty(e.target.value)} style={selectStyle}>{COUNTIES.map(c => <option key={c} style={{ background: "#0A0F1A" }}>{c}</option>)}</select>
        <select value={risk} onChange={(e) => setRisk(e.target.value)} style={selectStyle}>{RISKS.map(r => <option key={r} style={{ background: "#0A0F1A", textTransform: "capitalize" }}>{r}</option>)}</select>
        <span style={{ marginLeft: "auto", fontSize: 11, textTransform: "uppercase", letterSpacing: "0.28em", color: "var(--text-muted)" }}>{filtered.length} records</span>
      </div>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(268px, 1fr))", gap: 18 }}>
        {filtered.map(j => (
          <JudgeCard key={j.name} name={j.name} county={j.county} score={j.score} riskLevel={j.risk}
            term={j.term} tenure={j.tenure} caseload={j.caseload} onProfile={() => onOpen(j)}
            metrics={[{ label: "Prison Usage", value: j.prison }, { label: "Reversal Rate", value: j.reversal }, { label: "Counsel Disparity", value: j.counsel }, { label: "Racial Disparity", value: "Pending" }]} />
        ))}
      </div>
      {filtered.length === 0 && (
        <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--text-muted)", textAlign: "center", padding: "60px 0" }}>No records match the current filters.</p>
      )}
    </div>
  );
}

function DashboardView() {
  const { StatCounter, Eyebrow, GoldRule, Badge } = BB;
  const counties = Array.from(new Set(JUDGES.map(j => j.county)));
  const countyData = counties.map(c => {
    const list = JUDGES.filter(j => j.county === c);
    const avgPrison = Math.round(list.reduce((s, j) => s + parseInt(j.prison), 0) / list.length);
    return { county: c, avgPrison, n: list.length };
  }).sort((a, b) => b.avgPrison - a.avgPrison);
  const max = Math.max(...countyData.map(c => c.avgPrison));

  return (
    <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "48px var(--gutter) 96px" }}>
      <Eyebrow>System View · Statewide</Eyebrow>
      <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-d2)", color: "var(--text-primary)", lineHeight: 1.1, margin: "16px 0 48px", fontWeight: 600 }}>
        The record, at <span style={{ fontStyle: "italic", color: "var(--accent)" }}>statewide scale.</span>
      </h1>

      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(220px, 1fr))", gap: 28, marginBottom: 64 }}>
        {[{ v: 211, s: "", l: "judges tracked across 36 counties" }, { v: 36, s: "", l: "counties normalized to one civic surface" }, { v: 54, s: "%", l: "average prison usage statewide" }, { v: 1240, s: "", l: "appellate reversals traced to the bench" }].map((k, i) => (
          <div key={i} className="apt-card" style={{ padding: 24 }}>
            <StatCounter value={k.v} suffix={k.s} size="md" />
            <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--text-secondary)", fontSize: 15, marginTop: 8 }}>{k.l}</div>
          </div>
        ))}
      </div>

      <GoldRule style={{ marginBottom: 40 }} />

      <div style={{ display: "grid", gridTemplateColumns: "1.4fr 1fr", gap: 48, alignItems: "start" }}>
        <div>
          <Eyebrow tone="muted">Prison usage by county · average</Eyebrow>
          <div style={{ marginTop: 28, display: "flex", flexDirection: "column", gap: 18 }}>
            {countyData.map(c => (
              <div key={c.county}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 7 }}>
                  <span style={{ fontFamily: "var(--font-ui)", fontSize: 13, color: "var(--text-secondary)" }}>{c.county}<span style={{ color: "var(--text-faint)", marginLeft: 8 }}>· {c.n} judges</span></span>
                  <span style={{ fontFamily: "var(--font-display)", fontSize: 16, color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{c.avgPrison}%</span>
                </div>
                <div style={{ height: 6, background: "rgba(245,241,230,0.06)", borderRadius: 999, overflow: "hidden" }}>
                  <div style={{ height: "100%", width: (c.avgPrison / max * 100) + "%", background: "linear-gradient(90deg, var(--apt-gold-deep), var(--accent))", borderRadius: 999 }} />
                </div>
              </div>
            ))}
          </div>
        </div>
        <div className="apt-card" style={{ padding: 28 }}>
          <Eyebrow tone="muted">Signal legend</Eyebrow>
          <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--text-secondary)", fontSize: 15, margin: "14px 0 22px", lineHeight: 1.5 }}>
            Five detection classes color every actor record. The point is to make the evidence legible enough to ask better questions.
          </p>
          <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
            <Badge variant="signal" signal="excellent">Excellent — aligned with peers</Badge>
            <Badge variant="signal" signal="low">Low — minor deviation</Badge>
            <Badge variant="signal" signal="moderate">Moderate — notable pattern</Badge>
            <Badge variant="signal" signal="high">Elevated — sustained outlier</Badge>
            <Badge variant="signal" signal="critical">Critical — systemic disparity</Badge>
          </div>
        </div>
      </div>
    </div>
  );
}

const RISK_META = {
  excellent: { color: "var(--apt-excellent)", label: "Excellent" },
  low: { color: "var(--apt-low)", label: "Low Concern" },
  moderate: { color: "var(--apt-moderate)", label: "Moderate" },
  high: { color: "var(--apt-high)", label: "Elevated" },
  critical: { color: "var(--apt-critical)", label: "Critical" },
};

function MetricBar({ label, value, pct, color, baseline }) {
  return (
    <div style={{ marginBottom: 22 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline", marginBottom: 8 }}>
        <span style={{ fontFamily: "var(--font-ui)", fontSize: 12, textTransform: "uppercase", letterSpacing: "0.22em", color: "var(--text-muted)" }}>{label}</span>
        <span style={{ fontFamily: "var(--font-display)", fontSize: 22, color: "var(--text-primary)", fontVariantNumeric: "tabular-nums" }}>{value}</span>
      </div>
      <div style={{ position: "relative", height: 6, background: "rgba(245,241,230,0.06)", borderRadius: 999, overflow: "visible" }}>
        <div style={{ height: "100%", width: pct + "%", background: `linear-gradient(90deg, ${color}, color-mix(in srgb, ${color} 55%, #fff))`, borderRadius: 999 }} />
        {baseline != null && (
          <div title="Statewide median" style={{ position: "absolute", top: -3, bottom: -3, left: baseline + "%", width: 1.5, background: "var(--text-secondary)" }} />
        )}
      </div>
    </div>
  );
}

function ProfileView({ judge, onClose }) {
  const { Eyebrow, GoldRule, Badge, Button, StatCounter } = BB;
  const risk = RISK_META[judge.risk] || RISK_META.moderate;
  const countyLabel = judge.county === "Statewide" ? judge.county : judge.county + " County";
  const prison = parseInt(judge.prison), reversal = parseInt(judge.reversal);
  const trend = [38, 44, 41, 52, 49, prison];
  const flags = [
    judge.counsel === "Severe" && "Counsel-disparity outlier vs. county peers",
    reversal >= 10 && "Appellate reversal rate in the top decile statewide",
    prison >= 65 && "Prison usage materially above the statewide median",
  ].filter(Boolean);

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 60, background: "rgba(7,11,20,0.86)", backdropFilter: "blur(8px)", overflowY: "auto" }} onClick={onClose}>
      <div onClick={(e) => e.stopPropagation()} style={{ maxWidth: 1040, margin: "56px auto", padding: "0 var(--gutter) 80px" }}>
        <div className="apt-card" style={{ padding: 0, overflow: "hidden" }}>
          {/* header band */}
          <div style={{ position: "relative", padding: "40px 44px 36px", borderBottom: "1px solid var(--border-subtle)" }}>
            <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${risk.color}, transparent)` }} />
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 24 }}>
              <div>
                <Eyebrow tone="muted">Actor Record · Deep Dive</Eyebrow>
                <h1 style={{ fontFamily: "var(--font-display)", fontSize: "clamp(2rem,4vw,3rem)", color: "var(--text-primary)", margin: "12px 0 6px", fontWeight: 600 }}>{judge.name}</h1>
                <div style={{ fontFamily: "var(--font-ui)", fontSize: 13, textTransform: "uppercase", letterSpacing: "0.24em", color: "var(--text-muted)" }}>{countyLabel} · Circuit Court Judge</div>
                <div style={{ marginTop: 18 }}><Badge variant="signal" signal={judge.risk}>{risk.label}</Badge></div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 14 }}>
                <div style={{ width: 104, height: 104, borderRadius: "50%", display: "grid", placeItems: "center", border: `2px solid ${risk.color}`, background: `color-mix(in srgb, ${risk.color} 12%, transparent)`, boxShadow: `0 0 30px color-mix(in srgb, ${risk.color} 30%, transparent)` }}>
                  <span style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: 40, color: "var(--text-primary)" }}>{judge.score}</span>
                </div>
                <span style={{ fontFamily: "var(--font-ui)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.3em", color: risk.color }}>Aptitudinal Alignment</span>
                <Button variant="ghost" size="sm" onClick={onClose}>✕ Close</Button>
              </div>
            </div>
          </div>

          {/* body */}
          <div style={{ padding: "40px 44px" }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 24, marginBottom: 44 }}>
              {[["Bench Term", judge.term], ["Tenure", judge.tenure], ["2024 Caseload", judge.caseload], ["Counsel Disparity", judge.counsel]].map(([l, v]) => (
                <div key={l}>
                  <div style={{ fontFamily: "var(--font-ui)", fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.24em", color: "var(--text-faint)", marginBottom: 6 }}>{l}</div>
                  <div style={{ fontFamily: "var(--font-display)", fontSize: 22, color: "var(--text-primary)" }}>{v}</div>
                </div>
              ))}
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 56, alignItems: "start" }}>
              <div>
                <Eyebrow>Bias Metrics · vs. statewide median</Eyebrow>
                <div style={{ marginTop: 26 }}>
                  <MetricBar label="Prison Usage" value={judge.prison} pct={prison} color={risk.color} baseline={54} />
                  <MetricBar label="Appellate Reversal Rate" value={judge.reversal} pct={reversal * 5} color={risk.color} baseline={30} />
                  <MetricBar label="Caseload Load Index" value={Math.round(parseInt(judge.caseload.replace(",", "")) / 16) + "%"} pct={Math.round(parseInt(judge.caseload.replace(",", "")) / 16)} color={risk.color} baseline={68} />
                </div>
                <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 14, color: "var(--text-faint)", marginTop: 8, lineHeight: 1.5 }}>
                  The vertical mark is the statewide median. Difference is preserved without forcing a cause.
                </p>
              </div>

              <div>
                <Eyebrow>Prison Usage · six-year trend</Eyebrow>
                <div style={{ display: "flex", alignItems: "flex-end", gap: 12, height: 160, marginTop: 26, padding: "0 4px", borderBottom: "1px solid var(--border-subtle)" }}>
                  {trend.map((v, i) => (
                    <div key={i} style={{ flex: 1, display: "flex", flexDirection: "column", alignItems: "center", gap: 8 }}>
                      <div style={{ width: "100%", height: (v / 80 * 130) + "px", background: i === trend.length - 1 ? `linear-gradient(180deg, ${risk.color}, color-mix(in srgb, ${risk.color} 40%, transparent))` : "linear-gradient(180deg, rgba(200,169,126,0.4), rgba(200,169,126,0.08))", borderRadius: "2px 2px 0 0" }} />
                      <span style={{ fontFamily: "var(--font-ui)", fontSize: 10, color: "var(--text-faint)" }}>{2019 + i}</span>
                    </div>
                  ))}
                </div>

                <div style={{ marginTop: 36 }}>
                  <Eyebrow>Accountability Flags</Eyebrow>
                  <div style={{ marginTop: 18, display: "flex", flexDirection: "column", gap: 12 }}>
                    {flags.length ? flags.map((f, i) => (
                      <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", borderLeft: `2px solid ${risk.color}`, paddingLeft: 14 }}>
                        <span style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, color: "var(--text-secondary)", lineHeight: 1.45 }}>{f}</span>
                      </div>
                    )) : (
                      <span style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--text-muted)" }}>No flags above threshold. Record aligns with county peers.</span>
                    )}
                  </div>
                </div>
              </div>
            </div>

            <GoldRule style={{ margin: "44px 0 28px" }} />
            <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 13, color: "var(--text-faint)", textAlign: "center" }}>
              Coverage note: metrics drawn from {judge.caseload} analyzed 2024 dispositions. For research and orientation only — not a substitute for the official record.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}

function BiasBeaconApp() {
  const [tab, setTab] = React.useState("records");
  const [selected, setSelected] = React.useState(null);
  return (
    <React.Fragment>
      <Header tab={tab} setTab={setTab} />
      {tab === "records" ? <RecordsView onOpen={setSelected} /> : <DashboardView />}
      {selected && <ProfileView judge={selected} onClose={() => setSelected(null)} />}
    </React.Fragment>
  );
}

Object.assign(window, { BiasBeaconApp });
