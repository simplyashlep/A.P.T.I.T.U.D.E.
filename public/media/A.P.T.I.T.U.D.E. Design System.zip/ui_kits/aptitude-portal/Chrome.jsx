/* A.P.T.I.T.U.D.E. portal — TopNav + Footer chrome (product surfaces).
   Exposed on window for the inline page script. */

const NAV_LINKS = [
  { label: "Judiciary", desc: "Every sitting judge in Oregon — identity, metrics, and Aptitudinal Alignment." },
  { label: "Watchtower", desc: "Prosecutors by office and individual — charging tendencies and disparity." },
  { label: "Law Enforcement", desc: "Every officer in Oregon — searchable by agency, rank, and record." },
  { label: "Community Corrections", desc: "Parole and probation officers by county — caseloads and outcomes." },
  { label: "Aptitude Advancement", desc: "Where the connection is made — financial access and the path forward.", gold: true },
  { label: "Bias Beacon", desc: "The dashboard. STOP data, conviction rates, heat maps, and budget flow." },
  { label: "Juris Lab", desc: "Upload documents. AI agents analyze, inform, draft, and surface comparable cases." },
  { label: "Community", desc: "Public comment, statewide meetings, complaint pathways, and groups." },
  { label: "About", desc: "The founders, the methodology, and why we built this." },
];

function Wordmark({ size = 22 }) {
  const dot = { color: "var(--accent)" };
  const L = "APTITUDE".split("");
  return (
    <span style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: size, letterSpacing: "0.22em", color: "var(--text-primary)", display: "inline-flex", alignItems: "baseline" }}>
      {L.map((l, i) => <span key={i}>{l}<span style={dot}>.</span></span>)}
    </span>
  );
}

function TopNav() {
  const [open, setOpen] = React.useState(false);
  return (
    <nav style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 50, background: "rgba(10,15,26,0.6)", backdropFilter: "var(--blur-nav)", WebkitBackdropFilter: "var(--blur-nav)", borderBottom: "1px solid var(--border-subtle)" }}>
      <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "0 var(--gutter)", height: "var(--nav-height)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", flexDirection: "column" }}>
          <a href="#top" style={{ textDecoration: "none" }}><Wordmark /></a>
          <span style={{ fontSize: 9, textTransform: "uppercase", letterSpacing: "0.36em", color: "rgba(140,147,163,0.5)", marginTop: 2 }}>Accountability Is Infrastructure · MMXXVI</span>
        </div>
        <button onClick={() => setOpen(o => !o)} aria-label="Menu" className="nav-medallion" style={{ width: 44, height: 44, borderRadius: 6, display: "grid", placeItems: "center", cursor: "pointer", background: "linear-gradient(180deg, rgba(200,169,126,0.08), rgba(200,169,126,0.03))", border: 0, boxShadow: "0 1px 0 rgba(255,255,255,0.06) inset, 0 6px 18px rgba(0,0,0,0.55), 0 0 24px rgba(200,169,126,0.1)" }}>
          <i data-lucide="landmark" style={{ width: 22, height: 22, color: open ? "var(--accent)" : "var(--text-secondary)" }}></i>
        </button>
      </div>
      {open && (
        <div style={{ position: "absolute", top: "var(--nav-height)", left: 0, right: 0, background: "rgba(10,15,26,0.97)", backdropFilter: "var(--blur-nav)", borderBottom: "1px solid var(--border-subtle)" }}>
          <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "32px var(--gutter)", display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 4 }}>
            {NAV_LINKS.map((l) => (
              <a key={l.label} href="#" onClick={(e)=>{e.preventDefault();setOpen(false);}} style={{ display: "flex", flexDirection: "column", gap: 4, padding: "16px", borderRadius: 4, textDecoration: "none", border: l.gold ? "1px solid rgba(200,169,126,0.25)" : "1px solid transparent", background: l.gold ? "rgba(200,169,126,0.04)" : "transparent", transition: "background var(--dur-fast) ease" }}
                 onMouseEnter={(e)=>e.currentTarget.style.background="rgba(200,169,126,0.06)"}
                 onMouseLeave={(e)=>e.currentTarget.style.background=l.gold?"rgba(200,169,126,0.04)":"transparent"}>
                <span style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.36em", fontWeight: 500, color: l.gold ? "var(--accent)" : "var(--text-primary)" }}>{l.label}</span>
                <span style={{ fontSize: 12, color: "var(--text-muted)", lineHeight: 1.45 }}>{l.desc}</span>
              </a>
            ))}
          </div>
        </div>
      )}
    </nav>
  );
}

function Footer() {
  const { GoldRule } = window.APTITUDEDesignSystem_cff43a;
  const links = ["Judiciary","Watchtower","Law Enforcement","Corrections","Aptitude Advancement","Bias Beacon","Juris Lab","Community","About"];
  return (
    <footer style={{ borderTop: "1px solid var(--border-subtle)", padding: "56px var(--gutter)", position: "relative" }}>
      <div style={{ maxWidth: "var(--container)", margin: "0 auto" }}>
        <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between", gap: 40 }}>
          <div style={{ maxWidth: 440 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 18 }}>
              <img src="../../assets/scale-logo.svg" width="28" height="28" alt="" />
              <Wordmark size={16} />
            </div>
            <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--text-secondary)", fontSize: 16, lineHeight: 1.6, margin: 0 }}>
              Accountability Pathways Through Institutional Transparency, Understanding, and Data Ecosystems — measuring what public institutions promised against what the record shows.
            </p>
            <p style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.36em", color: "var(--text-muted)", marginTop: 16 }}>Precision · Principle · Proof</p>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, auto)", gap: "12px 48px" }}>
            {links.map(l => <a key={l} className="apt-link" style={{ fontSize: 11.5, textTransform: "uppercase", letterSpacing: "0.28em" }} href="#">{l}</a>)}
          </div>
        </div>
        <GoldRule style={{ margin: "40px 0" }} />
        <div style={{ display: "flex", flexWrap: "wrap", justifyContent: "space-between", gap: 16, fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.36em", color: "var(--text-muted)" }}>
          <span>© MMXXVI — A.P.T.I.T.U.D.E. · Oregon</span>
          <span style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", textTransform: "none", letterSpacing: "normal", color: "var(--text-secondary)", fontSize: 14 }}>For research and orientation only — not a substitute for counsel or the official record.</span>
          <span>Public · Accountable · Disciplined</span>
        </div>
      </div>
    </footer>
  );
}

Object.assign(window, { TopNav, Footer, Wordmark, NAV_LINKS });
