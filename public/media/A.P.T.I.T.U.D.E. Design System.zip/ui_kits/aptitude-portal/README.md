# UI Kit — A.P.T.I.T.U.D.E. Public Portal

The public-facing home of the platform: the entry point that frames the nine
"wings" of Oregon's public record and routes people into each accountability tool.

## Screens
- `index.html` — the full single-page portal (open this).
- `Chrome.jsx` — `TopNav` (fixed glass bar + courthouse-medallion mega-menu) and `Footer`.
- `screens.jsx` — page sections:
  - **Hero** — embossed wordmark, acronym, italic tagline, `SearchField`, and the rotating "Oregon · Did You Know" `StatCounter` strip.
  - **PillarsSection** — the "Nine wings of one public record" grid of flippable `PillarCard`s, each themed with its pillar accent.
  - **PrinciplesSection** — three `NumeralHeading` columns (Precision · Principle · Proof).
  - **QuoteSection** — full-bleed editorial pull quote over a faint scales watermark.

## How it composes the system
Everything is built from the design-system bundle (`window.APTITUDEDesignSystem_cff43a`):
`Button`, `Eyebrow`, `GoldRule`, `SearchField`, `StatCounter`, `NumeralHeading`, `PillarCard`.
Icons come from Lucide (CDN) — the brand's icon system — rendered via `<i data-lucide="…">`
and `lucide.createIcons()`.

> This is a recreation for design reference, not production code. The live search
> and counters call backend APIs in the real app; here they are illustrative.
