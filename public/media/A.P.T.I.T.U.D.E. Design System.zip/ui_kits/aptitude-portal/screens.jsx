/* A.P.T.I.T.U.D.E. portal — page sections. Composes the design-system bundle. */
const DS = window.APTITUDEDesignSystem_cff43a;
const { Button, Eyebrow, GoldRule, NumeralHeading, StatCounter, SearchField, PillarCard } = DS;

const FACTS = [
  { value: 211, label: "active circuit judges across 36 Oregon counties" },
  { value: 34, suffix: "%", label: "wider counsel disparity in the highest-flagged counties" },
  { value: 1240, label: "appellate reversals logged and traced to the bench since 2019" },
];

function Hero() {
  const [fact, setFact] = React.useState(0);
  React.useEffect(() => { const id = setInterval(() => setFact(f => (f + 1) % FACTS.length), 5200); return () => clearInterval(id); }, []);
  const L = "APTITUDE".split("");
  const f = FACTS[fact];
  return (
    <section id="top" className="apt-grain" style={{ position: "relative", minHeight: "100svh", display: "flex", flexDirection: "column", overflow: "hidden" }}>
      {/* edge rule lines */}
      <div style={{ position: "absolute", left: "var(--gutter)", top: 96, bottom: 160, width: 1, background: "linear-gradient(to bottom, transparent, rgba(200,169,126,0.22) 25%, rgba(200,169,126,0.22) 75%, transparent)", zIndex: 2 }} />
      <div style={{ position: "absolute", right: "var(--gutter)", top: 96, bottom: 160, width: 1, background: "linear-gradient(to bottom, transparent, rgba(200,169,126,0.22) 25%, rgba(200,169,126,0.22) 75%, transparent)", zIndex: 2 }} />
      <div className="section" style={{ position: "relative", zIndex: 3, flex: 1, display: "flex", flexDirection: "column", justifyContent: "center", paddingTop: 120, paddingBottom: 40 }}>
        <div style={{ maxWidth: 1000 }}>
          <h1 className="apt-wordmark-3d" style={{ fontFamily: "var(--font-display)", fontWeight: 700, fontSize: "var(--text-hero)", letterSpacing: "0.16em", margin: 0, display: "flex", flexWrap: "wrap" }}>
            {L.map((l, i) => <span key={i}>{l}<span style={{ color: "var(--accent)", opacity: 0.7, WebkitTextFillColor: "var(--accent)", margin: "0 0.02em" }}>.</span></span>)}
          </h1>
          <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 16, color: "var(--text-secondary)", letterSpacing: "0.06em", marginTop: 26 }}>
            Accountability&nbsp;Pathways · Through · Institutional · Transparency · Understanding · and · Data · Ecosystems
          </p>
          <p style={{ fontFamily: "var(--font-serif)", fontSize: "clamp(26px,3vw,34px)", color: "var(--text-primary)", fontStyle: "italic", lineHeight: 1.25, marginTop: 36 }}>
            Every public institution has a record<span style={{ color: "var(--accent)" }}>.</span><br />
            <span style={{ color: "var(--text-secondary)", fontSize: "0.8em" }}>Now it has a mirror.</span>
          </p>
          <div style={{ marginTop: 40 }}>
            <div style={{ display: "flex", gap: 24, marginBottom: 16, fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.32em", color: "var(--text-muted)", flexWrap: "wrap" }}>
              <span>Any institution — court, agency, creditor, or officer</span>
              <span style={{ color: "var(--accent)", opacity: 0.6 }}>·</span>
              <span>A statute, rule, or public record</span>
            </div>
            <SearchField placeholder="Search any institution, obligation, statute, or public record…" />
            <div style={{ display: "flex", flexWrap: "wrap", gap: "10px 28px", marginTop: 22 }}>
              {["Aptitudinal Alignment — what it measures","Oregon STOP data","Court financial obligations","DPSST certification"].map(s => (
                <a key={s} className="apt-link" href="#" style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.18em" }}>{s}</a>
              ))}
            </div>
          </div>
        </div>
      </div>
      {/* Oregon · Did You Know strip */}
      <div style={{ borderTop: "1px solid var(--border-subtle)", position: "relative", zIndex: 3 }}>
        <div className="section" style={{ padding: "26px var(--gutter)", display: "flex", alignItems: "center", gap: 40, flexWrap: "wrap" }}>
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ width: 6, height: 6, borderRadius: "50%", background: "var(--accent)" }} />
            <span style={{ fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.36em", color: "var(--accent)" }}>Oregon · Did You Know</span>
          </div>
          <StatCounter key={fact} value={f.value} suffix={f.suffix || ""} label={f.label} size="md" />
        </div>
      </div>
    </section>
  );
}

const PILLARS = [
  { eyebrow: "Pillar I", title: "The Judiciary", icon: "gavel", accent: "var(--apt-judiciary)", rgb: "200,169,126", description: "Every active, sitting judge in Oregon — 211 across 36 counties — with Aptitudinal Alignment indexed.", tiers: [{label:"Tier I",body:"Name, county, term, alignment index."},{label:"Tier II",body:"Prison usage, reversals, sentencing trends."},{label:"Tier III",body:"Deep dive with peer comparison."}] },
  { eyebrow: "Pillar II", title: "The Watchtower", icon: "eye", accent: "var(--apt-watchtower)", rgb: "124,191,176", description: "Prosecutors — by office, then by individual DA and DDA. Charging patterns laid bare.", tiers: [{label:"Tier I",body:"Office, position, caseload, charging."},{label:"Tier II",body:"Plea ratios, dismissals, enhancements."},{label:"Tier III",body:"Disparity by demographic and peer set."}] },
  { eyebrow: "The Dashboard", title: "Bias Beacon", icon: "activity", accent: "var(--apt-beacon)", rgb: "212,149,106", description: "Oregon STOP data, conviction rates, sentencing disparity heat maps, and the money flow of justice.", tiers: [{label:"Statewide",body:"County disparity vs. national baselines."},{label:"Spatial",body:"Heat maps of hot spots; 3D charts."},{label:"Budget",body:"The money center of justice."}] },
  { eyebrow: "The Connection", title: "Aptitude Advancement", icon: "trending-up", accent: "var(--apt-advancement)", rgb: "124,168,139", description: "Where the gap closes. Financial access, open payment infrastructure, and the path forward.", tiers: [{label:"Entry",body:"Name your starting point. We meet you there."},{label:"Connection",body:"Matched resources and access pathways."},{label:"Action",body:"Specific next steps and legal rights."}] },
  { eyebrow: "Your Tools", title: "Juris Lab", icon: "flask-conical", accent: "var(--apt-jurislab)", rgb: "155,143,212", description: "Upload your documents. Four agents analyze, research, inform, and co-draft — nothing is filed for you.", tiers: [{label:"Analyze",body:"Document intake and structured summary."},{label:"Draft",body:"Letters and motions — co-written, never auto-filed."},{label:"Library",body:"Shared templates and caselaw."}] },
  { eyebrow: "Pillar III", title: "Law Enforcement", icon: "shield", accent: "var(--apt-enforcement)", rgb: "91,123,154", description: "Every officer in Oregon — searchable by agency, rank, DPSST certification, and STOP-data record.", tiers: [{label:"Tier I",body:"Agency, rank, sworn date, certifications."},{label:"Tier II",body:"Stop outcomes, force events, complaints."},{label:"Tier III",body:"STOP-data demographic breakdown."}] },
  { eyebrow: "Pillar IV", title: "Community Corrections", icon: "compass", accent: "var(--apt-corrections)", rgb: "196,133,90", description: "Every parole and probation officer in Oregon — caseloads, revocation rates, and outcome disparity.", tiers: [{label:"Tier I",body:"County, caseload, supervision specialty."},{label:"Tier II",body:"Revocation, sanction, completion rates."},{label:"Tier III",body:"Outcome disparity by demographic."}] },
  { eyebrow: "The Record-Keepers", title: "About", icon: "info", accent: "var(--apt-gold-deep)", rgb: "168,137,95", description: "The founders, the Aptitudinal Alignment methodology, and why public accountability is infrastructure.", tiers: [{label:"Founders",body:"Who built this and why."},{label:"Method",body:"How alignment is calculated and verified."},{label:"Sources",body:"Every dataset, every refresh, every gap."}] },
  { eyebrow: "The Commons", title: "Community", icon: "users", accent: "var(--apt-community)", rgb: "107,143,175", description: "Public comment, statewide meetings, agency contacts, complaint pathways, and people navigating the system.", tiers: [{label:"Voice",body:"Public comment and meeting calendars."},{label:"Paths",body:"Step-by-step complaint pathways."},{label:"Groups",body:"Spaces to compare experience."}] },
];

function PillarsSection() {
  return (
    <section style={{ position: "relative", padding: "120px 0" }}>
      <div className="section">
        <div style={{ display: "flex", justifyContent: "space-between", flexWrap: "wrap", gap: 24, alignItems: "baseline", marginBottom: 64 }}>
          <div>
            <Eyebrow>Accountability Is Infrastructure</Eyebrow>
            <h2 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-d1)", color: "var(--text-primary)", lineHeight: 1.05, margin: "16px 0 0", fontWeight: 600 }}>
              Nine wings of one<br /><span style={{ fontStyle: "italic", color: "var(--accent)" }}>public record.</span>
            </h2>
          </div>
          <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 19, color: "var(--text-secondary)", maxWidth: 420, lineHeight: 1.5 }}>
            Every institution that operates in public accepted a standard. Each card is a door into how well they are keeping it. Flip to see what is behind.
          </p>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "clamp(12px,1.4vw,20px)" }}>
          {PILLARS.map((p) => (
            <PillarCard key={p.title} eyebrow={p.eyebrow} title={p.title} description={p.description}
              accent={p.accent} accentRgb={p.rgb} tiers={p.tiers}
              icon={<i data-lucide={p.icon} style={{ width: 13, height: 13 }}></i>} />
          ))}
        </div>
      </div>
    </section>
  );
}

function PrinciplesSection() {
  const cols = [
    { n: "I", eyebrow: "Precision", title: "Precision.", body: "Every answer measured against the controlling rule. We resist the soft language of guesswork; what is uncertain is named uncertain." },
    { n: "II", eyebrow: "Principle", title: "Principle.", body: "Doctrine over disposition. The reasoning is shown — statutes, canons, and the architecture of a holding — not concealed behind confidence." },
    { n: "III", eyebrow: "Proof", title: "Proof.", body: "Authority is the closing argument. We point to the cases, codes, and frameworks that bear the weight, so your work can rest on them." },
  ];
  return (
    <section style={{ padding: "40px 0 120px" }}>
      <div className="section">
        <GoldRule style={{ marginBottom: 80 }} />
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 56 }}>
          {cols.map((c) => (
            <NumeralHeading key={c.n} numeral={c.n} eyebrow={c.eyebrow} title={c.title} body={c.body} />
          ))}
        </div>
      </div>
    </section>
  );
}

function QuoteSection() {
  return (
    <section style={{ position: "relative", padding: "120px 0", overflow: "hidden" }}>
      <img src="../../assets/scale-logo.svg" alt="" style={{ position: "absolute", width: 480, opacity: 0.05, left: "50%", top: "50%", transform: "translate(-50%,-50%)", pointerEvents: "none" }} />
      <div className="section" style={{ position: "relative", textAlign: "center", maxWidth: 920 }}>
        <div style={{ fontFamily: "var(--font-display)", fontSize: 40, color: "var(--accent)", opacity: 0.5, lineHeight: 0.5 }}>&rdquo;</div>
        <blockquote style={{ fontFamily: "var(--font-display)", fontSize: "clamp(34px,5vw,58px)", color: "var(--text-primary)", lineHeight: 1.12, margin: "20px 0 28px", fontWeight: 600 }}>
          &ldquo;Law is reason,<br /><span style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--accent)" }}>free from passion.&rdquo;</span>
        </blockquote>
        <div style={{ fontSize: 11, textTransform: "uppercase", letterSpacing: "0.36em", color: "var(--text-muted)" }}>Aristotle · Politics, Book III</div>
        <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 19, color: "var(--text-secondary)", maxWidth: 620, margin: "48px auto 0", lineHeight: 1.5 }}>
          A.P.T.I.T.U.D.E. exists for the moment between a question and a brief — when reason must do the steady work of taking sides for principle.
        </p>
      </div>
    </section>
  );
}

Object.assign(window, { Hero, PillarsSection, PrinciplesSection, QuoteSection });
