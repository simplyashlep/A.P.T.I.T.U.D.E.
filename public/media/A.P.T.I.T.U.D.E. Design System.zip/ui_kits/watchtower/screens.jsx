/* The Watchtower — prosecutor offices + individual DAs. Composes the DS bundle.
   Pillar accent: teal (--apt-watchtower). */
const WT = window.APTITUDEDesignSystem_cff43a;
const TEAL = "var(--apt-watchtower)";

const OFFICES = [
  { county: "Multnomah", da: "Nathan Vasquez", attys: 92, caseload: "18,400", plea: 71, dismiss: 14, stack: "High", risk: "high" },
  { county: "Lane", da: "Patricia Perlow", attys: 41, caseload: "7,900", plea: 64, dismiss: 19, stack: "Moderate", risk: "moderate" },
  { county: "Marion", da: "Paige Clarkson", attys: 48, caseload: "9,300", plea: 76, dismiss: 11, stack: "High", risk: "critical" },
  { county: "Washington", da: "Kevin Barton", attys: 55, caseload: "10,100", plea: 62, dismiss: 21, stack: "Low", risk: "low" },
  { county: "Clackamas", da: "John Wentworth", attys: 33, caseload: "6,200", plea: 68, dismiss: 16, stack: "Moderate", risk: "moderate" },
  { county: "Deschutes", da: "Steve Gunnels", attys: 24, caseload: "4,800", plea: 73, dismiss: 12, stack: "High", risk: "high" },
];

const PROSECUTORS = [
  { name: "Nathan Vasquez", county: "Multnomah", score: 66, risk: "high", role: "District Attorney", term: "Elected", tenure: "2 yrs", caseload: "—", plea: "71%", dismiss: "14%", stack: "High" },
  { name: "Amanda Nadell", county: "Multnomah", score: 59, risk: "critical", role: "Sr. Deputy DA", term: "Appointed", tenure: "11 yrs", caseload: "1,910", plea: "78%", dismiss: "9%", stack: "Severe" },
  { name: "Patricia Perlow", county: "Lane", score: 81, risk: "low", role: "District Attorney", term: "Elected", tenure: "9 yrs", caseload: "—", plea: "64%", dismiss: "19%", stack: "Moderate" },
  { name: "Erik Hasselman", county: "Lane", score: 84, risk: "excellent", role: "Chief Deputy DA", term: "Appointed", tenure: "14 yrs", caseload: "1,420", plea: "61%", dismiss: "22%", stack: "Low" },
  { name: "Paige Clarkson", county: "Marion", score: 57, risk: "critical", role: "District Attorney", term: "Elected", tenure: "5 yrs", caseload: "—", plea: "76%", dismiss: "11%", stack: "High" },
  { name: "Kevin Barton", county: "Washington", score: 83, risk: "low", role: "District Attorney", term: "Elected", tenure: "7 yrs", caseload: "—", plea: "62%", dismiss: "21%", stack: "Low" },
];

function Header({ tab, setTab }) {
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 40, background: "rgba(10,15,26,0.7)", backdropFilter: "var(--blur-nav)", WebkitBackdropFilter: "var(--blur-nav)", borderBottom: "1px solid var(--border-subtle)" }}>
      <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "0 var(--gutter)", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between", gap: 24 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <i data-lucide="eye" style={{ width: 22, height: 22, color: TEAL }}></i>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: 17, letterSpacing: "0.2em", color: "var(--text-primary)", whiteSpace: "nowrap" }}>THE WATCHTOWER</span>
            <span style={{ fontSize: 9, textTransform: "uppercase", letterSpacing: "0.34em", color: "var(--text-muted)" }}>A.P.T.I.T.U.D.E. · Pillar II</span>
          </div>
        </div>
        <div style={{ display: "flex", gap: 4 }}>
          {[["offices", "By Office"], ["actors", "Individual Prosecutors"]].map(([k, label]) => (
            <button key={k} onClick={() => setTab(k)} style={{
              fontFamily: "var(--font-ui)", fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.28em",
              padding: "9px 18px", borderRadius: "var(--radius-pill)", cursor: "pointer",
              border: "1px solid " + (tab === k ? "color-mix(in srgb, " + TEAL + " 50%, transparent)" : "transparent"),
              background: tab === k ? "color-mix(in srgb, " + TEAL + " 10%, transparent)" : "transparent",
              color: tab === k ? TEAL : "var(--text-muted)", transition: "all var(--dur-fast) ease",
            }}>{label}</button>
          ))}
        </div>
      </div>
    </header>
  );
}

function OfficeCard({ o }) {
  const max = 80;
  return (
    <div className="apt-card" style={{ padding: 26, position: "relative" }}>
      <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, transparent, ${TEAL} 45%, transparent)` }} />
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
        <div>
          <h3 style={{ fontFamily: "var(--font-display)", fontWeight: 600, fontSize: 22, color: "var(--text-primary)", margin: 0 }}>{o.county} County DA</h3>
          <div style={{ fontFamily: "var(--font-ui)", fontSize: 12, color: "var(--text-muted)", marginTop: 2 }}>{o.da} · {o.attys} attorneys</div>
        </div>
        <span style={{ fontFamily: "var(--font-ui)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.2em", color: TEAL, border: `1px solid color-mix(in srgb, ${TEAL} 40%, transparent)`, borderRadius: 2, padding: "4px 8px" }}>Stack · {o.stack}</span>
      </div>
      <div style={{ display: "flex", gap: 28, marginTop: 22 }}>
        <div><div style={{ fontFamily: "var(--font-display)", fontSize: 26, color: "var(--text-primary)" }}>{o.caseload}</div><div style={{ fontSize: 9.5, textTransform: "uppercase", letterSpacing: "0.22em", color: "var(--text-faint)" }}>2024 caseload</div></div>
      </div>
      <div style={{ marginTop: 22, display: "flex", flexDirection: "column", gap: 14 }}>
        {[["Plea rate", o.plea], ["Dismissal rate", o.dismiss]].map(([l, v]) => (
          <div key={l}>
            <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 6 }}>
              <span style={{ fontFamily: "var(--font-ui)", fontSize: 11.5, textTransform: "uppercase", letterSpacing: "0.18em", color: "var(--text-muted)" }}>{l}</span>
              <span style={{ fontFamily: "var(--font-display)", fontSize: 15, color: "var(--text-primary)" }}>{v}%</span>
            </div>
            <div style={{ height: 5, background: "rgba(245,241,230,0.06)", borderRadius: 999 }}>
              <div style={{ height: "100%", width: (v / max * 100) + "%", background: `linear-gradient(90deg, color-mix(in srgb, ${TEAL} 55%, #000), ${TEAL})`, borderRadius: 999 }} />
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function OfficesView() {
  const { Eyebrow, StatCounter, GoldRule } = WT;
  return (
    <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "48px var(--gutter) 96px" }}>
      <Eyebrow style={{ color: TEAL }}>Pillar II · Prosecutors</Eyebrow>
      <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-d2)", color: "var(--text-primary)", lineHeight: 1.1, margin: "16px 0 0", fontWeight: 600, maxWidth: 760 }}>
        Charging patterns, <span style={{ fontStyle: "italic", color: TEAL }}>laid bare.</span>
      </h1>
      <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 18, color: "var(--text-secondary)", maxWidth: 640, marginTop: 18, lineHeight: 1.5 }}>
        Prosecutors — by office, then by individual DA and DDA. Where charging intensity and courtroom outcomes move together, and where they do not.
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))", gap: 24, margin: "44px 0 56px" }}>
        {[{ v: 36, s: "", l: "county DA offices statewide" }, { v: 69, s: "%", l: "average plea rate across offices" }, { v: 16, s: "%", l: "average dismissal rate" }].map((k, i) => (
          <div key={i} className="apt-card" style={{ padding: 22 }}>
            <StatCounter value={k.v} suffix={k.s} size="md" accent={TEAL} />
            <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", color: "var(--text-secondary)", fontSize: 14, marginTop: 8 }}>{k.l}</div>
          </div>
        ))}
      </div>
      <GoldRule style={{ marginBottom: 40 }} />
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(340px, 1fr))", gap: 18 }}>
        {OFFICES.map(o => <OfficeCard key={o.county} o={o} />)}
      </div>
    </div>
  );
}

function ActorsView() {
  const { JudgeCard, Eyebrow } = WT;
  return (
    <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "48px var(--gutter) 96px" }}>
      <Eyebrow style={{ color: TEAL }}>Pillar II · Individual Prosecutors</Eyebrow>
      <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-d2)", color: "var(--text-primary)", lineHeight: 1.1, margin: "16px 0 40px", fontWeight: 600 }}>
        Every DA and deputy, <span style={{ fontStyle: "italic", color: TEAL }}>by the record.</span>
      </h1>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(268px, 1fr))", gap: 18 }}>
        {PROSECUTORS.map(p => (
          <JudgeCard key={p.name} name={p.name} county={p.county} role={p.role} score={p.score} riskLevel={p.risk}
            scoreLabel="Charging Alignment" term={p.term} tenure={p.tenure} caseload={p.caseload}
            metrics={[{ label: "Plea Rate", value: p.plea }, { label: "Dismissal Rate", value: p.dismiss }, { label: "Charge Stacking", value: p.stack }, { label: "Disparity", value: "Pending" }]} />
        ))}
      </div>
    </div>
  );
}

function WatchtowerApp() {
  const [tab, setTab] = React.useState("offices");
  React.useEffect(() => { if (window.lucide) window.lucide.createIcons(); });
  return (
    <React.Fragment>
      <Header tab={tab} setTab={setTab} />
      {tab === "offices" ? <OfficesView /> : <ActorsView />}
    </React.Fragment>
  );
}

Object.assign(window, { WatchtowerApp });
