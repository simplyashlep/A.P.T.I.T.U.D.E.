/* Juris Lab — document intake + four AI agents + co-drafting. Composes the DS bundle.
   Pillar accent: plum (--apt-jurislab). Nothing is ever filed for you. */
const JL = window.APTITUDEDesignSystem_cff43a;
const PLUM = "var(--apt-jurislab)";

const AGENTS = [
  { key: "intake", name: "Intake Parser", icon: "file-text", role: "Structures observable facts only — never infers legal conclusions." },
  { key: "classify", name: "Legal Classifier", icon: "git-branch", role: "Maps events to claim types and doctrine clusters, using the ontology only." },
  { key: "retrieve", name: "Vector Retrieval", icon: "search", role: "Surfaces supporting authority — cases, statutes, policies. Ranked, never conclusive." },
  { key: "draft", name: "Procedural Engine", icon: "pen-line", role: "Builds ordered enforcement pathways with prerequisites and jurisdiction alignment." },
];

const SAMPLE_DOCS = ["Arrest narrative — Marion Co.", "FCRA dispute letter", "Eviction notice (ORS 90)", "Sentencing memo"];

function Header() {
  return (
    <header style={{ position: "sticky", top: 0, zIndex: 40, background: "rgba(10,15,26,0.7)", backdropFilter: "var(--blur-nav)", WebkitBackdropFilter: "var(--blur-nav)", borderBottom: "1px solid var(--border-subtle)" }}>
      <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "0 var(--gutter)", height: 64, display: "flex", alignItems: "center", justifyContent: "space-between" }}>
        <div style={{ display: "flex", alignItems: "center", gap: 14 }}>
          <i data-lucide="flask-conical" style={{ width: 22, height: 22, color: PLUM }}></i>
          <div style={{ display: "flex", flexDirection: "column" }}>
            <span style={{ fontFamily: "var(--font-display)", fontSize: 17, letterSpacing: "0.2em", color: "var(--text-primary)" }}>JURIS LAB</span>
            <span style={{ fontSize: 9, textTransform: "uppercase", letterSpacing: "0.34em", color: "var(--text-muted)" }}>A.P.T.I.T.U.D.E. · Your Tools</span>
          </div>
        </div>
        <span style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 14, color: "var(--text-muted)" }}>Nothing is ever filed for you.</span>
      </div>
    </header>
  );
}

function JurisLabApp() {
  const { Eyebrow, Button, Badge, GoldRule } = JL;
  const [doc, setDoc] = React.useState(null);
  const [stage, setStage] = React.useState(-1); // -1 idle, 0..3 running, 4 done
  React.useEffect(() => { if (window.lucide) window.lucide.createIcons(); });

  React.useEffect(() => {
    if (stage < 0 || stage >= AGENTS.length) return;
    const id = setTimeout(() => setStage(s => s + 1), 850);
    return () => clearTimeout(id);
  }, [stage]);

  const run = () => { if (doc) setStage(0); };
  const done = stage >= AGENTS.length;

  const dropStyle = {
    border: `1px dashed ${doc ? "color-mix(in srgb, " + PLUM + " 55%, transparent)" : "var(--border-strong)"}`,
    borderRadius: "var(--radius-md)", padding: "40px 28px", textAlign: "center",
    background: doc ? "color-mix(in srgb, " + PLUM + " 7%, transparent)" : "rgba(245,241,230,0.02)",
    transition: "all var(--dur-base) ease",
  };

  return (
    <React.Fragment>
      <Header />
      <div style={{ maxWidth: "var(--container)", margin: "0 auto", padding: "48px var(--gutter) 96px" }}>
        <Eyebrow style={{ color: PLUM }}>Your Tools · Document Intelligence</Eyebrow>
        <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--text-d2)", color: "var(--text-primary)", lineHeight: 1.1, margin: "16px 0 0", fontWeight: 600, maxWidth: 820 }}>
          Upload your documents. Four agents <span style={{ fontStyle: "italic", color: PLUM }}>analyze, research, inform, and co-draft.</span>
        </h1>
        <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 18, color: "var(--text-secondary)", maxWidth: 660, marginTop: 18, lineHeight: 1.5 }}>
          Auditability before automation. Every output carries provenance — and nothing leaves your hands without you.
        </p>

        <div style={{ display: "grid", gridTemplateColumns: "minmax(300px, 0.9fr) 1.3fr", gap: 40, marginTop: 48, alignItems: "start" }}>
          {/* LEFT — intake */}
          <div className="apt-card" style={{ padding: 28 }}>
            <Eyebrow tone="muted">Intake</Eyebrow>
            <div style={{ ...dropStyle, marginTop: 18 }}>
              <i data-lucide="upload-cloud" style={{ width: 28, height: 28, color: doc ? PLUM : "var(--text-muted)" }}></i>
              <div style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 16, color: "var(--text-secondary)", marginTop: 12 }}>
                {doc ? doc : "Drop a record, or choose a sample below"}
              </div>
            </div>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginTop: 18 }}>
              {SAMPLE_DOCS.map(d => (
                <button key={d} onClick={() => { setDoc(d); setStage(-1); }} style={{
                  fontFamily: "var(--font-ui)", fontSize: 10.5, letterSpacing: "0.08em", padding: "7px 12px", cursor: "pointer",
                  borderRadius: 999, border: "1px solid " + (doc === d ? "color-mix(in srgb, " + PLUM + " 55%, transparent)" : "var(--border-strong)"),
                  background: doc === d ? "color-mix(in srgb, " + PLUM + " 12%, transparent)" : "transparent",
                  color: doc === d ? PLUM : "var(--text-muted)", transition: "all var(--dur-fast) ease",
                }}>{d}</button>
              ))}
            </div>
            <div style={{ marginTop: 24 }}>
              <Button variant="primary" onClick={run} style={{ background: PLUM, borderColor: PLUM, width: "100%" }} disabled={!doc}>
                {done ? "Re-run pipeline" : "Run the four agents"}
              </Button>
            </div>
          </div>

          {/* RIGHT — pipeline + output */}
          <div>
            <Eyebrow tone="muted">The pipeline</Eyebrow>
            <div style={{ display: "flex", flexDirection: "column", gap: 12, marginTop: 18 }}>
              {AGENTS.map((a, i) => {
                const active = stage === i;
                const complete = stage > i;
                const c = active ? PLUM : complete ? "var(--apt-excellent)" : "var(--text-faint)";
                return (
                  <div key={a.key} style={{ display: "flex", gap: 16, alignItems: "flex-start", padding: "16px 18px", borderRadius: "var(--radius-sm)", border: `1px solid ${active ? "color-mix(in srgb, " + PLUM + " 45%, transparent)" : "var(--border-subtle)"}`, background: active ? "color-mix(in srgb, " + PLUM + " 6%, transparent)" : "transparent", transition: "all var(--dur-base) ease" }}>
                    <div style={{ width: 36, height: 36, flex: "none", borderRadius: "50%", display: "grid", placeItems: "center", border: `1px solid color-mix(in srgb, ${c} 50%, transparent)`, color: c }}>
                      {complete ? <span style={{ fontSize: 16 }}>✓</span> : <i data-lucide={a.icon} style={{ width: 15, height: 15 }}></i>}
                    </div>
                    <div style={{ flex: 1 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
                        <span style={{ fontFamily: "var(--font-ui)", fontSize: 13.5, fontWeight: 500, color: "var(--text-primary)", letterSpacing: "0.04em" }}>{a.name}</span>
                        {active && <span style={{ fontFamily: "var(--font-ui)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.24em", color: PLUM }}>Running…</span>}
                        {complete && <span style={{ fontFamily: "var(--font-ui)", fontSize: 9, textTransform: "uppercase", letterSpacing: "0.24em", color: "var(--apt-excellent)" }}>Done</span>}
                      </div>
                      <p style={{ fontFamily: "var(--font-ui)", fontWeight: 300, fontSize: 12.5, color: "var(--text-muted)", margin: "4px 0 0", lineHeight: 1.45 }}>{a.role}</p>
                    </div>
                  </div>
                );
              })}
            </div>

            {done && (
              <div className="apt-card" style={{ padding: 28, marginTop: 24 }}>
                <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 18 }}>
                  <span style={{ width: 16, height: 1, background: PLUM }} />
                  <span style={{ fontFamily: "var(--font-ui)", fontSize: 10.5, textTransform: "uppercase", letterSpacing: "0.3em", color: PLUM }}>The Record Responds</span>
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 8, marginBottom: 18 }}>
                  <Badge variant="signal" signal="moderate">Claim · Due-process</Badge>
                  <Badge variant="signal" signal="low">Doctrine · Estoppel cluster</Badge>
                  <Badge>3 authorities</Badge>
                  <Badge>Provenance logged</Badge>
                </div>
                <p style={{ fontFamily: "var(--font-serif)", fontStyle: "italic", fontSize: 16, color: "var(--text-secondary)", lineHeight: 1.6, margin: 0 }}>
                  "{doc}" structured into 4 events and 2 candidate claims. A draft response is staged below — co-written, never auto-filed. Review each citation before you rely on it.
                </p>
                <GoldRule style={{ margin: "22px 0" }} />
                <div style={{ display: "flex", gap: 12 }}>
                  <Button variant="secondary" size="sm">Open draft</Button>
                  <Button variant="ghost" size="sm">View audit trail</Button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </React.Fragment>
  );
}

Object.assign(window, { JurisLabApp });
